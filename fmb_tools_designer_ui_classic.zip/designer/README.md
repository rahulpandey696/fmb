# Qt Designer files for FMB tools

Open any `.ui` file here with **Qt Designer**. On Windows QGIS ships Qt Designer: open the
**OSGeo4W Shell** and run `designer`, then use File → Open.

## `project_tab.ui` — live: the plugin loads this file

The **Project** tab (the first tab) is built from `project_tab.ui` every time the plugin starts.
Anything you change here in Designer appears in the plugin after you reload it (Plugin Reloader,
or restart QGIS):

* layout, order, group boxes, spacing, sizes
* labels, button texts, tooltips, check-box defaults, spin-box ranges
* the settings of FMB widgets (see below)

**Keep the `objectName` of every widget the code uses.** The plugin connects to them by name:

| Area | Object names |
|---|---|
| Current model | `cur_label`, `open_btn`, `save_all_btn`, `open_folder_btn`, `folders_btn`, `last_btn`, `files_tree` |
| New model | `root`, `root_folders_btn`, `name`, `solver`, `hardware`, `sgs`, `quadtree`, `one_d`, `units`, `gisfmt`, `cell` |
| 2D domain | `draw_area_btn`, `draw_rect3_btn`, `draw_rect2_btn`, `view_btn`, `extent_layer`, `selected_only_cb`, `refresh_layers_btn`, `fit_btn`, `rotate_cb`, `margin`, `snap_cb`, `show_cells_cb`, `ox`, `oy`, `rot`, `gx`, `gy`, `dom_summary`, `zoom_btn`, `clear_dom_btn`, `use_area_code_cb`, `write_loc_cb`, `domain_group`, `scroll` |
| Inputs | `dem`, `code`, `loc`, `mat`, `bc`, `proj` |
| Time & output | `start`, `end`, `dt`, `mapfmt`, `maptypes`, `mapint`, `tsint`, `inflow`, `events`, `create_btn` |

You can add new widgets freely, but they only do something once code is connected to them.

## FMB widgets (promoted widgets)

FMB tools' own widgets are *promoted* in the `.ui` files. Designer draws them as their base class,
which is often an empty `QWidget` box. Their settings are **dynamic properties** — select the
widget and look at the bottom of the Property Editor:

| Class (base) | Dynamic properties |
|---|---|
| `FmbPathEdit` (QWidget) | `fmbKind` = file / folder / gis / grid, `fmbFilter` e.g. `Grids (*.tif *.asc)`, `fmbPlaceholder` |
| `FmbRadioChoice` (QWidget) | `fmbOptions` e.g. `HPC\|CLASSIC`, `fmbDefault` (shown underlined), `fmbValue` (initially selected) |
| `FmbNumberSpin` (QDoubleSpinBox) | `fmbUnit`, `fmbIsInt`, `fmbMin`, `fmbMax`, `fmbStep`, `fmbDefault`, `fmbPrefix` (blank = "not set" state) |
| `FmbTokenListEdit` (QWidget) | `fmbSeparator`, `fmbPlaceholder` (the token list is filled by the code) |
| `FmbChoiceEdit` (QComboBox) | normal combo-box items and `editable` |
| `SmartDoubleSpin` / `SmartIntSpin` | normal spin-box properties (these boxes also handle pasted values) |
| `FmbLogView`, `FmbNumberEdit`, `LineChart` (QWidget) | none (used in the reference files) |

To add a new one, place the base widget, right-click it → **Promote to…**, type the class name, and
set the header file to `fmb_tools/ui/designer_widgets.h`. That header is only a module name, so
Designer saying the file can't be found is expected.

## `reference/` — the other tabs

These files are exported from the running plugin. They show every other tab with its real layouts,
widgets, texts, tooltips and object names. Use them to view the interface, try out changes, or
start converting a tab to a live `.ui` file.

Those tabs are still built in Python (`ui/tabs.py`, `ui/empty_tab.py`, `ui/outputs_tab.py`,
`ui/control_file_editor.py`, `ui/main_dialog.py`), so editing a reference file does not change the
plugin. To regenerate the reference files after a code change, go to **Help → Export .ui files for
Qt Designer…**.
