# FMB tools – Qt Designer files (v0.10.0 workbench)

## Opening the files
Open these files in **Qt Designer**. On Windows, open the **OSGeo4W Shell** and run `designer`,
then use File → Open.

* Keep `icon.png` in the same folder as the `.ui` files, because the sidebar logo loads from it.
* The files carry the plugin's theme, so in Designer they look the same as the plugin.
* Press **Ctrl+R** (Form → Preview) to see a live preview.

## Files

| File | What it shows |
|---|---|
| `fmb_workbench.ui` | The whole window: header, sidebar and **every page**. The pages sit in a stacked widget — select it in the Object Inspector and use the small ◀ ▶ arrows (or set `currentIndex`) to page through Dashboard, Project, TCF, TGC… Help. |
| `fmb_workbench_welcome.ui` | The same window with no model open (the welcome screen). |
| `01_dashboard.ui` … `16_help.ui` | One file per page — the quickest way to show a single screen on a slide. |
| `17_folder_structure_dialog.ui` | The "Create TUFLOW folder structure" dialog. |
| `18_flood_modeller_import.ui` | The "Import a Flood Modeller model" wizard (source, new model, 1D engine, 2D options, preview). |
| `previews/*.png` | How each file renders, plus a screenshot of `01_dashboard.ui` opened in Qt Designer. |

The dashboard and editor pages show an example model ("Brisbane_~s1~_001", 10 m cells, 3 events)
so the screens are filled in.

## Notes
* FMB's own widgets are *promoted* widgets: file pickers, radio-button groups, number boxes and the log
  view. Designer draws them as their base class, sometimes as an empty box, and their settings appear as
  `fmb*` dynamic properties.
* In the plugin, the sidebar step circles are drawn by code. In Designer the sidebar is a plain list:
  ✓ marks finished steps, and the numbers are the step numbers.
* These are presentation / reference copies. The plugin builds its window in Python, except the Project
  page, which it loads from `fmb_tools/ui/designer/project_tab.ui`. In the plugin, **Help → Export .ui
  files for Qt Designer…** writes a fresh set from your own open model.
