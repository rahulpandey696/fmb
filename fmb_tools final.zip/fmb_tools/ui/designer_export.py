# -*- coding: utf-8 -*-
"""
Export the live FMB tools interface to Qt Designer .ui files.

Every tab is written with its real layouts, widgets, texts, tooltips, ranges and object
names (the Python attribute names), so it opens in Qt Designer for viewing and editing.
FMB widgets are written as promoted widgets (see designer_widgets.py) with their settings as
fmb* dynamic properties. The Project tab is *loaded* from ui/designer/project_tab.ui at run
time; the other tabs are still built in Python - their .ui files are a faithful reference /
starting point (see ui/designer/README.md).

    from fmb_tools.ui.designer_export import export_all
    export_all(main_dialog, "C:/temp/fmb_ui")
"""
import os
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import Qt, QObject
from qgis.PyQt.QtWidgets import (QWidget, QLayout, QBoxLayout, QGridLayout, QFormLayout, QTabWidget, QSplitter,
                                 QScrollArea, QStackedWidget, QGroupBox, QLabel, QAbstractButton, QLineEdit, QComboBox,
                                 QAbstractSpinBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit, QTreeWidget,
                                 QTableWidget, QAbstractItemView, QFrame, QCheckBox, QRadioButton, QToolButton,
                                 QDialog, QSizePolicy, QMenu, QListWidget, QProgressBar, QPushButton)
import re

from . import widgets as W

HEADER = "fmb_tools/ui/designer_widgets.h"
# FMB widget class -> (name in the .ui, Qt base class)
PROMOTE = [
    (W.SmartDoubleSpin, "SmartDoubleSpin", "QDoubleSpinBox"), (W.SmartIntSpin, "SmartIntSpin", "QSpinBox"),
    (W.NumberSpin, "FmbNumberSpin", "QDoubleSpinBox"), (W.NumberEdit, "FmbNumberEdit", "QWidget"),
    (W.PathEdit, "FmbPathEdit", "QWidget"), (W.RadioChoice, "FmbRadioChoice", "QWidget"),
    (W.TokenListEdit, "FmbTokenListEdit", "QWidget"), (W.ChoiceEdit, "FmbChoiceEdit", "QComboBox"),
    (W.LogView, "FmbLogView", "QWidget"), (W.LineChart, "LineChart", "QWidget"),
]
QT_MODULES = ("PyQt5.", "PyQt6.", "qgis.PyQt.", "sip")


class Exporter(object):
    pixmap_file = ""                # file name written next to the .ui for label pictures (logo)

    _policies = {}

    def _default_policy(self, w):
        """Size policy a fresh widget of the same Qt class has (None if unknown)."""
        base = None
        for c in type(w).__mro__:
            if c.__module__.startswith(QT_MODULES):
                base = c
                break
        if base is None:
            return None
        if base not in self._policies:
            try:
                tmp = base()
                self._policies[base] = tmp.sizePolicy()
                tmp.deleteLater()
            except Exception:
                self._policies[base] = None
        return self._policies[base]

    def __init__(self, root, class_name, placeholders=None):
        self.root = root
        self.class_name = class_name
        self.placeholders = placeholders or {}       # widget -> text: write a placeholder page instead
        self.names = {}
        self.used = set()
        self.custom = {}
        self._collect_names(root)
        # object names used as style-sheet selectors (#Card, #Muted ...) are shared by many widgets but
        # Designer needs unique names - they become an 'fmbStyle' property and [fmbStyle="..."] selectors
        qss = " ".join(x.styleSheet() for x in [root] + root.findChildren(QWidget) if x.styleSheet())
        objnames = {x.objectName() for x in [root] + root.findChildren(QWidget) if x.objectName()}
        self.style_names = set(re.findall(r"#([A-Za-z_]\w*)", qss)) & objnames

    # -- names -------------------------------------------------------------------
    def _collect_names(self, obj, depth=0):
        if depth > 2:
            return
        for attr, val in list(getattr(obj, "__dict__", {}).items()):
            if isinstance(val, QObject) and id(val) not in self.names and not attr.startswith("__"):
                self.names[id(val)] = attr.lstrip("_") or attr
                if isinstance(val, QWidget) and not self._leaf(val) and depth < 2 and val is not obj:
                    self._collect_names(val, depth + 1)

    def _name(self, obj, prefix):
        n = obj.objectName() or self.names.get(id(obj)) or ""
        n = "".join(c if c.isalnum() or c == "_" else "_" for c in n) or prefix
        base, i = n, 2
        if n == prefix:
            n = "{}_{}".format(prefix, i)
        while n in self.used:
            n = "{}_{}".format(base, i)
            i += 1
        self.used.add(n)
        return n

    # -- classes -----------------------------------------------------------------
    @staticmethod
    def _qt_base(w):
        for c in type(w).__mro__:
            if c.__module__.startswith(QT_MODULES) or c.__module__ in ("PyQt5.QtWidgets", "PyQt6.QtWidgets"):
                return c.__name__
        return "QWidget"

    @staticmethod
    def _hidden(w):
        """Hidden on purpose by the code (not just a page of a stacked / tab widget)."""
        p = w.parentWidget()
        return w.isHidden() and not isinstance(p, QStackedWidget) and \
            w.testAttribute(Qt.WidgetAttribute.WA_WState_ExplicitShowHide)

    def _class(self, w):
        for cls, name, base in PROMOTE:
            if isinstance(w, cls):
                self.custom[name] = (base, HEADER)
                return name
        mod = type(w).__module__
        if mod.startswith("qgis.gui") or mod.startswith("qgis._gui"):
            name = type(w).__name__
            self.custom[name] = (self._qt_base(w), name.lower() + ".h")
            return name
        return self._qt_base(w)

    def _leaf(self, w):
        return any(isinstance(w, cls) for cls, _n, _b in PROMOTE) or type(w).__module__.startswith(("qgis.gui", "qgis._gui"))

    # -- properties ---------------------------------------------------------------
    @staticmethod
    def _p(el, name, value, kind=None, stdset=True):
        p = ET.SubElement(el, "property", name=name)
        if not stdset:
            p.set("stdset", "0")
        if kind is None:
            kind = {bool: "bool", int: "number", float: "double"}.get(type(value), "string")
        if kind == "bool":
            ET.SubElement(p, "bool").text = "true" if value else "false"
        elif kind == "size":
            s = ET.SubElement(p, "size")
            ET.SubElement(s, "width").text = str(int(value[0]))
            ET.SubElement(s, "height").text = str(int(value[1]))
        elif kind in ("enum", "set", "number", "double"):
            ET.SubElement(p, kind).text = str(value)
        else:
            ET.SubElement(p, "string").text = str(value)

    def _props(self, w, el, top=False):
        P = self._p
        tip = w.toolTip()
        if tip:
            P(el, "toolTip", tip)
        if not w.isEnabled() and not top:
            P(el, "enabled", False)
        ms, mx = w.minimumSize(), w.maximumSize()
        if (ms.width() or ms.height()) and not isinstance(w, (QLabel,)):
            P(el, "minimumSize", (ms.width(), ms.height()), "size")
        if mx.width() < 16777215 or mx.height() < 16777215:
            P(el, "maximumSize", (min(mx.width(), 16777215), min(mx.height(), 16777215)), "size")
        if w.objectName() in self.style_names:
            P(el, "fmbStyle", w.objectName(), stdset=False)
        for raw in w.dynamicPropertyNames():
            pn = bytes(raw).decode("utf-8", "ignore")
            if pn.startswith("_q_") or pn.startswith("fmb") and self._leaf(w):
                continue
            v = w.property(pn)
            if isinstance(v, (bool, int, float, str)) and pn not in ("fmbStyle",):
                P(el, pn, ("true" if v else "false") if isinstance(v, bool) else v, stdset=False)
        sp = w.sizePolicy()
        names = {QSizePolicy.Policy.Fixed: "Fixed", QSizePolicy.Policy.Minimum: "Minimum",
                 QSizePolicy.Policy.Maximum: "Maximum", QSizePolicy.Policy.Preferred: "Preferred",
                 QSizePolicy.Policy.Expanding: "Expanding", QSizePolicy.Policy.MinimumExpanding: "MinimumExpanding",
                 QSizePolicy.Policy.Ignored: "Ignored"}
        default = self._default_policy(w)
        if default is not None and (sp.horizontalPolicy() != default.horizontalPolicy() or
                                    sp.verticalPolicy() != default.verticalPolicy()) and \
                sp.horizontalPolicy() in names and sp.verticalPolicy() in names:
            pe = ET.SubElement(el, "property", name="sizePolicy")
            spe = ET.SubElement(pe, "sizepolicy", hsizetype=names[sp.horizontalPolicy()],
                                vsizetype=names[sp.verticalPolicy()])
            ET.SubElement(spe, "horstretch").text = str(sp.horizontalStretch())
            ET.SubElement(spe, "verstretch").text = str(sp.verticalStretch())
        if isinstance(w, QLabel) and w.pixmap() is not None and not w.pixmap().isNull() and self.pixmap_file:
            pe = ET.SubElement(el, "property", name="pixmap")
            ET.SubElement(pe, "pixmap").text = self.pixmap_file
            P(el, "scaledContents", True)
        if isinstance(w, QListWidget) and w.currentRow() >= 0:
            P(el, "currentRow", w.currentRow(), "number")
        if isinstance(w, QPushButton) and w.isFlat():
            P(el, "flat", True)
        if w.styleSheet():
            # theme arrows point at temporary files on this computer - Designer uses its own arrows
            qss = re.sub(r"\s*image:\s*url\([^)]*\);?", "", w.styleSheet())
            qss = re.sub(r"#([A-Za-z_]\w*)", lambda m: '[fmbStyle="{}"]'.format(m.group(1))
                         if m.group(1) in self.style_names else m.group(0), qss)
            P(el, "styleSheet", qss)
        if self._leaf(w):
            props = getattr(w, "designer_properties", None)
            if props:
                for k, v in props().items():
                    if v not in (None, ""):
                        P(el, k, v, stdset=False)
            if isinstance(w, QAbstractSpinBox):
                self._spin_props(w, el)
            if isinstance(w, QComboBox):
                self._combo_props(w, el)
            return
        if isinstance(w, QGroupBox):
            P(el, "title", w.title())
            if w.isCheckable():
                P(el, "checkable", True)
                P(el, "checked", w.isChecked())
        elif isinstance(w, QLabel):
            P(el, "text", w.text())
            if w.wordWrap():
                P(el, "wordWrap", True)
            if w.openExternalLinks():
                P(el, "openExternalLinks", True)
        elif isinstance(w, QAbstractButton):
            P(el, "text", w.text())
            if w.isCheckable() and not isinstance(w, (QCheckBox, QRadioButton)):
                P(el, "checkable", True)
            if w.isCheckable() and w.isChecked():
                P(el, "checked", True)
            if isinstance(w, QToolButton) and w.autoRaise():
                P(el, "autoRaise", True)
        elif isinstance(w, QLineEdit):
            if w.text():
                P(el, "text", w.text())
            if w.placeholderText():
                P(el, "placeholderText", w.placeholderText())
            if w.isReadOnly():
                P(el, "readOnly", True)
        elif isinstance(w, QComboBox):
            self._combo_props(w, el)
        elif isinstance(w, QAbstractSpinBox):
            self._spin_props(w, el)
        elif isinstance(w, (QPlainTextEdit, QTextEdit)):
            if w.isReadOnly():
                P(el, "readOnly", True)
            if w.placeholderText():
                P(el, "placeholderText", w.placeholderText())
        elif isinstance(w, QTreeWidget):
            if w.isHeaderHidden():
                P(el, "headerHidden", True)
            hi = w.headerItem()
            for c in range(w.columnCount()):
                col = ET.SubElement(el, "column")
                self._p(col, "text", hi.text(c) if hi is not None else "")
        elif isinstance(w, QListWidget):
            ud = Qt.ItemDataRole.UserRole
            for i in range(w.count()):
                it = w.item(i)
                text = it.text().replace("\n", "  -  ")
                section = bool(it.data(ud + 4))
                glyph = it.data(ud + 1)
                if section:
                    text = text.upper()
                elif glyph:                         # workbench sidebar: step glyph / tick
                    text = "{}   {}".format("\u2713" if it.data(ud + 2) == "done" else glyph, text)
                item = ET.SubElement(el, "item")
                self._p(item, "text", text)
                if section:
                    f = ET.SubElement(ET.SubElement(item, "property", name="font"), "font")
                    ET.SubElement(f, "bold").text = "true"
        elif isinstance(w, QProgressBar):
            P(el, "maximum", w.maximum(), "number")
            P(el, "value", w.value(), "number")
            P(el, "textVisible", w.isTextVisible())
        elif isinstance(w, QTableWidget):
            for c in range(w.columnCount()):
                it = w.horizontalHeaderItem(c)
                col = ET.SubElement(el, "column")
                self._p(col, "text", it.text() if it is not None else str(c + 1))
        elif isinstance(w, QSplitter):
            P(el, "orientation", "Qt::Horizontal" if w.orientation() == Qt.Orientation.Horizontal else "Qt::Vertical",
              "enum")
        elif isinstance(w, QScrollArea):
            P(el, "widgetResizable", w.widgetResizable())
        if isinstance(w, QFrame) and not isinstance(w, (QLabel, QAbstractItemView, QPlainTextEdit, QTextEdit,
                                                        QScrollArea, QSplitter, QGroupBox, QStackedWidget)) \
                and type(w).__name__ == "QFrame":
            shape = {QFrame.Shape.StyledPanel: "QFrame::StyledPanel", QFrame.Shape.Box: "QFrame::Box",
                     QFrame.Shape.HLine: "QFrame::HLine", QFrame.Shape.VLine: "QFrame::VLine",
                     QFrame.Shape.Panel: "QFrame::Panel"}.get(w.frameShape())
            if shape:
                P(el, "frameShape", shape, "enum")

    def _combo_props(self, w, el):
        if w.isEditable():
            self._p(el, "editable", True)
        for i in range(w.count()):
            it = ET.SubElement(el, "item")
            self._p(it, "text", w.itemText(i))

    def _spin_props(self, w, el):
        P = self._p
        if isinstance(w, QSpinBox):
            P(el, "minimum", w.minimum(), "number")
            P(el, "maximum", w.maximum(), "number")
            P(el, "value", w.value(), "number")
        elif isinstance(w, QDoubleSpinBox):
            P(el, "decimals", w.decimals(), "number")
            P(el, "minimum", repr(float(w.minimum())), "double")
            P(el, "maximum", repr(float(w.maximum())), "double")
            P(el, "singleStep", repr(float(w.singleStep())), "double")
            P(el, "value", repr(float(w.value())), "double")
        if w.suffix():
            P(el, "suffix", w.suffix())
        if w.prefix():
            P(el, "prefix", w.prefix())
        if w.specialValueText():
            P(el, "specialValueText", w.specialValueText())

    # -- tree ----------------------------------------------------------------------
    def widget(self, w, top=False):
        cls = "QDialog" if top and isinstance(w, QDialog) else ("QWidget" if top else self._class(w))
        if top and isinstance(w, QGroupBox):
            cls = "QGroupBox"
        name = self.class_name if top else self._name(w, cls.lstrip("Q").lower())
        el = ET.Element("widget", {"class": cls, "name": name})
        if top:
            g = ET.SubElement(el, "property", name="geometry")
            r = ET.SubElement(g, "rect")
            for k, v in (("x", 0), ("y", 0), ("width", max(w.width(), 400)), ("height", max(w.height(), 300))):
                ET.SubElement(r, k).text = str(v)
            if w.windowTitle():
                self._p(el, "windowTitle", w.windowTitle())
        self._props(w, el, top)
        if w in self.placeholders:
            lay = ET.SubElement(el, "layout", {"class": "QVBoxLayout", "name": self._name(w, "layout")})
            item = ET.SubElement(lay, "item")
            lab = ET.SubElement(item, "widget", {"class": "QLabel", "name": self._name(w, "placeholder")})
            self._p(lab, "text", self.placeholders[w])
            self._p(lab, "alignment", "Qt::AlignCenter", "set")
            return el
        if self._leaf(w) and not top:
            return el
        if isinstance(w, QTabWidget):
            for i in range(w.count()):
                page = w.widget(i)
                pel = self.widget(page)
                a = ET.SubElement(pel, "attribute", name="title")
                ET.SubElement(a, "string").text = w.tabText(i)
                el.append(pel)
            self._p(el, "currentIndex", 0, "number")
            return el
        if isinstance(w, QStackedWidget):
            for i in range(w.count()):
                el.append(self.widget(w.widget(i)))
            self._p(el, "currentIndex", max(0, w.currentIndex()), "number")
            return el
        if isinstance(w, QSplitter):
            for i in range(w.count()):
                if not self._hidden(w.widget(i)):
                    el.append(self.widget(w.widget(i)))
            return el
        if isinstance(w, QScrollArea):
            if w.widget() is not None:
                el.append(self.widget(w.widget()))
            return el
        if isinstance(w, QAbstractItemView):
            return el
        lay = w.layout()
        if lay is not None:
            el.append(self.layout(lay))
        return el

    def layout(self, lay):
        cls = type(lay).__name__
        if not cls.startswith("Q"):
            for c in type(lay).__mro__:
                if c.__name__ in ("QVBoxLayout", "QHBoxLayout", "QGridLayout", "QFormLayout"):
                    cls = c.__name__
                    break
        if cls == "QBoxLayout":
            cls = "QVBoxLayout" if lay.direction() in (QBoxLayout.Direction.TopToBottom,
                                                        QBoxLayout.Direction.BottomToTop) else "QHBoxLayout"
        el = ET.Element("layout", {"class": cls, "name": self._name(lay, "layout")})
        m = lay.contentsMargins()
        for side, v in (("leftMargin", m.left()), ("topMargin", m.top()), ("rightMargin", m.right()),
                        ("bottomMargin", m.bottom())):
            self._p(el, side, v, "number")
        if lay.spacing() >= 0:
            self._p(el, "spacing", lay.spacing(), "number")
        if isinstance(lay, QBoxLayout):
            st = [lay.stretch(i) for i in range(lay.count())]
            if any(st):
                el.set("stretch", ",".join(str(x) for x in st))
        if isinstance(lay, QGridLayout):
            rs = [lay.rowStretch(r) for r in range(lay.rowCount())]
            cs = [lay.columnStretch(c) for c in range(lay.columnCount())]
            if any(rs):
                el.set("rowstretch", ",".join(str(x) for x in rs))
            if any(cs):
                el.set("columnstretch", ",".join(str(x) for x in cs))
        for i in range(lay.count()):
            item = lay.itemAt(i)
            attrs = {}
            if isinstance(lay, QGridLayout):
                r, c, rs, cs = lay.getItemPosition(i)
                attrs = {"row": str(r), "column": str(c)}
                if rs > 1:
                    attrs["rowspan"] = str(rs)
                if cs > 1:
                    attrs["colspan"] = str(cs)
            elif isinstance(lay, QFormLayout):
                r, role = lay.getItemPosition(i)
                if r < 0:
                    continue
                if role == QFormLayout.ItemRole.SpanningRole:
                    attrs = {"row": str(r), "column": "0", "colspan": "2"}
                else:
                    attrs = {"row": str(r), "column": "0" if role == QFormLayout.ItemRole.LabelRole else "1"}
            child = self._item(item)
            if child is None:
                continue
            it = ET.SubElement(el, "item", attrs)
            it.append(child)
        return el

    def _item(self, item):
        if item.widget() is not None:
            w = item.widget()
            if isinstance(w, QMenu) or self._hidden(w):
                return None
            return self.widget(w)
        if item.layout() is not None:
            return self.layout(item.layout())
        sp = item.spacerItem()
        if sp is not None:
            el = ET.Element("spacer", name=self._name(sp if isinstance(sp, QObject) else QObject(), "spacer"))
            vert = bool(sp.expandingDirections() & Qt.Orientation.Vertical)
            self._p(el, "orientation", "Qt::Vertical" if vert else "Qt::Horizontal", "enum")
            h = sp.sizeHint()
            self._p(el, "sizeHint", (h.width() or (0 if vert else 40), h.height() or (40 if vert else 0)), "size",
                    stdset=False)
            return el
        return None

    def document(self):
        top = self.widget(self.root, top=True)
        ui = ET.Element("ui", version="4.0")
        ET.SubElement(ui, "class").text = self.class_name
        ui.append(top)
        if self.custom:
            cws = ET.SubElement(ui, "customwidgets")
            for name, (base, header) in sorted(self.custom.items()):
                cw = ET.SubElement(cws, "customwidget")
                ET.SubElement(cw, "class").text = name
                ET.SubElement(cw, "extends").text = base
                ET.SubElement(cw, "header").text = header
        ET.SubElement(ui, "resources")
        ET.SubElement(ui, "connections")
        return ui


def export_widget(widget, class_name, path, placeholders=None, pixmap_file=""):
    ex = Exporter(widget, class_name, placeholders)
    ex.pixmap_file = pixmap_file
    ui = ex.document()
    try:
        ET.indent(ui, space=" ")
    except AttributeError:          # Python < 3.9
        pass
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    ET.ElementTree(ui).write(path, encoding="UTF-8", xml_declaration=True)
    return path


PAGE_FILES = [("Dashboard", "01_dashboard"), ("Project", "02_project_domain"), ("Empty layers", "03_gis_layers"),
              ("TCF", "04_control_tcf"), ("TGC", "05_geometry_tgc"), ("TBC", "06_boundaries_tbc"),
              ("ECF", "07_1d_network_ecf"), ("TEF", "08_events_tef"), ("Other files", "09_more_control_files"),
              ("Databases", "10_databases"), ("Batch & Run", "11_batch_run"), ("QC", "12_model_checks"),
              ("Logs", "13_logs"), ("Stability", "14_stability"), ("Outputs", "15_outputs"), ("Help", "16_help")]


def export_all(dialog, folder, include_project=True):
    """Write the whole workbench (fmb_workbench.ui, every page inside - page through it in Designer)
    and one .ui per page, styled like the plugin. Returns the paths."""
    import shutil
    os.makedirs(folder, exist_ok=True)
    icon = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
    pix = ""
    if os.path.isfile(icon):
        shutil.copy(icon, os.path.join(folder, "icon.png"))
        pix = "icon.png"
    out = [export_widget(dialog, "FmbWorkbench", os.path.join(folder, "fmb_workbench.ui"), pixmap_file=pix)]
    qss = dialog.styleSheet()
    tabs = dialog.tabs
    for key, fname in PAGE_FILES:
        i = tabs.find(key)
        if i < 0:
            continue
        host = tabs.pages()[i]["host"]
        old_qss, old_name = host.styleSheet(), host.objectName()
        host.setStyleSheet(qss)              # each page carries the theme on its own
        host.setObjectName("FmbMain")
        try:
            out.append(export_widget(host, "Page_" + fname[3:], os.path.join(folder, fname + ".ui")))
        finally:
            host.setObjectName(old_name)
            host.setStyleSheet(old_qss)
    try:
        from .folders_dialog import FolderStructureDialog
        dlg = FolderStructureDialog("", dialog)
        dlg.setStyleSheet(qss)
        dlg.setObjectName("FmbMain")
        out.append(export_widget(dlg, "FolderStructureDialog", os.path.join(folder, "17_folder_structure_dialog.ui")))
        dlg.deleteLater()
    except Exception:
        pass
    return out
