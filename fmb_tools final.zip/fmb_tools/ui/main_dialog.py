# -*- coding: utf-8 -*-
"""Main window of the FMB tools plugin."""
import os

from qgis.PyQt.QtCore import Qt, QSettings, QEvent
from qgis.PyQt.QtGui import QIcon, QPixmap, QKeySequence
from qgis.PyQt.QtWidgets import (QDialog, QFrame, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel, QPushButton, QMessageBox,
                                 QFormLayout, QDialogButtonBox, QWidget)
try:
    from qgis.PyQt.QtWidgets import QShortcut
except ImportError:                     # Qt6: QShortcut lives in QtGui
    from qgis.PyQt.QtGui import QShortcut

from ..core.catalog import FILE_TYPE_INFO
from ..core.control_file import Entry, to_tuflow_path
from ..core.catalog import catalog
from ..core.project import TuflowProject
from . import qgis_utils as qu
from .control_file_editor import ControlFileEditor
from .tabs import ProjectTab, DatabaseTab, BatchTab, QcTab, LogsTab, ResultsTab, HelpTab, EventWizard
from .widgets import PathEdit, qexec
from .empty_tab import EmptyLayersTab
from .outputs_tab import OutputsTab
from .shell import NavShell
from .dashboard import DashboardPage, add_recent

MAIN_TABS = ["TCF", "TGC", "TBC", "ECF", "TEF"]
OTHER_TABS = ["QCF", "TRFC", "TOC", "TESF", "TSCF", "ADCF"]
TAB_TITLES = {"TCF": "TCF", "TGC": "TGC", "TBC": "TBC", "ECF": "ECF (1D)",
              "TEF": "TEF", "QCF": "QCF (quadtree)", "TRFC": "TRFC (rainfall)", "TOC": "TOC (operations)",
              "TESF": "TESF (wind)", "TSCF": "TSCF (SWMM)", "ADCF": "ADCF (AD)"}
PAGE_TITLES = {"TCF": "Control (TCF)", "TGC": "Geometry (TGC)", "TBC": "Boundaries (TBC)", "ECF": "1D network (ECF)",
               "TEF": "Events (TEF)"}


class MainDialog(QDialog):
    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        qu.set_iface(iface)
        self.setWindowTitle("FMB tools")
        # a normal application window: minimise / maximise buttons and its own taskbar entry
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowTitleHint | Qt.WindowType.WindowSystemMenuHint |
                            Qt.WindowType.WindowMinMaxButtonsHint | Qt.WindowType.WindowCloseButtonHint)
        icon = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        self.setWindowIcon(QIcon(icon))
        self.resize(1480, 900)
        geo = QSettings().value("fmb_tools/geometry")
        if geo is not None:
            try:
                self.restoreGeometry(geo)
            except Exception:
                pass
        self.project = None
        self.dir_override = {}
        self.editors = {}
        self._build()

    # ------------------------------------------------------------------ UI
    def _build(self):
        self.setObjectName("FmbMain")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self._header())
        self.tabs = NavShell("FMB tools", "TUFLOW model builder")
        icon = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        if os.path.isfile(icon):
            self.tabs.logo.setPixmap(QPixmap(icon).scaled(30, 30, Qt.AspectRatioMode.KeepAspectRatio,
                                                         Qt.TransformationMode.SmoothTransformation))
        lay.addWidget(self.tabs, 1)
        T = self.tabs

        T.add_section("Home")
        self.dashboard = None
        self._dash_host = QWidget()               # the dashboard needs the other pages - built at the end
        QVBoxLayout(self._dash_host).setContentsMargins(0, 0, 0, 0)
        T.addTab(self._dash_host, "Dashboard", "Dashboard", "\u2302", "Model overview, build progress and next steps",
                 header=False)

        T.add_section("Build")
        self.project_tab = ProjectTab()
        self.project_tab.newModelRequested.connect(self.new_model)
        self.project_tab.openModelRequested.connect(self.open_model)
        self.project_tab.saveAllRequested.connect(self.save_all)
        self.project_tab.showTab.connect(self.show_tab)
        T.addTab(self.project_tab, "Project & domain", "Project", "1",
                 "Model name, solver, cell size and the 2D domain drawn on the map")
        self.empty_tab = EmptyLayersTab(self)
        self.empty_tab.commandsReady.connect(self.add_read_commands)
        T.addTab(self.empty_tab, "GIS layers", "Empty layers", "2",
                 "Create TUFLOW empty GIS layers (GeoPackage / Shapefile) ready to draw in")
        glyphs = {"TCF": "3", "TGC": "4", "TBC": "5", "ECF": "6", "TEF": "7"}
        for ft in MAIN_TABS:
            ed = self._make_editor(ft)
            tip = "{} - {}".format(FILE_TYPE_INFO[ft][0], FILE_TYPE_INFO[ft][1])
            if ft == "TEF":
                host = QWidget()
                hl = QVBoxLayout(host)
                hl.setContentsMargins(0, 0, 0, 0)
                self.event_wizard = EventWizard()
                self.event_wizard.generate.connect(self._add_events)
                hl.addWidget(self.event_wizard)
                hl.addWidget(ed, 1)
                self.tef_host = host
                T.addTab(host, PAGE_TITLES[ft], ft, glyphs[ft], tip, header=False)
            else:
                T.addTab(ed, PAGE_TITLES[ft], ft, glyphs[ft], tip, header=False)     # the editor has its own title bar
        self.other_tabs = QTabWidget()
        for ft in OTHER_TABS:
            self.other_tabs.addTab(self._make_editor(ft), TAB_TITLES[ft])
        T.addTab(self.other_tabs, "More control files", "Other files", "8",
                 "Quadtree, rainfall, operations, wind, SWMM and advection-dispersion control files")
        self.db_tab = DatabaseTab()
        T.addTab(self.db_tab, "Databases", "Databases", "9", "bc_dbase.csv, materials.csv and time-series tables")

        T.add_section("Run")
        self.batch_tab = BatchTab()
        self.batch_tab.names_fn = lambda kind: self.project.names(kind) if self.project is not None else []
        self.batch_tab.runsFinished.connect(self._after_runs)
        T.addTab(self.batch_tab, "Batch & run", "Batch & Run", "\u25b6",
                 "Batch files for every scenario / event, or run from QGIS")

        T.add_section("Check")
        self.qc_tab = QcTab(self)
        T.addTab(self.qc_tab, "Model checks (QC)", "QC", "Q", "Pre-run checks and TUFLOW check files")
        self.logs_tab = LogsTab(self)
        T.addTab(self.logs_tab, "Logs", "Logs", "L", "Colour-coded .tlf / .hpc.tlf logs and messages")
        self.results_tab = ResultsTab(self)
        T.addTab(self.results_tab, "Stability", "Stability", "S",
                 "Run status, mass error and HPC timestep checks with charts")

        T.add_section("Results")
        self.outputs_tab = OutputsTab(self)
        T.addTab(self.outputs_tab, "Outputs", "Outputs", "R",
                 "Tick result grids, meshes, plot output and check files to load them in QGIS")

        T.add_section("Help")
        self.help_tab = HelpTab()
        T.addTab(self.help_tab, "Help & guides", "Help", "?", "Explained commands, manual and wiki links")
        T.currentChanged.connect(self._tab_changed)
        T.foot.setText("Ctrl+K search \u00b7 Ctrl+S save \u00b7 F5 check \u00b7 Ctrl+B sidebar")

        bar = QFrame()
        bar.setObjectName("FmbStatus")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(12, 4, 8, 4)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        bl.addWidget(self.status, 1)
        for text, slot, tip in (
                ("New Project", self.new_project, "Close the current model and start the quick set-up of a new one"),
                ("Reset All", self.reset_all, "Discard unsaved changes and reset every tab to its defaults"),
                ("Close Project", self.close_project, "Close the current model (asks to save changes)")):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            bl.addWidget(b)
        lay.addWidget(bar)

        self.dashboard = DashboardPage(self)
        self._dash_host.layout().addWidget(self.dashboard)
        self._shortcuts()
        self.apply_theme()

        last = QSettings().value("fmb_tools/last_tcf", "")
        exe = QSettings().value("fmb_tools/exe", "")
        if exe:
            self.batch_tab.exe.setValue(exe)
        if last and os.path.isfile(last):
            self.status.setText("Last model: {}".format(last))
            self.project_tab.set_last(last)
        self._update_title()

    def _header(self):
        head = QFrame()
        head.setObjectName("FmbHeader")
        hl = QHBoxLayout(head)
        hl.setContentsMargins(18, 10, 14, 10)
        hl.setSpacing(10)
        names = QVBoxLayout()
        names.setSpacing(1)
        top = QHBoxLayout()
        top.setSpacing(8)
        self.title = QLabel("No model open")
        self.title.setObjectName("ModelName")
        top.addWidget(self.title)
        self.chips = []
        for _i in range(4):
            c = QLabel("")
            c.setProperty("chip", "true")
            c.hide()
            top.addWidget(c)
            self.chips.append(c)
        top.addStretch(1)
        names.addLayout(top)
        self.subtitle = QLabel("Start with a new model or open an existing .tcf")
        self.subtitle.setObjectName("ModelPath")
        names.addWidget(self.subtitle)
        hl.addLayout(names, 1)
        self.search_btn = QPushButton("\U0001F50D  Search pages, actions, commands...   Ctrl+K")
        self.search_btn.setObjectName("SearchButton")
        self.search_btn.clicked.connect(self.open_palette)
        hl.addWidget(self.search_btn)
        for text, slot, tip, attr in (("Run QC", self.run_qc, "Check the model now (F5)", "qc_btn"),
                                      ("Test run", self.run_test, "TUFLOW test mode (-t): read inputs, write check "
                                                                  "files, no simulation", "test_btn"),
                                      ("Run \u25b6", self.run_now, "Run the simulation(s) set in Batch & Run",
                                       "run_btn")):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            setattr(self, attr, b)
            hl.addWidget(b)
        self.save_btn = QPushButton("Save")
        self.save_btn.setProperty("primary", True)
        self.save_btn.setToolTip("Save every control file of the model (Ctrl+S)")
        self.save_btn.clicked.connect(lambda: self.save_all())
        hl.addWidget(self.save_btn)
        return head

    def _shortcuts(self):
        for seq, slot in (("Ctrl+K", self.open_palette), ("Ctrl+S", lambda: self.save_all()),
                          ("F5", self.run_qc), ("Ctrl+B", lambda: self.tabs.set_collapsed(not self.tabs.collapsed)),
                          ("Ctrl+H", lambda: self.go("Dashboard"))):
            sc = QShortcut(QKeySequence(seq), self)
            sc.activated.connect(slot)

    def apply_theme(self):
        from .theme import stylesheet
        self.setStyleSheet(stylesheet(self.palette()))

    def changeEvent(self, ev):
        if ev.type() == QEvent.Type.PaletteChange and not getattr(self, "_theming", False):
            self._theming = True          # follow a QGIS light / dark theme switch
            try:
                self.apply_theme()
            finally:
                self._theming = False
        super().changeEvent(ev)

    # -------------------------------------------------------- navigation API
    def go(self, key):
        """Show a page by key ('Dashboard', 'Project', 'TGC', 'QC' ...)."""
        if key in self.editors:
            self.show_tab(key)
            return
        i = self.tabs.find(key)
        if i >= 0:
            self.tabs.setCurrentIndex(i)

    def page_title(self, key):
        i = self.tabs.find(key)
        return self.tabs.title(i) if i >= 0 else key

    def update_badges(self, steps, findings=None):
        from ..core import workflow as WF
        self.tabs.clear_states()
        if self.project is None:
            return
        for page, state in WF.page_states(steps).items():
            if page in ("Project", "TGC", "TBC", "ECF", "TEF", "TCF", "Batch & Run", "Outputs"):
                self.tabs.set_state(page, state)
        if findings is not None:
            ne = sum(1 for f in findings if f.severity == "ERROR")
            nw = sum(1 for f in findings if f.severity == "WARNING")
            self.tabs.set_state("QC", "error" if ne else ("warn" if nw else "done"), str(ne or nw) if ne or nw else "")
        self.tabs.nav.viewport().update()

    def open_palette(self):
        from .shell import CommandPalette
        entries = []
        for pg in self.tabs.pages():
            entries.append(("Go to: " + pg["title"], "Page - " + (pg["item"].toolTip() or ""),
                            lambda k=pg["key"]: self.go(k), 0))
        for ft in OTHER_TABS:
            entries.append(("Go to: {}".format(TAB_TITLES[ft]), "Page - more control files",
                            lambda f=ft: self.show_tab(f), 1))
        for title, fn, sub in (
                ("New model", self.new_project, "Action - start the quick set-up"),
                ("Open existing .tcf", self.project_tab._open, "Action"),
                ("Save all control files", lambda: self.save_all(), "Action - Ctrl+S"),
                ("Run model checks (QC)", self.run_qc, "Action - F5"),
                ("Test run (-t)", self.run_test, "Action - read inputs and write check files only"),
                ("Run simulation", self.run_now, "Action"),
                ("Draw the 2D domain on the map (area polygon)", lambda: self._go_draw("polygon"), "Action - Project"),
                ("Draw a rotated domain rectangle (3 clicks)", lambda: self._go_draw("rect3"), "Action - Project"),
                ("Create TUFLOW folder structure", self.project_tab.create_folders, "Action"),
                ("Load model inputs to map", self._load_inputs, "Action - all GIS layers the model reads"),
                ("Create empty GIS layers", lambda: self.go("Empty layers"), "Action - GIS layers"),
                ("Write batch file", self._save_batch, "Action - Batch & run"),
                ("Toggle sidebar", lambda: self.tabs.set_collapsed(not self.tabs.collapsed), "Action - Ctrl+B")):
            entries.append((title, sub, fn, 1))
        from ..core.catalog import catalog
        from ..core.essentials import ESSENTIALS
        from ..core.explanations import explain_spec
        cat = catalog()
        for ft in ("TCF", "TGC", "TBC", "ECF", "TEF") + tuple(OTHER_TABS):
            ess = {k.lower() for _g, cmds in ESSENTIALS.get(ft, []) for k, *_r in cmds}
            for spec in cat.specs(ft):
                brief = explain_spec(spec)
                entries.append(("{}  \u203a  {}".format(ft, spec.name),
                                "Command - " + (brief[:140] if brief else spec.syntax[:110]),
                                lambda f=ft, n=spec.name: self.goto_command(f, n),
                                2 if spec.key.lower() in ess or spec.name.lower() in ess else 3))
        self._palette = CommandPalette(entries, self)
        self._palette.setStyleSheet(self._palette.styleSheet())
        self._palette.popup(self.search_btn)

    def goto_command(self, ftype, name):
        """Open a control-file page and select a command in its browser."""
        self.show_tab(ftype)
        ed = self.editors.get(ftype)
        if ed is None:
            return
        ed.search.setText(name)
        stack = [ed.tree.topLevelItem(i) for i in range(ed.tree.topLevelItemCount())]
        while stack:
            it = stack.pop(0)
            if (it.data(0, Qt.ItemDataRole.UserRole) or "").lower() == name.lower() and not it.isHidden():
                ed.tree.setCurrentItem(it)
                ed.tree.scrollToItem(it)
                break
            stack += [it.child(j) for j in range(it.childCount())]
        ed.focus_command(name)

    def go_step(self, step):
        """Dashboard 'Open' / 'Go to': jump to the page - and to the command - that finishes a step."""
        if step.command and step.page in self.editors:
            self.goto_command(step.page, step.command)
        else:
            self.go(step.page)

    def _go_draw(self, mode):
        self.go("Project")
        self.project_tab.start_draw(mode)

    def _load_inputs(self):
        if self.project is None:
            QMessageBox.information(self, "Model inputs", "Open or create a model first.")
            return
        self.dashboard.load_inputs()

    def _save_batch(self):
        self.go("Batch & Run")
        self.batch_tab.save_batch()

    def run_now(self):
        if self.project is None:
            QMessageBox.information(self, "Run", "Open or create a model first.")
            return
        self._sync_batch()
        self.save_all(quiet=True)
        self.go("Batch & Run")
        self.batch_tab.run_now()

    def _make_editor(self, ft):
        ed = ControlFileEditor(ft)
        ed.createRequested.connect(self.create_control_file)
        ed.openChildRequested.connect(self.open_child)
        ed.openDatabaseRequested.connect(self.open_database)
        ed.fileReplaced.connect(self._file_replaced)
        ed.changed.connect(self._update_title)
        ed.names_fn = self.model_names
        self.editors[ft] = ed
        return ed

    # --------------------------------------------------------- context API
    def current_project(self):
        return self.project

    def model_names(self, kind):
        """Names offered in the value dropdowns (scenarios, events, BC names, material IDs)."""
        names = list(self.project.names(kind)) if self.project is not None else []
        if kind in ("scenarios", "events") and hasattr(self, "batch_tab"):
            cfg = self.batch_tab.config()
            for slot in (cfg.scenarios if kind == "scenarios" else cfg.events):
                for v in slot:
                    if v not in names:
                        names.append(v)
        return names

    def dirs(self):
        """(results, check, log) folders."""
        if self.project is None:
            return "", "", ""
        res, chk, log = self.project.output_dirs()
        return (self.dir_override.get("results", res), self.dir_override.get("check", chk),
                self.dir_override.get("log", log))

    def edit_dirs(self):
        d = QDialog(self)
        d.setWindowTitle("Output folders")
        f = QFormLayout(d)
        res, chk, log = self.dirs()
        edits = {}
        for key, val in (("results", res), ("check", chk), ("log", log)):
            pe = PathEdit("folder", "", lambda: "")
            pe.setValue(val)
            edits[key] = pe
            f.addRow(key.title(), pe)
        f.addRow(QLabel("<i>Folders are read from the TCF; override them here if you use ~s~/~e~ sub-folders.</i>"))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        f.addRow(bb)
        if qexec(d):
            for k, pe in edits.items():
                self.dir_override[k] = pe.value().rstrip("\\/")
            self.logs_tab.refresh()
            self.results_tab.refresh()
            self.qc_tab.refresh_sims()

    def batch_first(self):
        return self.batch_tab.first_scenarios_events()

    def run_test(self):
        self._sync_batch()
        self.save_all(quiet=True)
        self.tabs.setCurrentWidget(self.batch_tab)
        self.batch_tab.run_test()

    # ------------------------------------------------------------- project
    def set_project(self, project):
        self.project = project
        self.dir_override = {}
        for ft, ed in self.editors.items():
            ed.set_control_file(project.files.get(ft) if project else None)
        if project:
            tcf = project.files.get("TCF")
            self.batch_tab.set_config(project.state.get("batch", {}))
            if tcf:
                self.batch_tab.set_tcf(tcf.path)
                QSettings().setValue("fmb_tools/last_tcf", tcf.path)
                add_recent(tcf.path)
            self.empty_tab.set_project(project)
        self._refresh_databases()
        self._update_title()
        if getattr(self, "dashboard", None) is not None:
            self.dashboard.schedule()

    def new_model(self, opts):
        root = self.project_tab.root.value().strip()
        prj = TuflowProject(root, opts["name"])
        tcf_path = prj.default_path("TCF")
        if os.path.exists(tcf_path) and QMessageBox.question(
                self, "New model", "{} already exists. Overwrite the control files?".format(tcf_path)) \
                != QMessageBox.StandardButton.Yes:
            return
        try:
            prj.create_folders()
            if opts.get("write_loc") or opts.get("area_points"):
                try:
                    prj.write_domain_layers(opts)
                except Exception as ex:       # fall back to Origin / Orientation in the TGC
                    QMessageBox.warning(self, "New model", "Could not write the 2d_loc / 2d_code layers ({}).\n"
                                        "The TGC uses Origin / Orientation instead.".format(ex))
            prj.new_from_template(opts)
            prj.write_databases(overwrite=False, direct_rainfall=opts.get("direct_rainfall"))
            if opts.get("events"):
                prj.state["batch"] = {"events": [opts["events"]] + [[]] * 8}
            prj.save_all()
        except Exception as ex:
            QMessageBox.critical(self, "New model", "Could not create the model:\n{}".format(ex))
            return
        self.set_project(prj)
        self.go("Dashboard")
        self.dashboard.refresh()
        qu.message("Model created in {}".format(root), "success")

    def open_model(self, path):
        try:
            prj = TuflowProject.from_tcf(path)
        except Exception as ex:
            QMessageBox.critical(self, "Open", "Could not read {}:\n{}".format(path, ex))
            return
        self.set_project(prj)
        missing = [ft for ft, cf in prj.files.items() if cf.path and not os.path.isfile(cf.path)]
        if missing:
            QMessageBox.warning(self, "Open", "These referenced control files were not found (tabs are empty "
                                              "until saved):\n" + "\n".join(prj.files[m].path for m in missing))
        self.go("Dashboard")
        self.dashboard.refresh()

    def create_control_file(self, ftype):
        if self.project is None:
            QMessageBox.information(self, "Create", "Create or open a model in the Project tab first.")
            self.tabs.setCurrentWidget(self.project_tab)
            return
        if ftype == "TCF":
            return
        self.project.ensure(ftype)
        self.project.link_child(ftype)
        parent = "ECF" if ftype == "TOC" else "TCF"
        self.editors[parent].set_control_file(self.project.files[parent])
        self.editors[parent].dirty = True
        self.editors[ftype].set_control_file(self.project.files[ftype])
        self.editors[ftype].dirty = True
        self._update_title()

    def open_child(self, ftype):
        if self.project is None:
            return
        if ftype not in self.project.files:
            self.create_control_file(ftype)
        self.show_tab(ftype)

    def show_tab(self, name):
        if name in self.editors:
            ed = self.editors[name]
            if name in OTHER_TABS:
                self.tabs.setCurrentWidget(self.other_tabs)
                self.other_tabs.setCurrentWidget(ed)
            elif name == "TEF":
                self.tabs.setCurrentWidget(self.tef_host)
            else:
                self.tabs.setCurrentWidget(ed)
            return
        i = self.tabs.find(name)
        if i >= 0:
            self.tabs.setCurrentIndex(i)

    def open_database(self, path):
        self.tabs.setCurrentWidget(self.db_tab)
        self.db_tab.load(path)

    def _file_replaced(self, ftype):
        ed = self.editors[ftype]
        if self.project is None:
            self.project = TuflowProject(os.path.dirname(os.path.dirname(ed.cf.path)),
                                         os.path.splitext(os.path.basename(ed.cf.path))[0])
        self.project.files[ftype] = ed.cf
        if ftype == "TCF":
            self.project.discover_children()
            self.set_project(self.project)
        else:
            parent_t = "ECF" if ftype == "TOC" else "TCF"
            parent = self.project.files.get(parent_t)
            cmd = FILE_TYPE_INFO[ftype][2]
            if parent is not None and cmd:
                parent.set_value(cmd, to_tuflow_path(ed.cf.path, os.path.dirname(parent.path)))
                self.editors[parent_t].set_control_file(parent)
                self.editors[parent_t].dirty = True
        self._update_title()

    def _add_events(self, events):
        if self.project is None or "TEF" not in self.project.files:
            self.create_control_file("TEF")
            if self.project is None:
                return
        tef = self.project.files["TEF"]
        existing = set(self.project.events_defined())
        cat = catalog()
        for name, sources in events:
            if name in existing:
                continue
            tef.entries.append(Entry("blank"))
            s, ch = cat.match("TEF", "Define Event")
            tef.entries.append(Entry("command", lhs="Define Event", value=name, spec=s, choices=ch))
            for text, val in sources:
                s, ch = cat.match("TEF", "BC Event Source")
                tef.entries.append(Entry("command", lhs="BC Event Source", value="{} | {}".format(text, val),
                                         spec=s, choices=ch))
            s, ch = cat.match("TEF", "End Define")
            tef.entries.append(Entry("command", lhs="End Define", value="", spec=s, choices=ch))
        self.editors["TEF"].set_control_file(tef)
        self.editors["TEF"].dirty = True
        self.batch_tab.refresh_names()
        self._update_title()

    def add_read_commands(self, cmds):
        """Add Read GIS commands (from the Empty layers tab) to the control files.
        An existing command of the same kind with no value is filled in; exact duplicates are skipped."""
        if self.project is None or not cmds:
            return
        added = []
        for ftype, lhs, value in cmds:
            if ftype not in self.project.files:
                self.create_control_file(ftype)
            cf = self.project.files.get(ftype)
            if cf is None:
                continue
            spec, ch = catalog().match(ftype, lhs)
            same = [e for e in cf.commands() if " ".join(e.lhs.lower().split()) == lhs.lower()]
            if any(e.value.strip().lower() == value.lower() for e in same):
                continue
            blank = [e for e in same if not e.value.strip()]
            if blank:
                blank[0].value = value
            else:
                entry = Entry("command", lhs=lhs, value=value, spec=spec, choices=ch or [])
                pos = len(cf.entries)
                if lhs in ("Read GIS Location",):
                    # grid location must come before the grid size / cell size commands
                    first = [i for i, e in enumerate(cf.entries) if e.kind == "command"]
                    pos = first[0] if first else pos
                if ftype == "TCF":
                    ev = [i for i, e in enumerate(cf.entries) if e.kind == "command" and e.key == "Event File"]
                    if ev:
                        pos = ev[-1]
                        while pos > 0 and cf.entries[pos - 1].kind in ("comment", "blank"):
                            pos -= 1
                cf.entries.insert(pos, entry)
            added.append("{}: {}".format(ftype, lhs))
            ed = self.editors.get(ftype)
            if ed is not None:
                ed.set_control_file(cf)
                ed.dirty = True
        self._update_title()
        if added:
            self.status.setText("Added {} Read GIS command(s) - Save all to write them: {}".format(
                len(added), "; ".join(added)))

    def _sync_batch(self):
        if self.project is not None:
            cfg = self.batch_tab.config()
            self.project.state["batch"] = cfg.to_dict()
            self.project.state["scenarios"] = [v[0] for v in cfg.scenarios if v]
            self.project.state["events"] = [v[0] for v in cfg.events if v]
            QSettings().setValue("fmb_tools/exe", cfg.exe)

    def save_all(self, quiet=False):
        if self.project is None:
            if not quiet:
                QMessageBox.information(self, "Save", "No model loaded.")
            return
        self._sync_batch()
        try:
            saved = self.project.save_all()
        except Exception as ex:
            QMessageBox.critical(self, "Save", "Could not save:\n{}".format(ex))
            return
        for ed in self.editors.values():
            if ed.cf is not None:
                ed.dirty = False
                ed.path_label.setText(ed.cf.path)
        self._update_title()
        self._refresh_databases()
        self.dashboard.schedule(300)
        if not quiet:
            qu.message("Saved {} control files".format(len(saved)), "success", 3)
            self.status.setText("Saved: " + ", ".join(os.path.basename(s) for s in saved))

    def run_qc(self):
        self._sync_batch()
        self.tabs.setCurrentWidget(self.qc_tab)
        self.qc_tab.run_checks()
        findings = getattr(self.qc_tab, "_findings", None)
        if findings is not None:
            self.dashboard.findings = findings
            self.update_badges(self.dashboard.steps, findings)

    def _refresh_databases(self):
        items = []
        if self.project is not None:
            from ..core.control_file import resolve_path
            for ft, cf in self.project.files.items():
                for e in cf.commands():
                    if e.spec is not None and e.spec.database and e.value.strip():
                        p = resolve_path(e.value.split("|")[0].split(">>")[0], os.path.dirname(cf.path))
                        items.append(("{} ({})".format(e.spec.key, ft), p))
        self.db_tab.set_known(items)

    def _update_title(self):
        for c in self.chips:
            c.hide()
        if self.project is None:
            self.title.setText("No model open")
            self.subtitle.setText("Start with a new model or open an existing .tcf  (Dashboard \u2192 New model)")
            self.setWindowTitle("FMB tools")
            for b in (self.qc_btn, self.test_btn, self.run_btn, self.save_btn):
                b.setEnabled(False)
            return
        for b in (self.qc_btn, self.test_btn, self.run_btn, self.save_btn):
            b.setEnabled(True)
        p = self.project
        dirty = [ft for ft, ed in self.editors.items() if ed.dirty and ed.cf is not None]
        self.title.setText(p.name)
        self.subtitle.setText(p.root)
        self.setWindowTitle("FMB tools - {}".format(p.name))
        tcf, tgc = p.files.get("TCF"), p.files.get("TGC")
        chips = []
        solver = ((tcf.value("Solution Scheme") if tcf else None) or "CLASSIC").strip()
        hw = ((tcf.value("Hardware") if tcf else None) or "CPU").strip()
        chips.append(("{} \u00b7 {}".format(solver.upper(), hw.upper()) if solver.upper().startswith("HPC")
                      else solver.upper(), "true"))
        cell = (tgc.value("Cell Size") if tgc else None) or ""
        if cell.strip():
            chips.append(("{} m cells".format(cell.strip()), "true"))
        evs = p.events_defined()
        if evs:
            chips.append(("{} event{}".format(len(evs), "s" if len(evs) != 1 else ""), "true"))
        if dirty:
            chips.append(("unsaved: " + ", ".join(dirty), "warn"))
        for c, (text, kind) in zip(self.chips, chips):
            c.setText(text)
            c.setProperty("chip", kind)
            c.style().unpolish(c)
            c.style().polish(c)
            c.show()
        self.project_tab.show_project(self.project, self.editors)

    def _tab_changed(self, _i):
        w = self.tabs.currentWidget()
        if w is self._dash_host and self.dashboard is not None:
            self.dashboard.refresh()
        elif w is self.db_tab:
            self._refresh_databases()
        elif w is self.logs_tab:
            self.logs_tab.refresh()
        elif w is self.results_tab:
            self.results_tab.refresh()
        elif w is self.outputs_tab:
            self.outputs_tab.refresh()
        elif w is self.qc_tab:
            self.qc_tab.refresh_sims()
        elif w is self.batch_tab and self.project and self.project.files.get("TCF"):
            self.batch_tab.set_tcf(self.project.files["TCF"].path)
            self.batch_tab.refresh_names()
        elif w is self.project_tab:
            self.project_tab.refresh_layers()
            self._update_title()

    def _after_runs(self):
        self.dashboard.schedule()
        self.logs_tab.refresh()
        self.results_tab.refresh()
        self.qc_tab.refresh_sims()

    # ------------------------------------------------------ project actions
    def _dirty(self):
        return [ft for ft, ed in self.editors.items() if ed.dirty and ed.cf is not None]

    def _confirm_unsaved(self, what="continue"):
        """Ask to save unsaved edits. Returns False if the user cancels."""
        dirty = self._dirty()
        if not dirty:
            return True
        r = QMessageBox.question(self, "FMB tools", "Save changes to {} before you {}?".format(", ".join(dirty), what),
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No |
                                 QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Cancel:
            return False
        if r == QMessageBox.StandardButton.Yes:
            self.save_all(quiet=True)
        return True

    def _clear_tabs(self):
        self.batch_tab.set_config({})
        self.batch_tab.tcf.setValue("")
        self.batch_tab.tcf_default = ""
        self.batch_tab.console.clear()
        self.qc_tab.table.setRowCount(0)
        self.qc_tab.summary.setText("")
        self.qc_tab.sim.clear()
        self.qc_tab.files.clear()
        self.logs_tab.refresh()
        self.results_tab.refresh()
        self.outputs_tab.clear()
        self.db_tab.path = ""
        self.db_tab.table.setRowCount(0)
        self.db_tab.table.setColumnCount(0)
        self.db_tab.msg.setText("")
        self.db_tab.set_known([])

    def close_project(self, ask=True):
        if self.project is None:
            self.status.setText("No model is open.")
            return True
        if ask and not self._confirm_unsaved("close the model"):
            return False
        if self.batch_tab.runner.running:
            self.batch_tab.runner.stop()
        name = self.project.name
        self.set_project(None)
        self.dir_override = {}
        self._clear_tabs()
        self.empty_tab.reset()
        self.project_tab.show_project(None, self.editors)
        self.go("Dashboard")
        self.dashboard.refresh()
        self.status.setText("Closed {}.".format(name))
        return True

    def new_project(self):
        if not self.close_project():
            return
        self.project_tab.reset_form()
        self.tabs.setCurrentWidget(self.project_tab)
        self.project_tab.root.line.setFocus()
        self.status.setText("New project: choose a root folder, fill in the quick set-up and press "
                            "'Create new model'.")

    def reset_all(self):
        if QMessageBox.question(self, "Reset All", "Discard all unsaved changes and reset every tab to its "
                                                   "defaults?") != QMessageBox.StandardButton.Yes:
            return
        self.close_project(ask=False)
        self.project_tab.reset_form()
        self.empty_tab.reset()
        self.tabs.setCurrentWidget(self.project_tab)
        self.status.setText("Everything has been reset.")

    def reject(self):
        """Esc must not hide the whole workbench (QDialog would) - close it with the window's X."""
        pass

    def closeEvent(self, ev):
        dirty = [ft for ft, ed in self.editors.items() if ed.dirty and ed.cf is not None]
        if dirty:
            r = QMessageBox.question(self, "FMB tools",
                                     "Save changes to {} before closing?".format(", ".join(dirty)),
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No |
                                     QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel:
                ev.ignore()
                return
            if r == QMessageBox.StandardButton.Yes:
                self.save_all(quiet=True)
        if self.batch_tab.runner.running:
            if QMessageBox.question(self, "FMB tools", "Simulations are running. Stop them?") \
                    == QMessageBox.StandardButton.Yes:
                self.batch_tab.runner.stop()
        self.project_tab.cleanup()
        QSettings().setValue("fmb_tools/geometry", self.saveGeometry())
        ev.accept()
