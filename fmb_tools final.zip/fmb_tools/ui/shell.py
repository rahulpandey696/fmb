# -*- coding: utf-8 -*-
"""
Window shell: a workflow sidebar with step badges + stacked pages, and a command palette.

NavShell keeps the small part of the QTabWidget API the rest of the plugin uses
(addTab, setCurrentWidget, currentWidget, indexOf, tabText, count ...), so pages do not
need to know they live in a sidebar instead of tabs.
"""
from qgis.PyQt.QtCore import Qt, pyqtSignal, QSize, QRect, QRectF, QEvent
from qgis.PyQt.QtGui import QColor, QFont, QPen, QBrush, QPainter, QFontMetrics, QPalette, QKeySequence
from qgis.PyQt.QtWidgets import (QWidget, QFrame, QHBoxLayout, QVBoxLayout, QLabel, QListWidget, QListWidgetItem,
                                 QStackedWidget, QToolButton, QStyledItemDelegate, QStyle, QStyleOptionViewItem,
                                 QDialog, QLineEdit, QApplication, QAbstractItemView)

from .theme import STATE_COLORS, colors

ROLE_KEY = Qt.ItemDataRole.UserRole
ROLE_GLYPH = Qt.ItemDataRole.UserRole + 1
ROLE_STATE = Qt.ItemDataRole.UserRole + 2
ROLE_BADGE = Qt.ItemDataRole.UserRole + 3
ROLE_SECTION = Qt.ItemDataRole.UserRole + 4
ROLE_SUB = Qt.ItemDataRole.UserRole + 6


def _flags(*values):
    out = 0
    for v in values:
        out |= int(getattr(v, "value", v))
    return out


class NavDelegate(QStyledItemDelegate):
    """Sidebar item: round step glyph, title and a state badge (done / warning / error / count)."""

    def __init__(self, shell):
        super().__init__(shell.nav)
        self.shell = shell

    def sizeHint(self, option, index):
        if index.data(ROLE_SECTION):
            return QSize(10, 26 if not self.shell.collapsed else 10)
        return QSize(10, 36)

    def paint(self, p, option, index):
        c = colors()
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = option.rect
        if index.data(ROLE_SECTION):
            if not self.shell.collapsed:
                f = QFont(option.font)
                f.setPointSizeF(max(6.5, f.pointSizeF() * 0.82))
                f.setBold(True)
                f.setLetterSpacing(QFont.SpacingType.PercentageSpacing, 108)
                p.setFont(f)
                p.setPen(c["muted"])
                p.drawText(r.adjusted(16, 6, -8, 0), _flags(Qt.AlignmentFlag.AlignLeft, Qt.AlignmentFlag.AlignVCenter),
                           index.data(Qt.ItemDataRole.DisplayRole).upper())
            else:
                p.setPen(QPen(c["border"], 1))
                y = r.center().y()
                p.drawLine(r.left() + 12, y, r.right() - 12, y)
            p.restore()
            return
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        box = QRectF(r.adjusted(6, 2, -6, -2))
        if selected or hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c["accent_soft"] if selected else c["hover"])
            p.drawRoundedRect(box, 7, 7)
        if selected:
            p.setBrush(c["accent"])
            p.drawRoundedRect(QRectF(box.left(), box.top() + 6, 3, box.height() - 12), 1.5, 1.5)
        state = index.data(ROLE_STATE) or ""
        glyph = index.data(ROLE_GLYPH) or ""
        d = 22
        cx = r.left() + (r.width() / 2.0 if self.shell.collapsed else 26)
        circle = QRectF(cx - d / 2.0, r.center().y() - d / 2.0 + 0.5, d, d)
        done = state == "done"
        ring = QColor(STATE_COLORS["done"]) if done else (c["accent"] if selected else c["border"])
        p.setPen(QPen(ring, 1.6))
        p.setBrush(QColor(STATE_COLORS["done"]) if done else (c["card"] if not selected else c["accent"]))
        p.drawEllipse(circle)
        f = QFont(option.font)
        f.setBold(True)
        f.setPointSizeF(max(6.5, f.pointSizeF() * (0.85 if len(glyph) < 2 else 0.72)))
        p.setFont(f)
        p.setPen(QColor("#ffffff") if (done or selected) else c["text"])
        p.drawText(circle, _flags(Qt.AlignmentFlag.AlignCenter), "✓" if done else glyph)
        if state in ("warn", "error") and self.shell.collapsed:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(STATE_COLORS[state]))
            p.drawEllipse(QRectF(circle.right() - 6, circle.top() - 1, 8, 8))
        if not self.shell.collapsed:
            f = QFont(option.font)
            f.setBold(selected)
            p.setFont(f)
            p.setPen(c["accent_text"] if selected else c["text"])
            badge = index.data(ROLE_BADGE) or ({"warn": "!", "error": "!"}.get(state, ""))
            reserve = 44 if badge else 12
            text_rect = QRect(int(circle.right()) + 10, r.top(), r.right() - int(circle.right()) - reserve, r.height())
            fm = QFontMetrics(f)
            p.drawText(text_rect, _flags(Qt.AlignmentFlag.AlignLeft, Qt.AlignmentFlag.AlignVCenter),
                       fm.elidedText(index.data(Qt.ItemDataRole.DisplayRole), Qt.TextElideMode.ElideRight,
                                     text_rect.width()))
            if badge:
                bf = QFont(option.font)
                bf.setBold(True)
                bf.setPointSizeF(max(6.5, bf.pointSizeF() * 0.8))
                p.setFont(bf)
                w = max(18, QFontMetrics(bf).horizontalAdvance(badge) + 10)
                br = QRectF(r.right() - 14 - w, r.center().y() - 9, w, 18)
                col = QColor(STATE_COLORS.get(state, STATE_COLORS["todo"]))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(col)
                p.drawRoundedRect(br, 9, 9)
                p.setPen(QColor("#ffffff"))
                p.drawText(br, _flags(Qt.AlignmentFlag.AlignCenter), badge)
        p.restore()


class NavShell(QWidget):
    """Sidebar navigation + stacked pages, with a QTabWidget-like API."""
    currentChanged = pyqtSignal(int)
    EXPANDED, COLLAPSED = 248, 58

    def __init__(self, brand="FMB tools", subtitle="TUFLOW model builder", parent=None):
        super().__init__(parent)
        self.collapsed = False
        self._pages = []          # [{"widget", "key", "title", "item"}]
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.side = QFrame()
        self.side.setObjectName("FmbSidebar")
        self.side.setFixedWidth(self.EXPANDED)
        sl = QVBoxLayout(self.side)
        sl.setContentsMargins(0, 10, 0, 8)
        sl.setSpacing(4)
        top = QHBoxLayout()
        top.setContentsMargins(14, 0, 8, 6)
        self.logo = QLabel()
        self.logo.setFixedSize(30, 30)
        top.addWidget(self.logo)
        names = QVBoxLayout()
        names.setSpacing(0)
        self.brand = QLabel(brand)
        self.brand.setObjectName("Brand")
        self.brand_sub = QLabel(subtitle)
        self.brand_sub.setObjectName("BrandSub")
        names.addWidget(self.brand)
        names.addWidget(self.brand_sub)
        top.addLayout(names, 1)
        self.collapse_btn = QToolButton()
        self.collapse_btn.setText("«")
        self.collapse_btn.setToolTip("Collapse / expand the sidebar")
        self.collapse_btn.clicked.connect(lambda: self.set_collapsed(not self.collapsed))
        top.addWidget(self.collapse_btn)
        sl.addLayout(top)
        self.nav = QListWidget()
        self.nav.setObjectName("NavList")
        self.nav.setMouseTracking(True)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.nav.setItemDelegate(NavDelegate(self))
        self.nav.currentRowChanged.connect(self._row_changed)
        sl.addWidget(self.nav, 1)
        self.foot = QLabel("")
        self.foot.setObjectName("BrandSub")
        self.foot.setContentsMargins(16, 0, 8, 0)
        self.foot.setWordWrap(True)
        sl.addWidget(self.foot)
        lay.addWidget(self.side)
        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)

    # -- building -------------------------------------------------------------
    def add_section(self, title):
        it = QListWidgetItem(title)
        it.setData(ROLE_SECTION, True)
        it.setFlags(Qt.ItemFlag.NoItemFlags)
        self.nav.addItem(it)
        return it

    def addTab(self, widget, title, key=None, glyph="", tip="", header=True):
        it = QListWidgetItem(title)
        it.setData(ROLE_KEY, key or title)
        it.setData(ROLE_GLYPH, glyph or title[:1])
        it.setToolTip(tip or title)
        self.nav.addItem(it)
        host = widget
        if header:                          # slim page header: title + one-line description
            host = QWidget()
            host.setObjectName("FmbPage")
            hl = QVBoxLayout(host)
            hl.setContentsMargins(14, 10, 14, 8)
            hl.setSpacing(6)
            head = QHBoxLayout()
            t = QLabel(title)
            t.setObjectName("PageTitle")
            head.addWidget(t)
            d = QLabel(tip)
            d.setObjectName("Muted")
            head.addWidget(d, 1)
            hl.addLayout(head)
            hl.addWidget(widget, 1)
        self.stack.addWidget(host)
        self._pages.append({"widget": widget, "host": host, "key": key or title, "title": title, "item": it})
        if len(self._pages) == 1:
            self.nav.setCurrentItem(it)
        return len(self._pages) - 1

    # -- QTabWidget-like API ----------------------------------------------------------
    def count(self):
        return len(self._pages)

    def widget(self, i):
        return self._pages[i]["widget"] if 0 <= i < len(self._pages) else None

    def indexOf(self, w):
        for i, pg in enumerate(self._pages):
            if pg["widget"] is w:
                return i
        return -1

    def currentIndex(self):
        cur = self.stack.currentWidget()
        for i, pg in enumerate(self._pages):
            if pg["host"] is cur:
                return i
        return -1

    def currentWidget(self):
        i = self.currentIndex()
        return self._pages[i]["widget"] if i >= 0 else None

    def setCurrentIndex(self, i):
        if 0 <= i < len(self._pages):
            self.nav.setCurrentItem(self._pages[i]["item"])

    def setCurrentWidget(self, w):
        self.setCurrentIndex(self.indexOf(w))

    def tabText(self, i):
        return self._pages[i]["key"] if 0 <= i < len(self._pages) else ""

    def title(self, i):
        return self._pages[i]["title"]

    def setTabText(self, i, text):
        self._pages[i]["title"] = text
        self._pages[i]["item"].setText(text)

    def setTabToolTip(self, i, tip):
        self._pages[i]["item"].setToolTip(tip)

    def pages(self):
        return list(self._pages)

    def find(self, key):
        k = (key or "").lower().replace("&&", "&")
        for i, pg in enumerate(self._pages):
            if pg["key"].lower() == k or pg["title"].lower() == k:
                return i
        for i, pg in enumerate(self._pages):
            if pg["key"].lower().startswith(k) or pg["title"].lower().startswith(k):
                return i
        return -1

    # -- badges -------------------------------------------------------------------
    def set_state(self, key, state, badge=""):
        i = self.find(key)
        if i >= 0:
            it = self._pages[i]["item"]
            it.setData(ROLE_STATE, state or "")
            it.setData(ROLE_BADGE, badge or "")

    def clear_states(self):
        for pg in self._pages:
            pg["item"].setData(ROLE_STATE, "")
            pg["item"].setData(ROLE_BADGE, "")

    def set_collapsed(self, on):
        self.collapsed = bool(on)
        self.side.setFixedWidth(self.COLLAPSED if on else self.EXPANDED)
        for w in (self.brand, self.brand_sub, self.foot, self.logo):
            w.setVisible(not on)
        self.collapse_btn.setText("»" if on else "«")
        self.nav.doItemsLayout()
        self.nav.viewport().update()

    def _row_changed(self, row):
        it = self.nav.item(row)
        if it is None:
            return
        for i, pg in enumerate(self._pages):
            if pg["item"] is it:
                if self.stack.currentWidget() is not pg["host"]:
                    self.stack.setCurrentWidget(pg["host"])
                    self.currentChanged.emit(i)
                return


# ---------------------------------------------------------------------------
class CommandPalette(QDialog):
    """Ctrl+K: type to jump to a page, run an action or find any TUFLOW command.
    entries: [(title, subtitle, callable, priority)] - priority 0 (pages) .. 3 (rare commands)."""

    def __init__(self, entries, parent=None):
        super().__init__(parent, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setObjectName("Palette")
        self.entries = entries
        self.setMinimumWidth(620)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Go to a page, run an action or find a TUFLOW command...  (Esc to close)")
        self.edit.textChanged.connect(self._filter)
        self.edit.installEventFilter(self)
        lay.addWidget(self.edit)
        self.list = QListWidget()
        self.list.setMinimumHeight(380)
        from .widgets import ExplainDelegate
        self.list.setItemDelegate(ExplainDelegate(self.list, ROLE_SUB))
        self.list.setUniformItemSizes(False)
        self.list.setWordWrap(True)
        self.list.itemActivated.connect(self._run)
        self.list.itemClicked.connect(self._run)
        lay.addWidget(self.list)
        hint = QLabel("↑↓ to choose, Enter to open.  Commands open in their control-file page.")
        hint.setObjectName("Muted")
        lay.addWidget(hint)
        c = colors()
        self.setStyleSheet("#Palette {{ background: {}; border: 1px solid {}; border-radius: 10px; }}"
                           "#Palette QLineEdit {{ padding: 8px; font-size: 12pt; border: 1px solid {}; "
                           "border-radius: 6px; }}".format(c["card"].name(), c["border"].name(), c["accent"].name()))
        self._filter("")

    @staticmethod
    def score(query, text):
        """Fuzzy score (lower is better): every query word must appear, as a substring or as letters
        in order. Whole words and word starts score best; the position matters only a little."""
        import re
        t = text.lower()
        total = len(t) * 0.02
        for w in query.lower().split():
            i = t.find(w)
            if i >= 0:
                start = i == 0 or not t[i - 1].isalnum()
                whole = re.search(r"(?<![a-z0-9]){}(?![a-z0-9])".format(re.escape(w)), t) is not None
                total += min(i, 40) * 0.25 + (0 if start else 3) - (6 if whole else 0)
                continue
            j, first = 0, -1
            for ch in w:                            # letters in order
                j = t.find(ch, j)
                if j < 0:
                    return None
                first = j if first < 0 else first
                j += 1
            total += 25 + min(first, 40) * 0.25
        return total

    def _filter(self, text):
        self.list.clear()
        rows = []
        for n, e in enumerate(self.entries):
            title, sub, prio = e[0], e[1], (e[3] if len(e) > 3 else 0)
            if not text.strip():
                if prio >= 2:
                    continue
                rows.append((n, n))
                continue
            s = self.score(text, title)
            if s is None:
                s2 = self.score(text, title + " " + sub)
                s = None if s2 is None else s2 + 30
            if s is not None:
                rows.append((s + prio * 9, n))
        rows.sort()
        for _s, n in rows[:60]:
            title, sub = self.entries[n][0], self.entries[n][1]
            it = QListWidgetItem(title)
            it.setData(ROLE_SUB, sub)
            it.setData(Qt.ItemDataRole.UserRole, n)
            self.list.addItem(it)
        if self.list.count():
            self.list.setCurrentRow(0)

    def eventFilter(self, obj, ev):
        if obj is self.edit and ev.type() == QEvent.Type.KeyPress:
            k = ev.key()
            if k in (Qt.Key.Key_Down, Qt.Key.Key_Up, Qt.Key.Key_PageDown, Qt.Key.Key_PageUp):
                QApplication.sendEvent(self.list, ev)
                return True
            if k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._run(self.list.currentItem())
                return True
        return super().eventFilter(obj, ev)

    def _run(self, item):
        if item is None:
            return
        n = item.data(Qt.ItemDataRole.UserRole)
        self.accept()
        fn = self.entries[n][2]
        if fn:
            fn()

    def popup(self, anchor):
        g = anchor.window().geometry()
        self.resize(max(620, int(g.width() * 0.45)), 470)
        self.move(g.left() + (g.width() - self.width()) // 2, g.top() + 70)
        self.show()
        self.edit.setFocus()
