# -*- coding: utf-8 -*-
"""Reusable widgets: value editors, path pickers, highlighters and a light chart."""
import os
import re

from qgis.PyQt.QtCore import Qt, pyqtSignal, QRectF, QPointF, QRect, QSize, QObject, QEvent
from qgis.PyQt.QtGui import (QColor, QFont, QPainter, QPen, QSyntaxHighlighter, QTextCharFormat, QBrush,
                             QPainterPath, QFontMetrics, QPalette, QKeySequence, QValidator)
from qgis.PyQt.QtWidgets import (QWidget, QHBoxLayout, QLineEdit, QToolButton, QComboBox, QFileDialog, QMenu,
                                 QSizePolicy, QDoubleSpinBox, QRadioButton, QButtonGroup, QStyledItemDelegate,
                                 QStyleOptionViewItem, QStyle, QApplication, QSpinBox, QToolTip,
                                 QTableWidgetItem, QAbstractItemView)

from . import qgis_utils as qu
from ..core.control_file import to_tuflow_path, resolve_path
from ..core.pasting import numbers_from_text

SEVERITY_COLORS = {
    "ERROR": QColor(200, 40, 40),
    "WARNING": QColor(214, 132, 0),
    "INFO": QColor(40, 110, 190),
    "PASS": QColor(30, 140, 70),
    "CHECK": QColor(40, 110, 190),
}
LEVEL_COLORS = {"req": QColor(200, 40, 40), "rec": QColor(214, 132, 0), "opt": QColor(120, 120, 120)}


def qexec(obj):
    fn = getattr(obj, "exec", None) or getattr(obj, "exec_")
    return fn()


def bold_font(size_delta=0):
    f = QFont()
    f.setBold(True)
    if size_delta:
        f.setPointSize(max(6, f.pointSize() + size_delta))
    return f


def mono_font():
    f = QFont("Consolas")
    f.setStyleHint(QFont.StyleHint.Monospace)
    f.setPointSize(10)
    return f


# ---------------------------------------------------------------------------
class TuflowHighlighter(QSyntaxHighlighter):
    """Syntax colours for TUFLOW control files (the Notepad++ look, built in)."""

    def __init__(self, doc):
        super().__init__(doc)

        def fmt(color, bold=False, italic=False):
            f = QTextCharFormat()
            f.setForeground(QColor(color))
            if bold:
                f.setFontWeight(QFont.Weight.Bold)
            f.setFontItalic(italic)
            return f
        self.f_comment = fmt("#6a8a6a", italic=True)
        self.f_cmd = fmt("#1f4e9c", bold=True)
        self.f_eq = fmt("#c0392b", bold=True)
        self.f_value = fmt("#222222")
        self.f_block = fmt("#8e44ad", bold=True)
        self.f_token = fmt("#d35400", bold=True)
        self.f_num = fmt("#16a085")
        self.f_path = fmt("#795548")

    def highlightBlock(self, text):
        s = text.lstrip()
        off = len(text) - len(s)
        if not s:
            return
        if s[0] in "!#":
            self.setFormat(0, len(text), self.f_comment)
            return
        code = text
        ci = -1
        for i, ch in enumerate(text):
            if ch in "!#":
                ci = i
                break
        if ci >= 0:
            self.setFormat(ci, len(text) - ci, self.f_comment)
            code = text[:ci]
        low = code.strip().lower()
        is_block = low.startswith(("if ", "else", "end if", "define", "end define", "start 2d", "end 2d",
                                   "start 1d", "end 1d"))
        eq = code.find("==")
        if eq >= 0:
            self.setFormat(off, eq - off, self.f_block if is_block else self.f_cmd)
            self.setFormat(eq, 2, self.f_eq)
            self.setFormat(eq + 2, len(code) - eq - 2, self.f_value)
            for m in re.finditer(r"-?\b\d+(\.\d+)?\b", code[eq + 2:]):
                self.setFormat(eq + 2 + m.start(), m.end() - m.start(), self.f_num)
            for m in re.finditer(r"[^\s|]*[\\/][^\s|]*", code[eq + 2:]):
                self.setFormat(eq + 2 + m.start(), m.end() - m.start(), self.f_path)
        else:
            self.setFormat(off, len(code) - off, self.f_block if is_block else self.f_cmd)
        for m in re.finditer(r"~[se]\d?~|<<[^>]+>>|~[A-Za-z0-9_]+~", code):
            self.setFormat(m.start(), m.end() - m.start(), self.f_token)


# colours of the log views: (text, background tint) - amber for warnings, red for errors
LOG_COLORS = {"ERROR": ("#b71c1c", "#fdecea"), "WARNING": ("#8a5300", "#fff1d6"),
              "CHECK": ("#1a5a96", "#e8f1fb"), "OK": ("#1b7a3a", "#e3f4e8")}
LOG_STATE = {"ERROR": 1, "WARNING": 2, "CHECK": 3, "OK": 4}
SEVERITY_TINTS = {"ERROR": QColor("#fdecea"), "WARNING": QColor("#fff1d6"), "CHECK": QColor("#e8f1fb"),
                  "INFO": QColor("#e8f1fb"), "PASS": QColor("#e3f4e8"), "OK": QColor("#e3f4e8")}


class LogHighlighter(QSyntaxHighlighter):
    """Colours whole log lines: errors red, warnings amber, checks blue, 'simulation finished'
    green (see core.logs.classify_line). The kind is also stored as the block state so views
    can jump between issues quickly."""
    KEYWORD = re.compile(r"\b(ERROR|WARNING|CHECK)S?\b(\s+\d{4})?|\bunstable\b|\bNaN\b|(?i:simulation\s+\w+)",
                         re.IGNORECASE)

    def __init__(self, doc):
        super().__init__(doc)
        from ..core.logs import classify_line
        self.classify = classify_line
        self.line_fmt, self.key_fmt = {}, {}
        for kind, (fg, bg) in LOG_COLORS.items():
            f = QTextCharFormat()
            f.setForeground(QColor(fg))
            f.setBackground(QColor(bg))
            self.line_fmt[kind] = f
            k = QTextCharFormat(f)
            k.setFontWeight(QFont.Weight.Bold)
            self.key_fmt[kind] = k

    def highlightBlock(self, text):
        kind = self.classify(text)
        if not kind:
            self.setCurrentBlockState(0)
            return
        self.setCurrentBlockState(LOG_STATE[kind])
        self.setFormat(0, len(text), self.line_fmt[kind])
        for m in self.KEYWORD.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.key_fmt[kind])


class LogView(QWidget):
    """Read-only log / console view with colour-coded lines, issue counts that jump to the next
    error / warning / check, previous / next buttons, a filter (all lines, errors & warnings,
    errors only) and find."""
    FILTERS = [("All lines", None), ("Errors, warnings & checks", ("ERROR", "WARNING", "CHECK")),
               ("Errors & warnings", ("ERROR", "WARNING")), ("Errors only", ("ERROR",))]

    def __init__(self, placeholder="", max_blocks=0, parent=None):
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QPlainTextEdit, QVBoxLayout, QLabel
        from ..core.logs import classify_line
        self.classify = classify_line
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        bar = QHBoxLayout()
        bar.setSpacing(4)
        self.chips = {}
        for kind, label in (("ERROR", "errors"), ("WARNING", "warnings"), ("CHECK", "checks"), ("OK", "finished")):
            b = QToolButton()
            b.setAutoRaise(True)
            b.setProperty("label", label)
            fg, bg = LOG_COLORS[kind]
            b.setStyleSheet("QToolButton {{ color: {0}; background: {1}; border: 1px solid {0}; border-radius: 3px;"
                            " padding: 1px 6px; font-weight: bold; }}".format(fg, bg))
            b.setToolTip("Jump to the next {} line".format(label.rstrip("s") if kind != "OK" else "'finished'"))
            b.clicked.connect(lambda _=False, k=kind: self.goto((k,), 1))
            bar.addWidget(b)
            self.chips[kind] = b
        prev_b = QToolButton()
        prev_b.setText("\u25b2")
        prev_b.setToolTip("Previous error / warning / check")
        prev_b.clicked.connect(lambda: self.goto(("ERROR", "WARNING", "CHECK"), -1))
        next_b = QToolButton()
        next_b.setText("\u25bc")
        next_b.setToolTip("Next error / warning / check")
        next_b.clicked.connect(lambda: self.goto(("ERROR", "WARNING", "CHECK"), 1))
        bar.addWidget(prev_b)
        bar.addWidget(next_b)
        bar.addSpacing(8)
        bar.addWidget(QLabel("Show"))
        self.filter = QComboBox()
        for label, _k in self.FILTERS:
            self.filter.addItem(label)
        self.filter.setToolTip("Show every line or only the problem lines (with their line numbers)")
        self.filter.currentIndexChanged.connect(lambda _i: self._render())
        bar.addWidget(self.filter)
        bar.addStretch(1)
        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText("Find...")
        self.find_edit.setMaximumWidth(220)
        self.find_edit.setMinimumWidth(110)
        self.find_edit.returnPressed.connect(lambda: self.find_text(self.find_edit.text()))
        bar.addWidget(self.find_edit)
        lay.addLayout(bar)
        self.edit = QPlainTextEdit()
        self.edit.setReadOnly(True)
        self.edit.setFont(mono_font())
        self.edit.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        if placeholder:
            self.edit.setPlaceholderText(placeholder)
        if max_blocks:
            self.edit.setMaximumBlockCount(max_blocks)
        self.highlighter = LogHighlighter(self.edit.document())
        lay.addWidget(self.edit, 1)
        self._text = ""
        self._partial = ""
        self._line_no = 0
        self.counts = dict.fromkeys(LOG_COLORS, 0)
        self._update_chips()

    # -- content ------------------------------------------------------------
    def _wanted(self):
        return self.FILTERS[self.filter.currentIndex()][1]

    def setPlainText(self, text):
        self._text = text or ""
        lines = self._text.splitlines()
        self._line_no = len(lines)
        self._partial = ""
        self.counts = dict.fromkeys(LOG_COLORS, 0)
        for ln in lines:
            k = self.classify(ln)
            if k:
                self.counts[k] += 1
        self._render()
        self._update_chips()

    def clear(self):
        self.setPlainText("")

    def toPlainText(self):
        return self._text

    def append_text(self, chunk):
        """Append console output (may contain partial lines)."""
        if not chunk:
            return
        self._text += chunk
        data = self._partial + chunk
        lines = data.split("\n")
        self._partial = lines.pop()
        wanted = self._wanted()
        new = []
        for ln in lines:
            ln = ln.rstrip("\r")
            self._line_no += 1
            k = self.classify(ln)
            if k:
                self.counts[k] += 1
            if wanted and k in wanted:
                new.append(self._numbered(self._line_no, ln))
        if wanted is None:
            self.edit.moveCursor(QTextCursorEnd())
            self.edit.insertPlainText(chunk)
        elif new:
            self.edit.appendPlainText("\n".join(new))
        self.edit.ensureCursorVisible()
        if lines:
            self._update_chips()

    @staticmethod
    def _numbered(n, line):
        return "{:>7} | {}".format(n, line)

    def _render(self):
        wanted = self._wanted()
        if wanted is None:
            self.edit.setPlainText(self._text)
            return
        out = [self._numbered(i + 1, ln) for i, ln in enumerate(self._text.splitlines())
               if self.classify(ln) in wanted]
        self.edit.setPlainText("\n".join(out) if out else "(no {} lines)".format(
            self.filter.currentText().lower().replace("only", "").strip()))

    def _update_chips(self):
        for kind, b in self.chips.items():
            n = self.counts.get(kind, 0)
            if kind == "OK":
                b.setText("\u25cf finished")
                b.setVisible(n > 0)
            else:
                b.setText("\u25cf {} {}".format(n, b.property("label") if n != 1 else b.property("label")[:-1]))
                b.setEnabled(n > 0)

    # -- navigation ---------------------------------------------------------
    def goto(self, kinds, direction=1):
        """Select the next (direction 1) or previous (-1) line of one of `kinds`; wraps around."""
        doc = self.edit.document()
        n = doc.blockCount()
        if not n:
            return False
        states = {LOG_STATE[k] for k in kinds}
        cur = self.edit.textCursor().blockNumber()
        for step in range(1, n + 1):
            b = doc.findBlockByNumber((cur + direction * step) % n)
            if b.userState() in states:
                from qgis.PyQt.QtGui import QTextCursor
                c = QTextCursor(b)
                c.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
                self.edit.setTextCursor(c)
                self.edit.centerCursor()
                return True
        QApplication.beep()
        return False

    def find_text(self, text):
        if not text:
            return False
        if self.edit.find(text):
            return True
        from qgis.PyQt.QtGui import QTextCursor
        c = self.edit.textCursor()
        c.movePosition(QTextCursor.MoveOperation.Start)
        self.edit.setTextCursor(c)
        return self.edit.find(text)


def QTextCursorEnd():
    from qgis.PyQt.QtGui import QTextCursor
    return QTextCursor.MoveOperation.End


# ---------------------------------------------------------------------------
class PathEdit(QWidget):
    """Line edit + browse button + 'pick from QGIS layers' menu.
    The value is always written relative to base_dir() in TUFLOW style."""
    changed = pyqtSignal(str)
    openRequested = pyqtSignal()

    def __init__(self, kind="file", file_filter="", base_dir_fn=None, options=None, parent=None,
                 open_label=None):
        super().__init__(parent)
        self.kind = kind
        self.file_filter = file_filter or "All files (*)"
        self.base_dir_fn = base_dir_fn or (lambda: "")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        if options:
            self.edit = QComboBox()
            self.edit.setEditable(True)
            self.edit.addItems([""] + list(options))
            self.line = self.edit.lineEdit()
        else:
            self.edit = self.line = QLineEdit()
        self.line.setPlaceholderText({"gis": "GIS layer (.gpkg >> layer, .shp, .mif) or spatial database layer name",
                                      "grid": "raster file (.tif, .asc, .flt ...)",
                                      "folder": "folder, e.g. ..\\results\\"}.get(kind, "file path"))
        self.line.textChanged.connect(self.changed.emit)
        lay.addWidget(self.edit, 1)
        self.btn = QToolButton()
        self.btn.setText("...")
        self.btn.setToolTip("Browse")
        self.btn.clicked.connect(self.browse)
        lay.addWidget(self.btn)
        self.lbtn = None
        if kind in ("gis", "grid"):
            self._layer_button()
        if open_label:
            ob = QToolButton()
            ob.setText(open_label)
            ob.setToolTip("Open this file in its tab")
            ob.clicked.connect(self.openRequested.emit)
            lay.addWidget(ob)

    def _layer_button(self):
        if self.lbtn is not None:
            return
        self.lbtn = QToolButton()
        self.lbtn.setText("L")
        self.lbtn.setToolTip("Pick a layer loaded in QGIS")
        self.lbtn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu = QMenu(self.lbtn)
        self.menu.aboutToShow.connect(self._fill_layer_menu)
        self.lbtn.setMenu(self.menu)
        self.layout().insertWidget(2, self.lbtn)

    def designer_properties(self):
        return {"fmbKind": self.kind, "fmbFilter": self.file_filter if self.file_filter != "All files (*)" else "",
                "fmbPlaceholder": self.line.placeholderText()}

    def set_kind(self, kind, file_filter=None, placeholder=None):
        """Change what the picker browses for (file | folder | gis | grid | gis_out)."""
        self.kind = kind or "file"
        if file_filter:
            self.file_filter = file_filter
        self.line.setPlaceholderText(placeholder or {
            "gis": "GIS layer (.gpkg >> layer, .shp, .mif) or spatial database layer name",
            "grid": "raster file (.tif, .asc, .flt ...)", "folder": "folder, e.g. ..\\results\\"}.get(self.kind, "file path"))
        if self.kind in ("gis", "grid"):
            self._layer_button()
        elif self.lbtn is not None:
            self.lbtn.hide()

    def value(self):
        return self.line.text()

    def setValue(self, v):
        self.line.blockSignals(True)
        self.line.setText(v or "")
        self.line.setCursorPosition(0)
        self.line.blockSignals(False)

    def _rel(self, path):
        return to_tuflow_path(path, self.base_dir_fn())

    def browse(self):
        start = self.base_dir_fn() or ""
        cur = self.value().split("|")[0].split(">>")[0].strip()
        if cur:
            p = resolve_path(cur, start)
            start = p if os.path.exists(p) else start
        if self.kind == "folder" or self.kind == "folder_or_choice":
            d = QFileDialog.getExistingDirectory(self, "Select folder", start)
            if d:
                if not self.base_dir_fn():          # absolute folder (model root etc.) - keep it native
                    self.line.setText(os.path.normpath(d))
                else:
                    self.line.setText(self._rel(d).rstrip("\\/") + "\\")
            return
        if self.kind == "gis_out":
            f, _ = QFileDialog.getSaveFileName(self, "Output layer", start, self.file_filter)
        else:
            f, _ = QFileDialog.getOpenFileName(self, "Select file", start, self.file_filter)
        if not f:
            return
        rel = self._rel(f)
        if self.kind == "gis" and f.lower().endswith(".gpkg"):
            from ..core.qc import gpkg_layers
            names = gpkg_layers(f) or []
            if names:
                m = QMenu(self)
                for n in names:
                    m.addAction(n)
                act = qexec_menu(m, self.btn)
                if act is None:
                    return
                rel = "{} >> {}".format(rel, act.text())
        self._set_or_append(rel)

    def _set_or_append(self, text):
        cur = self.value().strip()
        if cur and self.kind == "gis" and getattr(self, "_append", False):
            self.line.setText(cur + " | " + text)
        else:
            self.line.setText(text)
        self._append = False

    def _fill_layer_menu(self):
        self.menu.clear()
        kind = "vector" if self.kind == "gis" else "raster"
        layers = qu.project_layers(kind)
        if not layers:
            a = self.menu.addAction("(no {} layers in the QGIS project)".format(kind))
            a.setEnabled(False)
            return
        app = self.menu.addAction("Append instead of replace")
        app.setCheckable(True)
        app.setChecked(getattr(self, "_append", False))
        app.toggled.connect(lambda on: setattr(self, "_append", on))
        self.menu.addSeparator()
        for name, source, _t, _l in layers:
            path, lname = qu.layer_path_and_name(source)
            act = self.menu.addAction(name)
            act.setToolTip(source)
            act.triggered.connect(lambda _=False, p=path, n=lname: self._pick(p, n))

    def _pick(self, path, lname):
        rel = self._rel(path)
        if path.lower().endswith(".gpkg") and lname:
            rel = "{} >> {}".format(rel, lname)
        self._set_or_append(rel)


def qexec_menu(menu, anchor):
    pos = anchor.mapToGlobal(anchor.rect().bottomLeft())
    fn = getattr(menu, "exec", None) or getattr(menu, "exec_")
    return fn(pos)


class NoWheelMixin(object):
    """Ignore the mouse wheel unless the widget has focus, so scrolling a table
    never changes a value by accident."""

    def wheelEvent(self, ev):
        if self.hasFocus():
            super().wheelEvent(ev)
        else:
            ev.ignore()


class TokenListEdit(QWidget):
    """Line edit with a checkable dropdown of tokens (e.g. Map Output Data Types,
    scenario / event names). `tokens` is a list of (token, label) or a callable
    returning such a list."""
    changed = pyqtSignal(str)

    def __init__(self, tokens, parent=None, sep=" ", button_text="+", placeholder=""):
        super().__init__(parent)
        self.tokens = tokens
        self.sep = sep
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        self.line = QLineEdit()
        self.line.setPlaceholderText(placeholder)
        self.line.textChanged.connect(self.changed.emit)
        lay.addWidget(self.line, 1)
        b = QToolButton()
        b.setText(button_text)
        b.setToolTip("Pick values")
        b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu = QMenu(b)
        self.menu.aboutToShow.connect(self._fill)
        b.setMenu(self.menu)
        lay.addWidget(b)

    def designer_properties(self):
        return {"fmbSeparator": self.sep, "fmbPlaceholder": self.line.placeholderText()}

    def _current(self):
        if self.sep.strip():
            return [t.strip() for t in self.line.text().split(self.sep.strip()) if t.strip()]
        return self.line.text().split()

    def _fill(self):
        self.menu.clear()
        toks = self.tokens() if callable(self.tokens) else self.tokens
        cur = self._current()
        low = [c.lower() for c in cur]
        if not toks:
            a = self.menu.addAction("(nothing defined in the model yet - type the names)")
            a.setEnabled(False)
            return
        for tok, label in toks:
            a = self.menu.addAction("{}  -  {}".format(tok, label) if label else tok)
            a.setCheckable(True)
            a.setChecked(tok.lower() in low)
            a.toggled.connect(lambda on, t=tok: self._toggle(t, on))

    def _toggle(self, tok, on):
        cur = self._current()
        low = [c.lower() for c in cur]
        if on and tok.lower() not in low:
            cur.append(tok)
        if not on and tok.lower() in low:
            del cur[low.index(tok.lower())]
        self.line.setText(self.sep.join(cur) if self.sep.strip() else " ".join(cur))

    def value(self):
        return self.line.text()

    def setValue(self, v):
        self.line.blockSignals(True)
        self.line.setText(v or "")
        self.line.setCursorPosition(0)
        self.line.blockSignals(False)


class ChoiceEdit(NoWheelMixin, QComboBox):
    """Dropdown of the command's options (editable when free values are allowed)."""
    changed = pyqtSignal(str)

    def __init__(self, options, editable=False, default="", parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setEditable(editable)
        self.addItem("")
        for o in options:
            label = o + ("  (default)" if o == default else "")
            self.addItem(label, o)
        self.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.currentIndexChanged.connect(lambda _i: self.changed.emit(self.value()))
        if editable:
            self.lineEdit().textEdited.connect(lambda _t: self.changed.emit(self.value()))
            self.currentIndexChanged.connect(lambda _i: self.lineEdit().setCursorPosition(0))

    def value(self):
        i = self.currentIndex()
        data = self.itemData(i)
        if self.isEditable():
            txt = self.currentText()
            if data is not None and txt == self.itemText(i):
                return data
            return txt.replace("  (default)", "")
        return data if data is not None else ""

    def setValue(self, v):
        self.blockSignals(True)
        v = v or ""
        idx = -1
        for i in range(self.count()):
            d = self.itemData(i)
            if (d or "").lower() == v.lower():
                idx = i
                break
        if idx < 0 and v:
            if self.isEditable():
                self.setEditText(v)
            else:
                self.addItem(v, v)
                idx = self.count() - 1
        if idx >= 0:
            self.setCurrentIndex(idx)
        elif not v:
            self.setCurrentIndex(0)
        if self.isEditable():
            self.lineEdit().setCursorPosition(0)
        self.blockSignals(False)


class NameCombo(ChoiceEdit):
    """Editable dropdown filled from the model when opened (BC names, material IDs ...).
    `names_fn()` returns [(value, label)]."""

    def __init__(self, names_fn, placeholder="", parent=None):
        super().__init__([], True, "", parent)
        self.names_fn = names_fn
        self.lineEdit().setPlaceholderText(placeholder)

    def showPopup(self):
        cur = self.value()
        self.blockSignals(True)
        self.clear()
        self.addItem("")
        for val, label in (self.names_fn() or []):
            self.addItem("{}  -  {}".format(val, label) if label else val, val)
        self.blockSignals(False)
        self.setValue(cur)
        super().showPopup()

    def value(self):
        i = self.currentIndex()
        data = self.itemData(i)
        txt = self.currentText()
        if data is not None and txt == self.itemText(i):
            return data
        return txt.split("  -  ")[0]


class TextEdit(QLineEdit):
    changed = pyqtSignal(str)

    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.textChanged.connect(self.changed.emit)

    def value(self):
        return self.text()

    def setValue(self, v):
        self.blockSignals(True)
        self.setText(v or "")
        self.setCursorPosition(0)
        self.blockSignals(False)


# ---------------------------------------------------------------------------
# numbers
def fmt_number(v, is_int=False):
    if is_int:
        return str(int(round(v)))
    s = "{:.6f}".format(v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def parse_number(text):
    t = (text or "").strip().replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return None


class PasteMixin(object):
    """Reliable paste for spin boxes.

    Qt's spin boxes validate the whole text after a paste, so pasting into a box that shows
    'not set', a unit suffix or a thousands separator is silently rejected. Here Ctrl+V /
    Shift+Insert and the context-menu Paste replace the value with the first number found in
    the clipboard ('312,345.6 m', 'X: 312345.6', '5,25' ...). When the box is part of a
    group (X, Y pair ...) `multi_paste(spin, numbers)` spreads several numbers over the group.
    Drag-and-drop and middle-click pastes are rescued in validate()."""
    multi_paste = None

    def keyPressEvent(self, ev):
        if ev.matches(QKeySequence.StandardKey.Paste):
            self.paste_clipboard()
            ev.accept()
            return
        super().keyPressEvent(ev)

    def contextMenuEvent(self, ev):
        le = self.lineEdit()
        menu = QMenu(self)
        has_sel = le.hasSelectedText()
        a = menu.addAction("Cut")
        a.setEnabled(has_sel and not self.isReadOnly())
        a.triggered.connect(le.cut)
        a = menu.addAction("Copy")
        a.setEnabled(has_sel)
        a.triggered.connect(le.copy)
        a = menu.addAction("Paste")
        a.setEnabled(bool(QApplication.clipboard().text().strip()) and not self.isReadOnly())
        a.triggered.connect(self.paste_clipboard)
        menu.addAction("Select all", self.selectAll)
        menu.addSeparator()
        menu.addAction("Step up", lambda: self.stepBy(1))
        menu.addAction("Step down", lambda: self.stepBy(-1))
        if hasattr(self, "unset") and self.specialValueText():
            menu.addAction("Clear ({})".format(self.specialValueText()), self.unset)
        (getattr(menu, "exec", None) or getattr(menu, "exec_"))(ev.globalPos())

    def paste_clipboard(self):
        if self.isReadOnly():
            return
        text = QApplication.clipboard().text()
        nums = numbers_from_text(text, multi=self.multi_paste is not None)
        if not nums:
            QApplication.beep()
            self._note("The clipboard has no number to paste.")
            return
        if len(nums) > 1 and self.multi_paste is not None and self.multi_paste(self, nums):
            return
        self.set_pasted(nums[0])

    def set_pasted(self, v):
        """Set a pasted number; values outside the range are clamped with a note."""
        if getattr(self, "is_int", isinstance(self, QSpinBox)):
            v = int(round(v))
        lo = getattr(self, "lo", self.minimum())
        if v < lo or v > self.maximum():
            c = min(max(v, lo), self.maximum())
            self._note("{} is outside the allowed range ({} to {}) - set to {}.".format(
                fmt_number(v), fmt_number(lo), fmt_number(self.maximum()), fmt_number(c)))
            v = c
        self.setValue(v)
        self.selectAll()

    def _note(self, text):
        try:
            QToolTip.showText(self.mapToGlobal(self.rect().bottomLeft()), text, self)
        except Exception:
            pass

    def _core_text(self, text):
        t = text
        for part in (self.prefix(), self.suffix(), self.specialValueText()):
            if part and part.strip():
                t = t.replace(part, " ").replace(part.strip(), " ")
        return t

    def _salvage(self, text):
        """Text for a paste/drop that the normal validator rejected, or None while typing."""
        cur = self.lineEdit().text()
        special = self.specialValueText()
        typing = len(text) - len(cur) <= 1 and not (special and special in text)
        if typing:                              # ordinary typing - keep Qt's behaviour
            return None
        nums = numbers_from_text(self._core_text(text))
        if not nums or not (self.minimum() <= nums[0] <= self.maximum()):
            return None
        return self.prefix() + self.textFromValue(nums[0]) + self.suffix()


class SmartDoubleSpin(PasteMixin, NoWheelMixin, QDoubleSpinBox):
    """QDoubleSpinBox with reliable paste and no accidental wheel changes."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def validate(self, text, pos):
        res = super().validate(text, pos)
        if res[0] == QValidator.State.Invalid:
            new = self._salvage(text)
            if new is not None:
                return (QValidator.State.Acceptable, new, len(new) - len(self.suffix()))
        return res


class SmartIntSpin(PasteMixin, NoWheelMixin, QSpinBox):
    """QSpinBox with reliable paste and no accidental wheel changes."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def validate(self, text, pos):
        res = super().validate(text, pos)
        if res[0] == QValidator.State.Invalid:
            new = self._salvage(text)
            if new is not None:
                return (QValidator.State.Acceptable, new, len(new) - len(self.suffix()))
        return res


def link_spins(spins):
    """Pasting several numbers ('x, y' or 'start end') into one box of the group fills the
    following boxes too."""
    spins = list(spins)

    def spread(spin, nums):
        i = spins.index(spin)
        for sp, v in zip(spins[i:], nums):
            sp.set_pasted(v)
        spin.setFocus()
        return True
    for sp in spins:
        sp.multi_paste = spread


class NumberSpin(PasteMixin, NoWheelMixin, QDoubleSpinBox):
    """Spin box with units, a 'not set' state and locale-independent '.' decimals."""

    def __init__(self, unit="", is_int=False, lo=-1e9, hi=1e9, step=1.0, default=None, prefix="", parent=None):
        super().__init__(parent)
        self.configure(unit, is_int, lo, hi, step, default, prefix)

    def designer_properties(self):
        return {"fmbUnit": self.suffix().strip(), "fmbIsInt": "true" if self.is_int else "false",
                "fmbMin": fmt_number(self.lo), "fmbMax": fmt_number(self.hi), "fmbStep": fmt_number(self.singleStep()),
                "fmbDefault": "" if self.default is None else fmt_number(self.default), "fmbPrefix": self.prefix().strip()}

    def configure(self, unit="", is_int=False, lo=-1e9, hi=1e9, step=1.0, default=None, prefix=""):
        """(Re)set units, range, step and the 'not set' / default text."""
        if default is not None:
            lo = min(lo, default)
            hi = max(hi, default)
        self.is_int = is_int
        self.lo = lo
        self.hi = hi
        self.default = default
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setDecimals(0 if is_int else 6)
        self.setRange(lo - step, hi)
        self.setSingleStep(step)
        self.setSpecialValueText("not set" if default is None else "default ({})".format(fmt_number(default, is_int)))
        self.setSuffix(" " + unit if unit else "")
        self.setPrefix(prefix + " " if prefix else "")
        self.setAccelerated(True)
        self.setMinimumWidth(max(96, self.minimumWidth()))
        self.setValue(self.minimum())

    def textFromValue(self, v):
        return fmt_number(v, self.is_int)

    def valueFromText(self, text):
        t = text
        for part in (self.prefix(), self.suffix()):
            if part:
                t = t.replace(part, "")
        v = parse_number(t)
        return self.minimum() if v is None else v

    def validate(self, text, pos):
        t = text
        for part in (self.prefix(), self.suffix()):
            if part:
                t = t.replace(part.strip(), "")
        t = t.strip()
        if t == self.specialValueText() or t in ("", "-", ".", "-.", ","):
            return (QValidator.State.Intermediate, text, pos)
        if parse_number(t) is not None:
            return (QValidator.State.Acceptable, text, pos)
        new = self._salvage(text)
        if new is not None:
            return (QValidator.State.Acceptable, new, len(new) - len(self.suffix()))
        return (QValidator.State.Invalid, text, pos)

    def stepBy(self, steps):
        if not self.is_set():
            start = self.default if self.default is not None else max(self.lo, 0.0)
            self.setValue(start)
            return
        super().stepBy(steps)

    def is_set(self):
        return self.value() > self.minimum() + 1e-12

    def unset(self):
        self.setValue(self.minimum())

    def text_value(self):
        return fmt_number(self.value(), self.is_int) if self.is_set() else ""


class NumberEdit(QWidget):
    """One or more numbers (e.g. 'X, Y') with units. A small 'abc' toggle switches to
    free text for values such as <<variables>> or ~s1~ tokens."""
    changed = pyqtSignal(str)

    def __init__(self, parts, default=None, parent=None):
        """parts: list of dicts(unit, is_int, lo, hi, step, label)."""
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        self.spins = []
        defaults = []
        if default is not None:
            defaults = [parse_number(x) for x in str(default).split(",")]
        for i, p in enumerate(parts):
            d = defaults[i] if i < len(defaults) else None
            sp = NumberSpin(p.get("unit", ""), p.get("is_int", False), p.get("lo", -1e9), p.get("hi", 1e9),
                            p.get("step", 1.0), d, p.get("label", ""))
            sp.valueChanged.connect(self._emit)
            self.spins.append(sp)
            lay.addWidget(sp, 1)
        if len(self.spins) > 1:
            link_spins(self.spins)
        self.text = QLineEdit()
        self.text.setPlaceholderText("value, <<variable>> or ~s1~ token")
        self.text.textChanged.connect(self._emit)
        self.text.hide()
        lay.addWidget(self.text, 1)
        self.mode = QToolButton()
        self.mode.setText("abc")
        self.mode.setCheckable(True)
        self.mode.setToolTip("Type the value as text (for <<variables>>, ~s1~/~e1~ tokens or expressions)")
        self.mode.toggled.connect(self._set_text_mode)
        lay.addWidget(self.mode)
        self._block = False
        self._orig = ""

    def _set_text_mode(self, on):
        if on:
            self.text.blockSignals(True)
            self.text.setText(self._spin_value())
            self.text.blockSignals(False)
        else:
            self._to_spins(self.text.text())
        for sp in self.spins:
            sp.setVisible(not on)
        self.text.setVisible(on)
        self._emit()

    def _spin_value(self):
        vals = [sp.text_value() for sp in self.spins]
        while vals and not vals[-1]:
            vals.pop()
        if not vals:
            return ""
        # keep the original text (e.g. '1.0') while the numbers are unchanged
        if self._orig and [parse_number(x) for x in self._orig.split(",")] == \
                [parse_number(x) if x else None for x in vals]:
            return self._orig
        return ", ".join(vals)

    def _to_spins(self, text):
        vals = [parse_number(x) for x in (text or "").split(",")] if text else []
        for i, sp in enumerate(self.spins):
            sp.blockSignals(True)
            if i < len(vals) and vals[i] is not None:
                sp.setValue(vals[i])
            else:
                sp.unset()
            sp.blockSignals(False)

    def _emit(self, *_):
        if not self._block:
            self.changed.emit(self.value())

    def value(self):
        return self.text.text().strip() if self.mode.isChecked() else self._spin_value()

    def setValue(self, v):
        self._block = True
        v = (v or "").strip()
        self._orig = v
        parts = [x.strip() for x in v.split(",")] if v else []
        nums = [parse_number(x) for x in parts]
        numeric = all(n is not None for n in nums) and len(parts) <= len(self.spins) and \
            all(sp.lo <= n <= sp.hi for sp, n in zip(self.spins, nums))
        self.mode.blockSignals(True)
        self.mode.setChecked(not numeric)
        self.mode.blockSignals(False)
        if numeric:
            self._to_spins(v)
        else:
            self.text.setText(v)
        for sp in self.spins:
            sp.setVisible(numeric)
        self.text.setVisible(not numeric)
        self._block = False


# ---------------------------------------------------------------------------
# radio buttons
class RadioChoice(QWidget):
    """Radio buttons for short option sets (ON/OFF, CPU/GPU, METHOD A/B ...).
    No button is checked while the command has no value."""
    changed = pyqtSignal(str)

    def __init__(self, options, default="", parent=None):
        super().__init__(parent)
        self.lay = QHBoxLayout(self)
        self.lay.setContentsMargins(2, 0, 2, 0)
        self.lay.setSpacing(6)
        self.group = QButtonGroup(self)
        self.group.buttonClicked.connect(lambda _b: self.changed.emit(self.value()))
        self.default = default
        self.lay.addStretch(1)
        for o in options:
            self._add(o)

    def designer_properties(self):
        return {"fmbOptions": "|".join(b.property("value") or "" for b in self.group.buttons()),
                "fmbDefault": self.default or "", "fmbValue": self.value()}

    def set_options(self, options, default=""):
        """Replace the buttons."""
        for b in list(self.group.buttons()):
            self.group.removeButton(b)
            b.setParent(None)
            b.deleteLater()
        self.default = default
        for o in options:
            self._add(o)

    def _add(self, option):
        rb = QRadioButton(option or "(blank)")
        rb.setProperty("value", option)
        if option and option.lower() == (self.default or "").lower():
            f = rb.font()
            f.setUnderline(True)
            rb.setFont(f)
            rb.setToolTip("TUFLOW default")
        self.group.addButton(rb)
        self.lay.insertWidget(self.lay.count() - 1, rb)
        return rb

    def value(self):
        b = self.group.checkedButton()
        return b.property("value") if b is not None else ""

    def setValue(self, v):
        v = (v or "").strip()
        self.group.setExclusive(False)
        for b in self.group.buttons():
            b.setChecked(False)
        self.group.setExclusive(True)
        if not v:
            return
        for b in self.group.buttons():
            if (b.property("value") or "").lower() == v.lower():
                b.setChecked(True)
                return
        self._add(v).setChecked(True)      # value not in the list - keep it


class OptionValueEdit(QWidget):
    """Keyword options as radio buttons plus a 'value' choice with its own editor,
    e.g.  ( ) AUTO  ( ) value [ 0.5 s ]"""
    changed = pyqtSignal(str)

    def __init__(self, words, value_widget, default="", parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 0, 0, 0)
        lay.setSpacing(8)
        self.group = QButtonGroup(self)
        self.words = []
        for w in words:
            rb = QRadioButton(w)
            rb.setProperty("value", w)
            if w.lower() == (default or "").lower():
                f = rb.font()
                f.setUnderline(True)
                rb.setFont(f)
                rb.setToolTip("TUFLOW default")
            self.group.addButton(rb)
            self.words.append(rb)
            lay.addWidget(rb)
        self.val_rb = QRadioButton("")
        self.val_rb.setToolTip("Enter a value")
        self.group.addButton(self.val_rb)
        lay.addWidget(self.val_rb)
        self.editor = value_widget
        lay.addWidget(value_widget, 1)
        self.group.buttonClicked.connect(self._clicked)
        value_widget.changed.connect(self._editor_changed)
        self._block = False

    def _clicked(self, b):
        if b is self.val_rb and hasattr(self.editor, "setFocus"):
            self.editor.setFocus()
        self.changed.emit(self.value())

    def _editor_changed(self, _v):
        if self._block:
            return
        if not self.val_rb.isChecked() and self.editor.value():
            self.val_rb.setChecked(True)
        self.changed.emit(self.value())

    def value(self):
        b = self.group.checkedButton()
        if b is None:
            return ""
        if b is self.val_rb:
            return self.editor.value()
        return b.property("value")

    def setValue(self, v):
        self._block = True
        v = (v or "").strip()
        self.group.setExclusive(False)
        for b in self.group.buttons():
            b.setChecked(False)
        self.group.setExclusive(True)
        matched = False
        for rb in self.words:
            if v and rb.property("value").lower() == v.lower():
                rb.setChecked(True)
                matched = True
        if not matched:
            self.editor.setValue(v if v else "")
            if v:
                self.val_rb.setChecked(True)
        self._block = False


# ---------------------------------------------------------------------------
# choosing the right editor for a command
_NUM_UNITS = {
    "h": ("time_in_hours", "model_time_in_hours", "time", "time_interval_in_hours", "interval_in_hours"),
    "s": ("time_in_seconds", "timestep_in_seconds", "initial_timestep_in_seconds", "max_timestep_in_seconds",
          "min_timestep_in_seconds", "interval_in_seconds", "max_time"),
    "m": ("depth", "depth_in_m", "depth_m", "BSS_cutoff_depth", "drying_depth", "wet/dry_depth", "value_in_m",
          "value_m", "length_m", "min_width_m", "dist_in_m", "distance", "snap_distance", "psd_m", "grid_cell_size",
          "cell_size", "height", "width", "top_width", "weir_height", "weir_width", "initial_breach_depth",
          "depth_collapse", "depth_fully_breached", "elevation", "IWL", "Z_inactive", "dZ", "dZ_limit_in_m",
          "offset", "y", "max_dist", "h_tol", "hrl", "hrlmin", "X_length", "Y_length", "OX", "OY", "X", "Y", "x",
          "zmin", "zmax", "y1", "y2"),
    "%": ("aep_value_in_%", "value_as_a_%", "aep_value", "min_pblockage"),
    "yr": ("ari_value_in_years",),
    "deg": ("angle", "slope_in_degree", "value_in_degrees_from_equator", "point_angle", "edge_angle"),
    "mm": ("IL",),
    "mm/h": ("CL",),
    "": ("value", "factor", "Cd", "Cf", "Ch", "CN_value", "Cr_max", "DF", "Ex", "K_CE", "K_RE", "Sa", "Sb", "SF",
         "WrF_value", "area_factor", "critical_h/d", "exponent", "float", "froude_no", "frequency",
         "maximum_frequency", "maximum_null_fraction", "max_K_bd", "null_value", "p", "ratio", "scale_factor",
         "slope", "tail_thickness_factor", "value_0.0_to_1.0", "vrl", "vrlmin", "maximum_delta_value", "flow",
         "speed", "period", "days_since_1900", "opening", "XX", "YX", "lower", "upper", "sxs_factor", "sxs_limits",
         "a", "b", "DLC", "ELC", "XLC"),
}
_NUM_INT = ("max_col", "max_count", "max_points", "max_pts", "max_rf_gauges", "mchan", "mp", "n_allowed_repeats",
            "no_iterations", "no_pumps", "number", "number_of_CPU_threads", "number_of_timesteps", "timesteps",
            "maximum_points", "level", "rows", "columns")
_NON_NEGATIVE = set(_NUM_UNITS["s"]) | {"depth", "depth_in_m", "depth_m", "BSS_cutoff_depth", "drying_depth",
                                        "wet/dry_depth", "length_m", "min_width_m", "dist_in_m", "distance",
                                        "snap_distance", "psd_m", "grid_cell_size", "cell_size", "height", "width",
                                        "top_width", "X_length", "Y_length", "interval_in_hours",
                                        "time_interval_in_hours", "initial_breach_depth", "Cd", "Cf", "factor",
                                        "area_factor", "IL", "CL", "h_tol", "hrl", "hrlmin", "vrl", "vrlmin",
                                        "value_0.0_to_1.0"} | set(_NUM_INT)
_LABELS = {"X_length": "X", "Y_length": "Y", "OX": "X", "OY": "Y", "rows": "N", "columns": "M", "zmin": "min",
           "zmax": "max", "lower": "lower", "upper": "upper", "point_angle": "point", "edge_angle": "edge",
           "sxs_factor": "factor", "sxs_limits": "limit", "XX": "XX", "YX": "YX", "x": "x", "y": "y",
           "X": "X", "Y": "Y", "y1": "y1", "y2": "y2", "Cd": "Cd", "Ex": "Ex", "a": "a", "b": "b"}
_UNIT_LABEL = {"deg": "°"}

# per-command overrides where the manual only says <value>
_KEY_NUMBER = {
    "Set Code": dict(is_int=True, lo=-1e6, hi=1e6),
    "Set Soil": dict(is_int=True, lo=0, hi=1e6),
    "Cell Size": dict(unit="m", lo=0),
    "Base Cell Size": dict(unit="m", lo=0),
    "RF Grid Cell Size": dict(unit="m", lo=0),
    "Output Grid Cell Size": dict(unit="m", lo=0),
    "Set Zpt": dict(unit="m"), "Set IWL": dict(unit="m"), "Default Land Z": dict(unit="m"),
    "Set GWL": dict(unit="m"), "Set GWD": dict(unit="m", lo=0),
    "Set Soil Thickness": dict(unit="m", lo=0), "Set Soil Base Elevation": dict(unit="m"),
    "Set IGW Level": dict(unit="m"), "Set IGW Depth": dict(unit="m", lo=0),
    "Orientation Angle": dict(unit="°", lo=-360, hi=360),
    "Density of Water": dict(unit="kg/m3", lo=0), "Density of Air": dict(unit="kg/m3", lo=0),
    "Global Rainfall Initial Loss": dict(unit="mm", lo=0), "Global Rainfall Continuing Loss": dict(unit="mm/h", lo=0),
}
_STEP = {"h": 0.25, "s": 1.0, "m": 0.1, "%": 1.0, "yr": 1.0, "deg": 1.0, "mm": 1.0, "mm/h": 0.5, "": 0.1}

_NAME_LISTS = {"If Scenario": "scenarios", "Else If Scenario": "scenarios", "Model Scenarios": "scenarios",
               "If Event": "events", "Else If Event": "events", "Model Events": "events"}
_NAME_COMBOS = {"Global Rainfall BC": ("bc", "BC name from the BC database"),
                "Global Wind BC": ("bc", "BC name from the BC database"),
                "Set Mat": ("materials", "material ID"),
                "Blank BC Type": ("bc_types", "BC type")}
BC_TYPES = [("HT", "water level vs time"), ("QT", "flow vs time"), ("HQ", "stage-discharge"),
            ("SA", "source area"), ("ST", "source vs time"), ("RF", "rainfall"), ("VG", "variable geometry"),
            ("HX", "1D/2D link"), ("SX", "1D/2D source link"), ("CN", "connection")]


def _number_part(name, key_override=None):
    if key_override is not None:
        unit = key_override.get("unit", "")
        is_int = key_override.get("is_int", False)
        lo = key_override.get("lo", -1e9)
        hi = key_override.get("hi", 1e9)
        return dict(unit=unit, is_int=is_int, lo=lo, hi=hi, step=1.0 if is_int else 0.1, label="")
    if name in _NUM_INT:
        return dict(unit="", is_int=True, lo=0, hi=1e9, step=1, label=_LABELS.get(name, ""))
    for unit, names in _NUM_UNITS.items():
        if name in names:
            lo = 0.0 if name in _NON_NEGATIVE else -1e9
            return dict(unit=_UNIT_LABEL.get(unit, unit), is_int=False, lo=lo, hi=1e9, step=_STEP[unit],
                        label=_LABELS.get(name, ""))
    return None


def number_parts(spec, placeholder):
    """Return a list of number parts for a placeholder like '<X_length>, <Y_length>'
    or None if it is not numeric."""
    names = re.findall(r"<([^>]+)>", placeholder)
    if len(names) == 1 and "," in names[0]:
        if "..." in names[0]:
            return None
        names = [n.strip() for n in names[0].split(",")]
    if not names:
        return None
    override = _KEY_NUMBER.get(spec.key) if len(names) == 1 else None
    parts = [_number_part(n, override) for n in names]
    if any(p is None for p in parts):
        return None
    return parts


def _is_number(text):
    return all(parse_number(x) is not None for x in str(text).split(",")) if text != "" else False


def make_value_editor(spec, base_dir_fn, parent=None, names_fn=None):
    """Return a widget with value()/setValue()/changed for a command spec.

    Picks radio buttons for short option lists, a dropdown for longer ones,
    number boxes with units for numeric values, X/Y pairs, file / layer pickers
    for inputs, and model-aware dropdowns (scenarios, events, BC names, material IDs)."""
    from ..core.essentials import MAP_DATA_TYPES, MAP_FORMATS
    names_fn = names_fn or (lambda kind: [])
    if spec is None:
        return TextEdit("value", parent)
    key = spec.key
    if key == "Map Output Data Types":
        return TokenListEdit(MAP_DATA_TYPES, parent, placeholder="pick data types")
    if key == "Map Output Format":
        return TokenListEdit([(f, "") for f in MAP_FORMATS], parent, placeholder="pick formats")
    if key in _NAME_LISTS:
        kind = _NAME_LISTS[key]
        return TokenListEdit(lambda k=kind: [(n, "") for n in names_fn(k)], parent, sep=" | ", button_text="v",
                             placeholder="{} names, separated by |".format(kind[:-1]))
    if key in _NAME_COMBOS:
        kind, ph = _NAME_COMBOS[key]
        fn = (lambda: BC_TYPES) if kind == "bc_types" else (lambda k=kind: names_fn(k))
        return NameCombo(fn, ph, parent)

    kind = spec.value_kind
    if kind in ("gis", "grid", "gis_out", "file", "folder", "file_or_choice", "folder_or_choice"):
        k = kind.replace("_or_choice", "")
        opts = spec.options if kind.endswith("_or_choice") else None
        return PathEdit(k, spec.file_filter, base_dir_fn, opts, parent,
                        open_label="Open" if (spec.child_type or spec.database) else None)
    if kind == "none":
        lbl = TextEdit("(no value)", parent)
        lbl.setEnabled(False)
        return lbl

    words = [o for o in spec.options if o and not _is_number(o)]
    num_default = next((o for o in spec.options if _is_number(o)), None)
    if spec.default and _is_number(spec.default):
        num_default = spec.default
    parts = None
    if len(spec.placeholders) == 1:
        parts = number_parts(spec, spec.placeholders[0])
    elif not spec.placeholders and key in _KEY_NUMBER:
        parts = [_number_part("value", _KEY_NUMBER[key])]

    if kind == "choice":
        if 2 <= len(spec.options) <= 3 and all(len(o) <= 22 for o in spec.options):
            return RadioChoice(spec.options, spec.default, parent)
        return ChoiceEdit(spec.options, False, spec.default, parent)

    if parts:
        default = num_default if (num_default is not None and len(str(num_default).split(",")) == len(parts)) else None
        if not words:
            return NumberEdit(parts, default, parent)
        if len(words) <= 3:
            return OptionValueEdit(words, NumberEdit(parts, default), spec.default, parent)
        return ChoiceEdit(spec.options, True, spec.default, parent)

    if kind == "choice_edit":
        if words and len(words) <= 3 and len(spec.placeholders) == 1:
            ph = spec.placeholders[0]
            return OptionValueEdit(words, TextEdit(ph), spec.default, parent)
        return ChoiceEdit(spec.options, True, spec.default, parent)
    return TextEdit(" | ".join(spec.placeholders), parent)


# ---------------------------------------------------------------------------
class LineChart(QWidget):
    """Tiny dependency-free line chart (time series, mass balance, timestep)."""
    PALETTE = [QColor("#1f77b4"), QColor("#d62728"), QColor("#2ca02c"), QColor("#9467bd"),
               QColor("#ff7f0e"), QColor("#17becf"), QColor("#8c564b")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.series = []
        self.hlines = []
        self.title = ""
        self.xlabel = ""
        self.ylabel = ""
        self.setMinimumHeight(220)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_data(self, series, title="", xlabel="", ylabel="", hlines=None):
        """series: [(name, xs, ys)]; hlines: [(y, label, color)]"""
        self.series = [(n, list(x), list(y)) for n, x, y in series if x and y]
        self.title, self.xlabel, self.ylabel = title, xlabel, ylabel
        self.hlines = hlines or []
        self.update()

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect()
        p.fillRect(r, self.palette().base())
        fm = QFontMetrics(self.font())
        ml, mr, mt, mb = 64, 16, 28, 40
        plot = QRectF(r.left() + ml, r.top() + mt, r.width() - ml - mr, r.height() - mt - mb)
        text_col = self.palette().text().color()
        p.setPen(text_col)
        p.drawText(QRectF(r.left(), r.top() + 4, r.width(), 20), Qt.AlignmentFlag.AlignHCenter, self.title)
        if not self.series or plot.width() < 20 or plot.height() < 20:
            p.drawText(plot, Qt.AlignmentFlag.AlignCenter, "No data")
            return
        xs = [x for _, sx, _ in self.series for x in sx]
        ys = [y for _, _, sy in self.series for y in sy] + [h[0] for h in self.hlines]
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        if x1 == x0:
            x1 = x0 + 1
        if y1 == y0:
            y0, y1 = y0 - 1, y1 + 1
        pad = (y1 - y0) * 0.05
        y0, y1 = y0 - pad, y1 + pad

        def tx(x):
            return plot.left() + (x - x0) / (x1 - x0) * plot.width()

        def ty(y):
            return plot.bottom() - (y - y0) / (y1 - y0) * plot.height()
        grid = QPen(QColor(128, 128, 128, 60))
        p.setPen(grid)
        for i in range(6):
            yy = y0 + (y1 - y0) * i / 5.0
            p.drawLine(QPointF(plot.left(), ty(yy)), QPointF(plot.right(), ty(yy)))
            p.setPen(text_col)
            p.drawText(QRectF(r.left(), ty(yy) - 8, ml - 6, 16), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                       "{:.4g}".format(yy))
            p.setPen(grid)
        for i in range(6):
            xx = x0 + (x1 - x0) * i / 5.0
            p.drawLine(QPointF(tx(xx), plot.top()), QPointF(tx(xx), plot.bottom()))
            p.setPen(text_col)
            p.drawText(QRectF(tx(xx) - 30, plot.bottom() + 2, 60, 16), Qt.AlignmentFlag.AlignHCenter, "{:.4g}".format(xx))
            p.setPen(grid)
        p.setPen(text_col)
        p.drawRect(plot)
        p.drawText(QRectF(plot.left(), r.bottom() - 18, plot.width(), 16), Qt.AlignmentFlag.AlignHCenter, self.xlabel)
        p.save()
        p.translate(r.left() + 12, plot.center().y())
        p.rotate(-90)
        p.drawText(QRectF(-plot.height() / 2, -10, plot.height(), 16), Qt.AlignmentFlag.AlignHCenter, self.ylabel)
        p.restore()
        for y, label, col in self.hlines:
            pen = QPen(QColor(col))
            pen.setStyle(Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.drawLine(QPointF(plot.left(), ty(y)), QPointF(plot.right(), ty(y)))
            p.drawText(QPointF(plot.left() + 4, ty(y) - 3), label)
        for i, (name, sx, sy) in enumerate(self.series):
            col = self.PALETTE[i % len(self.PALETTE)]
            pen = QPen(col)
            pen.setWidthF(1.6)
            p.setPen(pen)
            path = QPainterPath()
            step = max(1, len(sx) // 4000)
            first = True
            for x, y in list(zip(sx, sy))[::step]:
                pt = QPointF(tx(x), ty(y))
                if first:
                    path.moveTo(pt)
                    first = False
                else:
                    path.lineTo(pt)
            p.drawPath(path)
            ly = plot.top() + 6 + i * (fm.height() + 2)
            p.fillRect(QRectF(plot.right() - 150, ly + 4, 12, 4), QBrush(col))
            p.setPen(text_col)
            p.drawText(QPointF(plot.right() - 134, ly + fm.ascent() - 2), name[:22])


# ---------------------------------------------------------------------------
def _flags(*values):
    """OR Qt enum values as an int (works for PyQt5 and PyQt6 enums)."""
    out = 0
    for v in values:
        out |= int(getattr(v, "value", v))
    return out


class ExplainDelegate(QStyledItemDelegate):
    """Tree item delegate that paints the item text with a grey, word-wrapped explanation
    underneath. The explanation is read from `role`; items without it are painted normally.
    Set `enabled` to False (and call view.doItemsLayout()) for a compact list."""

    def __init__(self, view, role, parent=None):
        super().__init__(parent or view)
        self.view = view
        self.role = role
        self.enabled = True
        header = getattr(view, "header", None)
        if header is not None:
            header().sectionResized.connect(lambda *_a: view.doItemsLayout())

    def _sub(self, index):
        return index.data(self.role) if self.enabled else None

    @staticmethod
    def _small(font):
        f = QFont(font)
        f.setBold(False)
        if f.pointSizeF() > 0:
            f.setPointSizeF(max(6.5, f.pointSizeF() * 0.92))
        return f

    def _text_width(self, option, index):
        w = option.rect.width()
        if w <= 0:
            depth, p = 0, index.parent()
            while p.isValid():
                depth += 1
                p = p.parent()
            ind = self.view.indentation() * (depth + (1 if self.view.rootIsDecorated() else 0))
            w = self.view.columnWidth(index.column()) - ind
        return max(80, w - 10)

    def sizeHint(self, option, index):
        base = super().sizeHint(option, index)
        sub = self._sub(index)
        if not sub:
            return base
        fm = QFontMetrics(self._small(option.font))
        r = fm.boundingRect(QRect(0, 0, self._text_width(option, index), 100000),
                            _flags(Qt.TextFlag.TextWordWrap, Qt.AlignmentFlag.AlignLeft), sub)
        return QSize(base.width(), base.height() + r.height() + 5)

    def paint(self, painter, option, index):
        sub = self._sub(index)
        if not sub:
            super().paint(painter, option, index)
            return
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        title = opt.text
        opt.text = ""
        style = opt.widget.style() if opt.widget is not None else QApplication.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)
        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        rect = opt.rect.adjusted(4, 2, -4, -2)
        fm = QFontMetrics(opt.font)
        h = fm.height()
        painter.save()
        if selected:
            tcol = opt.palette.color(QPalette.ColorRole.HighlightedText)
            scol = tcol
        else:
            brush = index.data(Qt.ItemDataRole.ForegroundRole)
            tcol = brush.color() if isinstance(brush, QBrush) else opt.palette.color(QPalette.ColorRole.Text)
            scol = QColor(105, 105, 105)
        painter.setFont(opt.font)
        painter.setPen(tcol)
        painter.drawText(QRect(rect.left(), rect.top(), rect.width(), h),
                         _flags(Qt.AlignmentFlag.AlignLeft, Qt.AlignmentFlag.AlignVCenter),
                         fm.elidedText(title, Qt.TextElideMode.ElideRight, rect.width()))
        painter.setFont(self._small(opt.font))
        painter.setPen(scol)
        painter.drawText(QRect(rect.left() + 2, rect.top() + h + 1, rect.width() - 2, rect.height() - h),
                         _flags(Qt.TextFlag.TextWordWrap, Qt.AlignmentFlag.AlignLeft, Qt.AlignmentFlag.AlignTop), sub)
        painter.restore()


# ---------------------------------------------------------------------------
def clipboard_rows(text):
    """Clipboard text -> list of rows of cells (tab separated from Excel, or CSV)."""
    import csv
    import io
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    if text.endswith("\n"):
        text = text[:-1]
    if not text:
        return []
    if "\t" in text:
        return [ln.split("\t") for ln in text.split("\n")]
    if "," in text and "\n" in text:
        return [r for r in csv.reader(io.StringIO(text))]
    return [[ln] for ln in text.split("\n")]


class TableClipboard(QObject):
    """Excel-style Copy / Paste / Delete for a QTableWidget: Ctrl+C copies the selected block
    as tab-separated text, Ctrl+V pastes a block at the current cell (adding rows, and columns
    when `add_column` is given), a single value fills every selected cell, Delete clears."""

    def __init__(self, table, add_column=None):
        super().__init__(table)
        self.table = table
        self.add_column = add_column
        table.installEventFilter(self)
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        table.customContextMenuRequested.connect(self._menu)

    def eventFilter(self, obj, ev):
        if obj is self.table and ev.type() == QEvent.Type.KeyPress and \
                self.table.state() != QAbstractItemView.State.EditingState:
            if ev.matches(QKeySequence.StandardKey.Copy):
                self.copy()
                return True
            if ev.matches(QKeySequence.StandardKey.Paste):
                self.paste()
                return True
            if ev.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
                self.clear()
                return True
        return False

    def _menu(self, pos):
        m = QMenu(self.table)
        m.addAction("Copy", self.copy)
        a = m.addAction("Paste", self.paste)
        a.setEnabled(bool(QApplication.clipboard().text()))
        m.addAction("Clear cells", self.clear)
        (getattr(m, "exec", None) or getattr(m, "exec_"))(self.table.viewport().mapToGlobal(pos))

    def _selected(self):
        return [(i.row(), i.column()) for i in self.table.selectedIndexes()]

    def copy(self):
        cells = self._selected()
        if not cells:
            return
        r0, r1 = min(r for r, _c in cells), max(r for r, _c in cells)
        c0, c1 = min(c for _r, c in cells), max(c for _r, c in cells)
        lines = []
        for r in range(r0, r1 + 1):
            row = []
            for c in range(c0, c1 + 1):
                it = self.table.item(r, c)
                row.append(it.text() if it is not None and (r, c) in cells else "")
            lines.append("\t".join(row))
        QApplication.clipboard().setText("\n".join(lines))

    def _set(self, r, c, text):
        it = self.table.item(r, c)
        if it is None:
            it = QTableWidgetItem("")
            self.table.setItem(r, c, it)
        it.setText(text)

    def paste(self):
        rows = clipboard_rows(QApplication.clipboard().text())
        if not rows:
            return
        cells = self._selected()
        if len(rows) == 1 and len(rows[0]) == 1 and len(cells) > 1:      # fill the selection
            for r, c in cells:
                self._set(r, c, rows[0][0].strip())
            return
        if cells:
            r0, c0 = min(r for r, _c in cells), min(c for _r, c in cells)
        else:
            r0, c0 = max(self.table.currentRow(), 0), max(self.table.currentColumn(), 0)
        need_rows = r0 + len(rows)
        if need_rows > self.table.rowCount():
            self.table.setRowCount(need_rows)
        need_cols = c0 + max(len(r) for r in rows)
        while self.add_column is not None and self.table.columnCount() < need_cols:
            before = self.table.columnCount()
            self.add_column()
            if self.table.columnCount() == before:
                break
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                if c0 + j < self.table.columnCount():
                    self._set(r0 + i, c0 + j, val.strip())

    def clear(self):
        for r, c in self._selected():
            it = self.table.item(r, c)
            if it is not None and it.flags() & Qt.ItemFlag.ItemIsEditable:
                it.setText("")
