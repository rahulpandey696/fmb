# -*- coding: utf-8 -*-
"""
Export the live FMB tools interface to Qt Designer .ui files.

Every tab is written with its real layouts, widgets, texts, tooltips, ranges and object
names (the Python attribute names), so it opens in Qt Designer for viewing and editing.
FMB widgets are written as promoted widgets (see designer_widgets.py) with their settings as
fmb* dynamic properties. The Project tab is *loaded* from ui/designer/project_tab.ui at run
time; the other tabs are still built in Python - their .ui files are a faithful reference /
starting point (see ui/designer/README.md).

    from fmb_tools.ui.designer_export import export_all
    export_all(main_dialog, "C:/temp/fmb_ui")
"""
import os
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import Qt, QObject
from qgis.PyQt.QtWidgets import (QWidget, QLayout, QBoxLayout, QGridLayout, QFormLayout, QTabWidget, QSplitter,
                                 QScrollArea, QStackedWidget, QGroupBox, QLabel, QAbstractButton, QLineEdit, QComboBox,
                                 QAbstractSpinBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit, QTreeWidget,
                                 QTableWidget, QAbstractItemView, QFrame, QCheckBox, QRadioButton, QToolButton,
                                 QDialog, QSizePolicy, QMenu)

from . import widgets as W

HEADER = "fmb_tools/ui/designer_widgets.h"
# FMB widget class -> (name in the .ui, Qt base class)
PROMOTE = [
    (W.SmartDoubleSpin, "SmartDoubleSpin", "QDoubleSpinBox"), (W.SmartIntSpin, "SmartIntSpin", "QSpinBox"),
    (W.NumberSpin, "FmbNumberSpin", "QDoubleSpinBox"), (W.NumberEdit, "FmbNumberEdit", "QWidget"),
    (W.PathEdit, "FmbPathEdit", "QWidget"), (W.RadioChoice, "FmbRadioChoice", "QWidget"),
    (W.TokenListEdit, "FmbTokenListEdit", "QWidget"), (W.ChoiceEdit, "FmbChoiceEdit", "QComboBox"),
    (W.LogView, "FmbLogView", "QWidget"), (W.LineChart, "LineChart", "QWidget"),
]
QT_MODULES = ("PyQt5.", "PyQt6.", "qgis.PyQt.", "sip")


class Exporter(object):
    def __init__(self, root, class_name, placeholders=None):
        self.root = root
        self.class_name = class_name
        self.placeholders = placeholders or {}       # widget -> text: write a placeholder page instead
        self.names = {}
        self.used = set()
        self.custom = {}
        self._collect_names(root)

    # -- names -------------------------------------------------------------------
    def _collect_names(self, obj, depth=0):
        if depth > 2:
            return
        for attr, val in list(getattr(obj, "__dict__", {}).items()):
            if isinstance(val, QObject) and id(val) not in self.names and not attr.startswith("__"):
                self.names[id(val)] = attr.lstrip("_") or attr
                if isinstance(val, QWidget) and not self._leaf(val) and depth < 2 and val is not obj:
                    self._collect_names(val, depth + 1)

    def _name(self, obj, prefix):
        n = obj.objectName() or self.names.get(id(obj)) or ""
        n = "".join(c if c.isalnum() or c == "_" else "_" for c in n) or prefix
        base, i = n, 2
        if n == prefix:
            n = "{}_{}".format(prefix, i)
        while n in self.used:
            n = "{}_{}".format(base, i)
            i += 1
        self.used.add(n)
        return n

    # -- classes -----------------------------------------------------------------
    @staticmethod
    def _qt_base(w):
        for c in type(w).__mro__:
            if c.__module__.startswith(QT_MODULES) or c.__module__ in ("PyQt5.QtWidgets", "PyQt6.QtWidgets"):
                return c.__name__
        return "QWidget"

    def _class(self, w):
        for cls, name, base in PROMOTE:
            if isinstance(w, cls):
                self.custom[name] = (base, HEADER)
                return name
        mod = type(w).__module__
        if mod.startswith("qgis.gui") or mod.startswith("qgis._gui"):
            name = type(w).__name__
            self.custom[name] = (self._qt_base(w), name.lower() + ".h")
            return name
        return self._qt_base(w)

    def _leaf(self, w):
        return any(isinstance(w, cls) for cls, _n, _b in PROMOTE) or type(w).__module__.startswith(("qgis.gui", "qgis._gui"))

    # -- properties ---------------------------------------------------------------
    @staticmethod
    def _p(el, name, value, kind=None, stdset=True):
        p = ET.SubElement(el, "property", name=name)
        if not stdset:
            p.set("stdset", "0")
        if kind is None:
            kind = {bool: "bool", int: "number", float: "double"}.get(type(value), "string")
        if kind == "bool":
            ET.SubElement(p, "bool").text = "true" if value else "false"
        elif kind == "size":
            s = ET.SubElement(p, "size")
            ET.SubElement(s, "width").text = str(int(value[0]))
            ET.SubElement(s, "height").text = str(int(value[1]))
        elif kind in ("enum", "set", "number", "double"):
            ET.SubElement(p, kind).text = str(value)
        else:
            ET.SubElement(p, "string").text = str(value)

    def _props(self, w, el, top=False):
        P = self._p
        tip = w.toolTip()
        if tip:
            P(el, "toolTip", tip)
        if not w.isEnabled() and not top:
            P(el, "enabled", False)
        ms, mx = w.minimumSize(), w.maximumSize()
        if (ms.width() or ms.height()) and not isinstance(w, (QLabel,)):
            P(el, "minimumSize", (ms.width(), ms.height()), "size")
        if mx.width() < 16777215 or mx.height() < 16777215:
            P(el, "maximumSize", (min(mx.width(), 16777215), min(mx.height(), 16777215)), "size")
        if w.styleSheet():
            P(el, "styleSheet", w.styleSheet())
        if self._leaf(w):
            props = getattr(w, "designer_properties", None)
            if props:
                for k, v in props().items():
                    if v not in (None, ""):
                        P(el, k, v, stdset=False)
            if isinstance(w, QAbstractSpinBox):
                self._spin_props(w, el)
            if isinstance(w, QComboBox):
                self._combo_props(w, el)
            return
        if isinstance(w, QGroupBox):
            P(el, "title", w.title())
            if w.isCheckable():
                P(el, "checkable", True)
                P(el, "checked", w.isChecked())
        elif isinstance(w, QLabel):
            P(el, "text", w.text())
            if w.wordWrap():
                P(el, "wordWrap", True)
            if w.openExternalLinks():
                P(el, "openExternalLinks", True)
        elif isinstance(w, QAbstractButton):
            P(el, "text", w.text())
            if w.isCheckable() and not isinstance(w, (QCheckBox, QRadioButton)):
                P(el, "checkable", True)
            if w.isCheckable() and w.isChecked():
                P(el, "checked", True)
            if isinstance(w, QToolButton) and w.autoRaise():
                P(el, "autoRaise", True)
        elif isinstance(w, QLineEdit):
            if w.text():
                P(el, "text", w.text())
            if w.placeholderText():
                P(el, "placeholderText", w.placeholderText())
            if w.isReadOnly():
                P(el, "readOnly", True)
        elif isinstance(w, QComboBox):
            self._combo_props(w, el)
        elif isinstance(w, QAbstractSpinBox):
            self._spin_props(w, el)
        elif isinstance(w, (QPlainTextEdit, QTextEdit)):
            if w.isReadOnly():
                P(el, "readOnly", True)
            if w.placeholderText():
                P(el, "placeholderText", w.placeholderText())
        elif isinstance(w, QTreeWidget):
            if w.isHeaderHidden():
                P(el, "headerHidden", True)
            hi = w.headerItem()
            for c in range(w.columnCount()):
                col = ET.SubElement(el, "column")
                self._p(col, "text", hi.text(c) if hi is not None else "")
        elif isinstance(w, QTableWidget):
            for c in range(w.columnCount()):
                it = w.horizontalHeaderItem(c)
                col = ET.SubElement(el, "column")
                self._p(col, "text", it.text() if it is not None else str(c + 1))
        elif isinstance(w, QSplitter):
            P(el, "orientation", "Qt::Horizontal" if w.orientation() == Qt.Orientation.Horizontal else "Qt::Vertical",
              "enum")
        elif isinstance(w, QScrollArea):
            P(el, "widgetResizable", w.widgetResizable())
        if isinstance(w, QFrame) and not isinstance(w, (QLabel, QAbstractItemView, QPlainTextEdit, QTextEdit,
                                                        QScrollArea, QSplitter, QGroupBox, QStackedWidget)) \
                and type(w).__name__ == "QFrame":
            shape = {QFrame.Shape.StyledPanel: "QFrame::StyledPanel", QFrame.Shape.Box: "QFrame::Box",
                     QFrame.Shape.HLine: "QFrame::HLine", QFrame.Shape.VLine: "QFrame::VLine",
                     QFrame.Shape.Panel: "QFrame::Panel"}.get(w.frameShape())
            if shape:
                P(el, "frameShape", shape, "enum")

    def _combo_props(self, w, el):
        if w.isEditable():
            self._p(el, "editable", True)
        for i in range(w.count()):
            it = ET.SubElement(el, "item")
            self._p(it, "text", w.itemText(i))

    def _spin_props(self, w, el):
        P = self._p
        if isinstance(w, QSpinBox):
            P(el, "minimum", w.minimum(), "number")
            P(el, "maximum", w.maximum(), "number")
            P(el, "value", w.value(), "number")
        elif isinstance(w, QDoubleSpinBox):
            P(el, "decimals", w.decimals(), "number")
            P(el, "minimum", repr(float(w.minimum())), "double")
            P(el, "maximum", repr(float(w.maximum())), "double")
            P(el, "singleStep", repr(float(w.singleStep())), "double")
            P(el, "value", repr(float(w.value())), "double")
        if w.suffix():
            P(el, "suffix", w.suffix())
        if w.prefix():
            P(el, "prefix", w.prefix())
        if w.specialValueText():
            P(el, "specialValueText", w.specialValueText())

    # -- tree ----------------------------------------------------------------------
    def widget(self, w, top=False):
        cls = "QDialog" if top and isinstance(w, QDialog) else ("QWidget" if top else self._class(w))
        if top and isinstance(w, QGroupBox):
            cls = "QGroupBox"
        name = self.class_name if top else self._name(w, cls.lstrip("Q").lower())
        el = ET.Element("widget", {"class": cls, "name": name})
        if top:
            g = ET.SubElement(el, "property", name="geometry")
            r = ET.SubElement(g, "rect")
            for k, v in (("x", 0), ("y", 0), ("width", max(w.width(), 400)), ("height", max(w.height(), 300))):
                ET.SubElement(r, k).text = str(v)
            if w.windowTitle():
                self._p(el, "windowTitle", w.windowTitle())
        self._props(w, el, top)
        if w in self.placeholders:
            lay = ET.SubElement(el, "layout", {"class": "QVBoxLayout", "name": self._name(w, "layout")})
            item = ET.SubElement(lay, "item")
            lab = ET.SubElement(item, "widget", {"class": "QLabel", "name": self._name(w, "placeholder")})
            self._p(lab, "text", self.placeholders[w])
            self._p(lab, "alignment", "Qt::AlignCenter", "set")
            return el
        if self._leaf(w) and not top:
            return el
        if isinstance(w, QTabWidget):
            for i in range(w.count()):
                page = w.widget(i)
                pel = self.widget(page)
                a = ET.SubElement(pel, "attribute", name="title")
                ET.SubElement(a, "string").text = w.tabText(i)
                el.append(pel)
            self._p(el, "currentIndex", 0, "number")
            return el
        if isinstance(w, QStackedWidget):
            for i in range(w.count()):
                el.append(self.widget(w.widget(i)))
            return el
        if isinstance(w, QSplitter):
            for i in range(w.count()):
                el.append(self.widget(w.widget(i)))
            return el
        if isinstance(w, QScrollArea):
            if w.widget() is not None:
                el.append(self.widget(w.widget()))
            return el
        if isinstance(w, QAbstractItemView):
            return el
        lay = w.layout()
        if lay is not None:
            el.append(self.layout(lay))
        return el

    def layout(self, lay):
        cls = type(lay).__name__
        if not cls.startswith("Q"):
            for c in type(lay).__mro__:
                if c.__name__ in ("QVBoxLayout", "QHBoxLayout", "QGridLayout", "QFormLayout"):
                    cls = c.__name__
                    break
        if cls == "QBoxLayout":
            cls = "QVBoxLayout" if lay.direction() in (QBoxLayout.Direction.TopToBottom,
                                                        QBoxLayout.Direction.BottomToTop) else "QHBoxLayout"
        el = ET.Element("layout", {"class": cls, "name": self._name(lay, "layout")})
        m = lay.contentsMargins()
        for side, v in (("leftMargin", m.left()), ("topMargin", m.top()), ("rightMargin", m.right()),
                        ("bottomMargin", m.bottom())):
            self._p(el, side, v, "number")
        if lay.spacing() >= 0:
            self._p(el, "spacing", lay.spacing(), "number")
        if isinstance(lay, QBoxLayout):
            st = [lay.stretch(i) for i in range(lay.count())]
            if any(st):
                el.set("stretch", ",".join(str(x) for x in st))
        if isinstance(lay, QGridLayout):
            rs = [lay.rowStretch(r) for r in range(lay.rowCount())]
            cs = [lay.columnStretch(c) for c in range(lay.columnCount())]
            if any(rs):
                el.set("rowstretch", ",".join(str(x) for x in rs))
            if any(cs):
                el.set("columnstretch", ",".join(str(x) for x in cs))
        for i in range(lay.count()):
            item = lay.itemAt(i)
            attrs = {}
            if isinstance(lay, QGridLayout):
                r, c, rs, cs = lay.getItemPosition(i)
                attrs = {"row": str(r), "column": str(c)}
                if rs > 1:
                    attrs["rowspan"] = str(rs)
                if cs > 1:
                    attrs["colspan"] = str(cs)
            elif isinstance(lay, QFormLayout):
                r, role = lay.getItemPosition(i)
                if r < 0:
                    continue
                if role == QFormLayout.ItemRole.SpanningRole:
                    attrs = {"row": str(r), "column": "0", "colspan": "2"}
                else:
                    attrs = {"row": str(r), "column": "0" if role == QFormLayout.ItemRole.LabelRole else "1"}
            child = self._item(item)
            if child is None:
                continue
            it = ET.SubElement(el, "item", attrs)
            it.append(child)
        return el

    def _item(self, item):
        if item.widget() is not None:
            w = item.widget()
            if isinstance(w, QMenu):
                return None
            return self.widget(w)
        if item.layout() is not None:
            return self.layout(item.layout())
        sp = item.spacerItem()
        if sp is not None:
            el = ET.Element("spacer", name=self._name(sp if isinstance(sp, QObject) else QObject(), "spacer"))
            vert = bool(sp.expandingDirections() & Qt.Orientation.Vertical)
            self._p(el, "orientation", "Qt::Vertical" if vert else "Qt::Horizontal", "enum")
            h = sp.sizeHint()
            self._p(el, "sizeHint", (h.width() or (0 if vert else 40), h.height() or (40 if vert else 0)), "size",
                    stdset=False)
            return el
        return None

    def document(self):
        top = self.widget(self.root, top=True)
        ui = ET.Element("ui", version="4.0")
        ET.SubElement(ui, "class").text = self.class_name
        ui.append(top)
        if self.custom:
            cws = ET.SubElement(ui, "customwidgets")
            for name, (base, header) in sorted(self.custom.items()):
                cw = ET.SubElement(cws, "customwidget")
                ET.SubElement(cw, "class").text = name
                ET.SubElement(cw, "extends").text = base
                ET.SubElement(cw, "header").text = header
        ET.SubElement(ui, "resources")
        ET.SubElement(ui, "connections")
        return ui


def export_widget(widget, class_name, path, placeholders=None):
    ex = Exporter(widget, class_name, placeholders)
    ui = ex.document()
    try:
        ET.indent(ui, space=" ")
    except AttributeError:          # Python < 3.9
        pass
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    ET.ElementTree(ui).write(path, encoding="UTF-8", xml_declaration=True)
    return path


# file name, object name, how to find the widget on the main dialog
TAB_FILES = [
    ("main_dialog.ui", "MainDialog", lambda d: d),
    ("empty_layers_tab.ui", "EmptyLayersTab", lambda d: d.empty_tab),
    ("control_file_editor.ui", "ControlFileEditor", lambda d: d.editors["TCF"]),
    ("event_wizard.ui", "EventWizard", lambda d: d.event_wizard),
    ("databases_tab.ui", "DatabaseTab", lambda d: d.db_tab),
    ("batch_run_tab.ui", "BatchTab", lambda d: d.batch_tab),
    ("qc_tab.ui", "QcTab", lambda d: d.qc_tab),
    ("logs_tab.ui", "LogsTab", lambda d: d.logs_tab),
    ("stability_tab.ui", "ResultsTab", lambda d: d.results_tab),
    ("outputs_tab.ui", "OutputsTab", lambda d: d.outputs_tab),
    ("help_tab.ui", "HelpTab", lambda d: d.help_tab),
]


def export_all(dialog, folder, include_project=True):
    """Write a .ui file for the main window and every tab into `folder`. Returns the paths."""
    out = []
    page_files = {}
    for fname, _cls, get in TAB_FILES[1:]:
        try:
            page_files[get(dialog)] = fname
        except Exception:
            pass
    page_files[dialog.project_tab] = "project_tab.ui"
    if hasattr(dialog, "tef_host"):
        page_files[dialog.tef_host] = "event_wizard.ui + control_file_editor.ui"
    for ft, ed in getattr(dialog, "editors", {}).items():
        page_files.setdefault(ed, "control_file_editor.ui ({})".format(ft))
    for fname, cls, get in TAB_FILES:
        try:
            w = get(dialog)
        except Exception:
            continue
        ph = {}
        if fname == "main_dialog.ui":
            ph = {page: "This tab is in  {}".format(f) for page, f in page_files.items()}
            other = getattr(dialog, "other_tabs", None)
            if other is not None:
                ph[other] = "Other control files (QCF, TRFC, TOC, TESF, TSCF, ADCF) - control_file_editor.ui"
        out.append(export_widget(w, cls, os.path.join(folder, fname), ph))
    try:
        from .folders_dialog import FolderStructureDialog
        dlg = FolderStructureDialog("", dialog)
        out.append(export_widget(dlg, "FolderStructureDialog", os.path.join(folder, "folders_dialog.ui")))
        dlg.deleteLater()
    except Exception:
        pass
    if include_project:
        out.append(export_widget(dialog.project_tab, "ProjectTabSnapshot",
                                 os.path.join(folder, "project_tab_snapshot.ui")))
    return out
