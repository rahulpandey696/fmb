# -*- coding: utf-8 -*-
"""
Pre-run quality checks on the model set-up (no TUFLOW run needed).
Each check returns Finding objects with a severity, a message, a fix hint and
a link to the relevant manual/wiki page.
"""
import csv
import io
import os
import re
import sqlite3

from .catalog import catalog, manual_url
from .control_file import split_value_paths, looks_like_path, resolve_path, substitute_tokens, TOKEN_RE
from .essentials import REQUIRED

ERROR, WARNING, INFO, PASS = "ERROR", "WARNING", "INFO", "PASS"
SEVERITY_ORDER = {ERROR: 0, WARNING: 1, INFO: 2, PASS: 3}


class Finding(object):
    __slots__ = ("severity", "ftype", "message", "hint", "url", "key")

    def __init__(self, severity, ftype, message, hint="", url="", key=""):
        self.severity = severity
        self.ftype = ftype
        self.message = message
        self.hint = hint
        self.url = url
        self.key = key

    def __repr__(self):
        return "[{}] {}: {}".format(self.severity, self.ftype, self.message)


def _num(text, default=None):
    if text is None:
        return default
    m = re.search(r"-?\d+(\.\d+)?([eE]-?\d+)?", str(text))
    return float(m.group(0)) if m else default


def gpkg_layers(path):
    """List layer names in a GeoPackage without needing QGIS."""
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(path.replace("\\", "/")), uri=True)
        try:
            rows = con.execute("SELECT table_name FROM gpkg_contents").fetchall()
        finally:
            con.close()
        return [r[0] for r in rows]
    except Exception:
        return None


def _file_variants(path):
    """TUFLOW lets you omit the extension of GIS layers."""
    if os.path.splitext(path)[1]:
        return [path]
    return [path + e for e in (".shp", ".mif", ".gpkg", ".tif", ".asc", ".flt", ".csv")]


class ModelChecker(object):
    def __init__(self, project, scenarios=None, events=None, cn_thresholds=None):
        self.p = project
        self.scenarios = scenarios if scenarios is not None else project.state.get("scenarios", [])
        self.events = events if events is not None else project.state.get("events", [])
        self.findings = []

    def add(self, sev, ftype, msg, hint="", url="", key=""):
        self.findings.append(Finding(sev, ftype, msg, hint, url, key))

    # ---------------------------------------------------------------
    def run(self):
        self.findings = []
        tcf = self.p.files.get("TCF")
        if tcf is None:
            self.add(ERROR, "TCF", "No TUFLOW Control File (.tcf) defined.", "Create or open a model in the Project tab.")
            return self.findings
        self.check_required()
        self.check_blocks()
        self.check_unknown_commands()
        self.check_files_exist()
        self.check_solver()
        self.check_time()
        self.check_geometry()
        self.check_materials()
        self.check_bc_database()
        self.check_events()
        self.check_rainfall()
        self.check_outputs()
        self.check_one_d()
        if not any(f.severity in (ERROR, WARNING) for f in self.findings):
            self.add(PASS, "ALL", "No errors or warnings found in the set-up checks.",
                     "Run TUFLOW in test mode (-t) to let TUFLOW write its own check files.")
        self.findings.sort(key=lambda f: SEVERITY_ORDER[f.severity])
        return self.findings

    # ---------------------------------------------------------------
    def check_required(self):
        for ftype, cf in self.p.files.items():
            for key in REQUIRED.get(ftype, []):
                if ftype == "TEF" or ftype == "TOC":
                    continue
                if ftype == "TGC" and key in ("Grid Size (X,Y)", "Cell Size") and self._quadtree_or_location(key):
                    continue
                hits = cf.find(key)
                spec, _ = catalog().match(ftype, key)
                url = spec.url if spec else ""
                if not hits:
                    sev = ERROR
                    if ftype == "TCF" and key in ("Solution Scheme",):
                        sev = WARNING
                    if ftype == "TCF" and key == "BC Database" and not self._has_bcs():
                        sev = INFO
                    self.add(sev, ftype, "'{}' is not set.".format(key), "Add it from the Essentials list.", url, key)
                elif spec is not None and spec.has_value and not hits[-1].value.strip():
                    self.add(ERROR, ftype, "'{}' has no value.".format(key), "Fill in the value.", url, key)

    def _quadtree_or_location(self, key):
        tgc = self.p.files.get("TGC")
        if key == "Grid Size (X,Y)" and tgc and (tgc.find("Grid Size (N,M)") or tgc.find("Read Grid Location")):
            return True
        if key == "Cell Size" and "QCF" in self.p.files and self.p.files["QCF"].value("Base Cell Size"):
            return True
        return False

    def _has_bcs(self):
        tbc = self.p.files.get("TBC")
        ecf = self.p.files.get("ECF")
        keys = ("Read GIS BC", "Read GIS SA", "Read GIS RF", "Global Rainfall BC")
        return any(cf and cf.find(k) for cf in (tbc, ecf) for k in keys)

    def check_blocks(self):
        for ftype, cf in self.p.files.items():
            for line, msg in cf.block_errors():
                self.add(ERROR, ftype, "Line {}: {}".format(line, msg), "Balance If/Else/End If and Define/End Define blocks.")

    def check_unknown_commands(self):
        for ftype, cf in self.p.files.items():
            for e in cf.commands():
                if e.spec is None:
                    self.add(WARNING, ftype, "Command not recognised: '{}'".format(e.lhs),
                             "Check spelling against the manual (commands are not case sensitive).",
                             manual_url(None, ftype), e.lhs)

    # ---------------------------------------------------------------
    def _variables(self):
        tcf = self.p.files.get("TCF")
        vars_ = {}
        if tcf:
            for e in tcf.commands():
                if e.lhs.lower().startswith("set variable"):
                    vars_[e.lhs[12:].strip().lower()] = e.value
        return vars_

    def check_files_exist(self):
        variables = self._variables()
        spatial_db = {}
        for ftype, cf in self.p.files.items():
            base = os.path.dirname(cf.path) if cf.path else self.p.dir_of(ftype)
            sdb = cf.value("Spatial Database")
            if sdb and sdb.upper() not in ("OFF", "TCF"):
                spatial_db[ftype] = resolve_path(substitute_tokens(sdb, self.scenarios, self.events, variables), base)
        tcf_db = spatial_db.get("TCF")
        for ftype, db in spatial_db.items():
            if not TOKEN_RE.search(db) and not os.path.isfile(db):
                self.add(ERROR, ftype, "Spatial Database not found: {}".format(db),
                         "Create it, e.g. with the Import Empty tool of the official TUFLOW QGIS plugin, "
                         "or fix the path.", manual_url("tcf-SpatialDatabase"), "Spatial Database")

        for ftype, cf in self.p.files.items():
            base = os.path.dirname(cf.path) if cf.path else self.p.dir_of(ftype)
            db = spatial_db.get(ftype, tcf_db)
            for e in cf.commands():
                spec = e.spec
                if spec is None or not e.value.strip():
                    continue
                if spec.value_kind not in ("gis", "grid", "file", "file_or_choice") and spec.child_type is None \
                        and spec.database is None:
                    continue
                if spec.value_kind == "file_or_choice" and e.value.strip().upper() in [o.upper() for o in spec.options]:
                    continue
                if spec.key in ("Spatial Database",):
                    continue
                value = substitute_tokens(e.value, self.scenarios, self.events, variables)
                if TOKEN_RE.search(value):
                    self.add(INFO, ftype, "'{}' uses scenario/event/variable tokens ({}) that are not set here; "
                             "existence not checked.".format(e.lhs, ", ".join(sorted(set(TOKEN_RE.findall(value))))),
                             "Set the scenario/event names in the Batch tab to check these paths.", spec.url, e.lhs)
                    continue
                for path, layers in split_value_paths(value):
                    if not path or re.fullmatch(r"-?\d+(\.\d+)?", path):
                        continue
                    if not looks_like_path(path) and db and spec.value_kind == "gis":
                        # layer name inside the spatial database
                        lyr = gpkg_layers(db) if os.path.isfile(db) else None
                        if lyr is not None and path.lower() not in [l.lower() for l in lyr]:
                            self.add(ERROR, ftype, "Layer '{}' ({}) not found in spatial database {}"
                                     .format(path, e.lhs, os.path.basename(db)), "Check the layer name.", spec.url, e.lhs)
                        continue
                    full = resolve_path(path, base)
                    if not any(os.path.exists(v) for v in _file_variants(full)):
                        self.add(ERROR, ftype, "File not found for '{}': {}".format(e.lhs, full),
                                 "Paths are relative to the folder of the control file ({}).".format(base),
                                 spec.url, e.lhs)
                        continue
                    if layers and full.lower().endswith(".gpkg"):
                        lyr = gpkg_layers(full)
                        if lyr is not None:
                            for l in layers:
                                if l.lower() not in [x.lower() for x in lyr]:
                                    self.add(ERROR, ftype, "Layer '{}' not found in {}".format(l, os.path.basename(full)),
                                             "", spec.url, e.lhs)

    # ---------------------------------------------------------------
    def _is_hpc(self):
        tcf = self.p.files["TCF"]
        return (tcf.value("Solution Scheme", "CLASSIC") or "").upper().startswith("HPC")

    def check_solver(self):
        tcf = self.p.files["TCF"]
        hw = (tcf.value("Hardware") or "").upper()
        url = manual_url("tcf-Hardware")
        if hw == "GPU" and not self._is_hpc():
            self.add(ERROR, "TCF", "Hardware == GPU needs Solution Scheme == HPC.", "Set Solution Scheme to HPC.", url)
        if tcf.value("GPU Solver", "").upper() == "ON":
            self.add(WARNING, "TCF", "'GPU Solver == ON' is the legacy pre-2017 GPU engine.",
                     "Use Solution Scheme == HPC with Hardware == GPU instead.", manual_url("tcf-GPUSolver"))
        if "QCF" in self.p.files and not self._is_hpc():
            self.add(ERROR, "TCF", "Quadtree needs the HPC solver.", "Set Solution Scheme == HPC.",
                     manual_url("tcf-QuadtreeControlFile"))
        if (tcf.value("SGS", "") or "").upper() == "ON" and not self._is_hpc():
            self.add(WARNING, "TCF", "SGS is an HPC feature.", "Use HPC or remove SGS.", manual_url("tcf-SGS"))
        cnf = _num(tcf.value("Control Number Factor"))
        if cnf is not None and cnf > 1.0:
            self.add(WARNING, "TCF", "Control Number Factor > 1 'overclocks' HPC and raises the risk of instability.",
                     "Keep at 1.0 or below.", manual_url("tcf-ControlNumberFactor"))
        if cnf == 0:
            self.add(WARNING, "TCF", "Control Number Factor == 0 runs HPC with a fixed timestep (no stability control).",
                     "Only for testing.", manual_url("tcf-ControlNumberFactor"))
        if (tcf.value("Defaults") or "").strip():
            self.add(INFO, "TCF", "Defaults == {} keeps old-release behaviour.".format(tcf.value("Defaults")),
                     "Remove for new models.", manual_url("tcf-Defaults"))

    def check_time(self):
        tcf = self.p.files["TCF"]
        st, et = _num(tcf.value("Start Time"), 0.0), _num(tcf.value("End Time"))
        if et is not None and et <= st:
            self.add(ERROR, "TCF", "End Time ({}) must be greater than Start Time ({}).".format(et, st), "",
                     manual_url("tcf-EndTime"))
        dt = _num(tcf.value("Timestep"))
        cell = self._cell_size()
        if dt is not None and dt <= 0:
            self.add(ERROR, "TCF", "Timestep must be positive.", "", manual_url("tcf-Timestep"))
        if dt and cell and not self._is_hpc():
            ratio = dt / cell
            if ratio > 0.5:
                self.add(WARNING, "TCF", "Classic timestep {:g} s is large for a {:g} m cell (ratio {:.2f}).".format(dt, cell, ratio),
                         "Classic guidance: timestep of about 1/4 to 1/2 of the cell size in metres. "
                         "Reduce the timestep to limit instability.", manual_url("tcf-Timestep"))
            elif ratio < 0.1:
                self.add(INFO, "TCF", "Classic timestep {:g} s is small for a {:g} m cell - runs will be slow.".format(dt, cell),
                         "Increase towards 1/4 of the cell size if the model is stable.", manual_url("tcf-Timestep"))
            else:
                self.add(PASS, "TCF", "Classic timestep/cell size ratio {:.2f} is within the usual 0.1-0.5 range.".format(ratio))
        if dt and self._is_hpc():
            self.add(INFO, "TCF", "HPC uses an adaptive timestep; Timestep == {:g} s is only the starting value.".format(dt),
                     "Watch the control numbers (Nu, Nc, Nd) and repeated timesteps after the run (Results tab).",
                     manual_url("tcf-Timestep"))

    def _cell_size(self):
        tgc = self.p.files.get("TGC")
        v = _num(tgc.value("Cell Size")) if tgc else None
        if v is None and "QCF" in self.p.files:
            v = _num(self.p.files["QCF"].value("Base Cell Size"))
        return v

    def check_geometry(self):
        tgc = self.p.files.get("TGC")
        if tgc is None:
            return
        url = manual_url(None, "TGC")
        cmds = [e.key.lower() for e in tgc.commands()]
        if not any(k.startswith(("read grid zpts", "read gis zpts", "read tin zpts", "set zpt", "create tin zpts",
                                 "read rowcol zpts")) for k in cmds):
            self.add(ERROR, "TGC", "No elevation (Zpt) command found.", "Add Read Grid Zpts with your DEM.", url)
        if not any(k.startswith(("set code", "read gis code", "read grid code")) for k in cmds):
            self.add(WARNING, "TGC", "No Set Code / Read GIS Code - active area is undefined.", "Add Set Code == 0 then Read GIS Code.", url)
        # order checks: Set Code before Read GIS Code, Set Mat before Read GIS Mat
        for set_k, read_k in (("set code", "read gis code"), ("set mat", "read gis mat"), ("set zpt", "read grid zpts")):
            try:
                i_set = cmds.index(set_k)
                i_read = cmds.index(read_k)
                if i_set > i_read:
                    self.add(WARNING, "TGC", "'{}' comes after '{}' and will overwrite it.".format(set_k.title(), read_k.title()),
                             "TGC commands are applied in order: put the Set command first.", url)
            except ValueError:
                pass
        cell = self._cell_size()
        if cell is not None and cell <= 0:
            self.add(ERROR, "TGC", "Cell Size must be positive.", "", manual_url("tgc-CellSize"))
        gs = tgc.value("Grid Size (X,Y)")
        if gs and cell:
            nums = [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", gs)]
            if len(nums) >= 2:
                cells = (nums[0] / cell) * (nums[1] / cell)
                self.add(INFO, "TGC", "Grid bounding box ~{:,.0f} cells ({:g} x {:g} m at {:g} m).".format(cells, nums[0], nums[1], cell),
                         "Free/demo mode is limited to 100,000 cells in the bounding box.")

    def check_materials(self):
        tcf = self.p.files["TCF"]
        tgc = self.p.files.get("TGC")
        uses_mat = tgc and any(e.key.lower() in ("set mat", "read gis mat", "read grid mat") for e in tgc.commands())
        mf = tcf.value("Read Materials File")
        if uses_mat and not mf:
            self.add(ERROR, "TCF", "Materials are set in the TGC but no 'Read Materials File' in the TCF.",
                     "Add Read Materials File.", manual_url("tcf-ReadMaterialsFile"))
        if tgc and uses_mat and not tgc.find("Set Mat"):
            self.add(WARNING, "TGC", "No 'Set Mat' default - cells outside material polygons get material 0.",
                     "Add Set Mat == <default ID> before Read GIS Mat.", manual_url("tgc-SetMat"))
        if not mf:
            return
        path = resolve_path(mf.split("|")[0], os.path.dirname(tcf.path))
        if not path.lower().endswith(".csv") or not os.path.isfile(path):
            return
        ids = []
        try:
            with io.open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
                for row in csv.reader(fh):
                    if not row or not row[0].strip() or row[0].strip().startswith(("!", "#")):
                        continue
                    mid = _num(row[0])
                    if mid is None:
                        continue      # header
                    ids.append(int(mid))
                    n = _num(row[1]) if len(row) > 1 else None
                    if n is not None and not (0.008 <= n <= 1.0) and "," not in (row[1] or ""):
                        self.add(WARNING, "MAT", "Material {}: Manning's n = {:g} is outside the usual range 0.01-0.5."
                                 .format(int(mid), n), "Check the value/units.")
        except (IOError, OSError):
            return
        dup = sorted(set(i for i in ids if ids.count(i) > 1))
        if dup:
            self.add(ERROR, "MAT", "Duplicate material IDs in {}: {}".format(os.path.basename(path), dup), "")
        if ids:
            self.add(PASS, "MAT", "{} material IDs read from {}.".format(len(ids), os.path.basename(path)))
            sm = _num(tgc.value("Set Mat")) if tgc else None
            if sm is not None and int(sm) not in ids:
                self.add(ERROR, "MAT", "Set Mat == {} is not defined in the materials file.".format(int(sm)), "")

    def check_bc_database(self):
        tcf = self.p.files["TCF"]
        bcdb = tcf.value("BC Database")
        if not bcdb:
            return
        path = resolve_path(substitute_tokens(bcdb, self.scenarios, self.events), os.path.dirname(tcf.path))
        if not os.path.isfile(path):
            return
        names = []
        try:
            with io.open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
                rows = [r for r in csv.reader(fh) if r and r[0].strip() and not r[0].strip().startswith(("!", "#"))]
        except (IOError, OSError):
            return
        if not rows:
            self.add(WARNING, "BC_DBASE", "BC database is empty.", "")
            return
        header = [h.strip().lower() for h in rows[0]]
        if not header or header[0] != "name" or len(header) < 2 or header[1] != "source":
            self.add(WARNING, "BC_DBASE", "First two columns of the BC database should be 'Name' and 'Source'.", "",
                     manual_url("tcf-BCDatabase"))
        base = os.path.dirname(path)
        event_sources = self._event_sources()
        for r in rows[1:]:
            names.append(r[0].strip())
            src = r[1].strip() if len(r) > 1 else ""
            if not src or _num(src) is not None and re.fullmatch(r"-?\d+(\.\d+)?", src):
                continue
            variants = self._expand_event_text(src, event_sources)
            for v in variants:
                if TOKEN_RE.search(v) or "~" in v:
                    continue
                full = resolve_path(v, base)
                if not os.path.exists(full):
                    self.add(ERROR, "BC_DBASE", "BC '{}': source file not found: {}".format(r[0].strip(), full), "",
                             manual_url("tcf-BCDatabase"))
        dup = sorted(set(n for n in names if names.count(n) > 1))
        if dup:
            self.add(WARNING, "BC_DBASE", "Duplicate BC names: {}".format(dup), "The last one wins - check intent.")
        tbc = self.p.files.get("TBC")
        grb = tbc.value("Global Rainfall BC") if tbc else None
        if grb and grb.strip() not in names and not TOKEN_RE.search(grb):
            self.add(ERROR, "TBC", "Global Rainfall BC '{}' is not a Name in the BC database.".format(grb), "",
                     manual_url("tbc-GlobalRainfallBC"))

    def _event_sources(self):
        """{event_text: [replacement per event]} from the TEF."""
        tef = self.p.files.get("TEF")
        out = {}
        if not tef:
            return out
        current = None
        for e in tef.commands():
            k = e.key.lower()
            if k == "define event":
                current = e.value.strip()
            elif k == "end define":
                current = None
            elif k == "bc event source" and "|" in e.value:
                text, repl = [s.strip() for s in e.value.split("|", 1)]
                if self.events and current and current not in self.events:
                    continue
                out.setdefault(text, []).append(repl)
        return out

    @staticmethod
    def _expand_event_text(src, event_sources):
        variants = [src]
        for text, repls in event_sources.items():
            if text and text in src:
                variants = [v.replace(text, r) for v in variants for r in repls] or variants
        return variants

    def check_events(self):
        tef = self.p.files.get("TEF")
        tcf = self.p.files["TCF"]
        if tef is None:
            if tcf.find("Model Events") or TOKEN_RE.search(tcf.path or "") and "~e" in (tcf.path or "").lower():
                self.add(WARNING, "TCF", "Events are used but no Event File (.tef) is defined.", "",
                         manual_url("tcf-EventFile"))
            return
        defined = self.p.events_defined()
        if not defined:
            self.add(WARNING, "TEF", "The event file has no 'Define Event' blocks.", "", manual_url(None, "TEF"))
        for ev in self.events:
            if ev and ev not in defined:
                self.add(ERROR, "TEF", "Event '{}' is used in the batch/Model Events but not defined in the TEF.".format(ev), "")
        me = tcf.value("Model Events")
        if me:
            for ev in [s.strip() for s in me.split("|") if s.strip()]:
                if ev not in defined:
                    self.add(ERROR, "TCF", "Model Events '{}' is not defined in the TEF.".format(ev), "")
        # Event File should be last in the TCF
        cmds = tcf.commands()
        if cmds and cmds[-1].key != "Event File" and tcf.find("Event File"):
            self.add(INFO, "TCF", "'Event File' is not the last command in the TCF.",
                     "The manual recommends placing it last so event settings take precedence.",
                     manual_url("tcf-EventFile"))

    def check_rainfall(self):
        tcf = self.p.files["TCF"]
        tbc = self.p.files.get("TBC")
        rain = ("TRFC" in self.p.files) or (tbc and (tbc.find("Global Rainfall BC") or tbc.find("Read GIS RF")))
        if not rain:
            return
        wd = _num(tcf.value("Cell Wet/Dry Depth"), 0.002)
        if wd > 0.0002 + 1e-12:
            self.add(WARNING, "TCF", "Direct rainfall model with Cell Wet/Dry Depth = {:g} m.".format(wd),
                     "The manual recommends 0.0002 m for direct rainfall models.", manual_url("tcf-CellWetDryDepth"))
        else:
            self.add(PASS, "TCF", "Cell Wet/Dry Depth suits direct rainfall.")
        if self._is_hpc() and (tcf.value("SGS") or "").upper() != "ON":
            self.add(INFO, "TCF", "Consider SGS == ON for direct rainfall on steep/fine terrain.", "",
                     manual_url("tcf-SGS"))

    def check_outputs(self):
        tcf = self.p.files["TCF"]
        st, et = _num(tcf.value("Start Time"), 0.0), _num(tcf.value("End Time"), 1.0)
        mi = _num(tcf.value("Map Output Interval"))
        if mi is not None and mi > (et - st) * 3600 > 0:
            self.add(WARNING, "TCF", "Map Output Interval ({:g} s) is longer than the simulation.".format(mi),
                     "Only maximums will be useful.", manual_url("tcf-MapOutputInterval"))
        if mi is not None and 0 < mi < 30:
            self.add(INFO, "TCF", "Map Output Interval {:g} s will create very large result files.".format(mi), "")
        if not tcf.find("Write Check Files"):
            self.add(WARNING, "TCF", "No 'Write Check Files' - you lose TUFLOW's own QA layers.",
                     "Add Write Check Files == ..\\check\\", manual_url("tcf-WriteCheckFiles"))
        if not tcf.find("Read GIS PO"):
            self.add(INFO, "TCF", "No plot output (2d_po) locations.", "Add Read GIS PO to get flow/level time series.",
                     manual_url("tcf-ReadGISPO"))

    def check_one_d(self):
        ecf = self.p.files.get("ECF")
        if ecf is None:
            return
        tcf = self.p.files["TCF"]
        dt1, dt2 = _num(ecf.value("Timestep")), _num(tcf.value("Timestep"))
        if dt1 and dt2 and not self._is_hpc() and dt1 > dt2:
            self.add(WARNING, "ECF", "1D timestep ({:g}) is larger than the 2D timestep ({:g}).".format(dt1, dt2),
                     "The 1D timestep is usually equal to or a fraction of the 2D timestep.", manual_url("ecf-Timestep"))
        if not ecf.find("Read GIS Network"):
            self.add(ERROR, "ECF", "ESTRY Control File has no 'Read GIS Network'.", "", manual_url("ecf-ReadGISNetwork"))
