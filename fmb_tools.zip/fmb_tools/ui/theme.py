# -*- coding: utf-8 -*-
"""
Modern look for the FMB tools window.

The style sheet is generated from the current QGIS palette, so it follows the light or dark
QGIS theme automatically, with one accent colour. It is scoped to the plugin window
(#FmbMain) and never touches the rest of QGIS.
"""
import hashlib
import os
import tempfile

from qgis.PyQt.QtGui import QColor, QPalette

ACCENT = "#1f6fd1"
STATE_COLORS = {"done": "#1e8c46", "warn": "#d68400", "error": "#c62828", "todo": "#8a94a6", "optional": "#b0b7c3"}


def mix(a, b, t):
    a, b = QColor(a), QColor(b)
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t))


def colors(palette=None, accent=ACCENT):
    if palette is None:
        from qgis.PyQt.QtWidgets import QApplication
        palette = QApplication.palette()
    win = palette.color(QPalette.ColorRole.Window)
    base = palette.color(QPalette.ColorRole.Base)
    text = palette.color(QPalette.ColorRole.Text)
    dark = win.lightness() < 128
    acc = QColor(accent) if not dark else mix(accent, "#ffffff", 0.25)
    c = {
        "dark": dark,
        "bg": mix(win, acc, 0.03),
        "side": mix(win, "#000000", 0.18) if dark else mix(win, acc, 0.06),
        "card": mix(win, "#ffffff", 0.06) if dark else QColor(base),
        "base": QColor(base),
        "border": mix(win, text, 0.22 if dark else 0.16),
        "text": QColor(text),
        "muted": mix(text, win, 0.45),
        "accent": acc,
        "accent_hover": mix(acc, "#000000", 0.12) if not dark else mix(acc, "#ffffff", 0.12),
        "accent_soft": mix(base if not dark else win, acc, 0.16 if not dark else 0.35),
        "accent_text": mix(acc, "#000000", 0.25) if not dark else mix(acc, "#ffffff", 0.35),
        "hover": mix(win, acc, 0.09 if not dark else 0.18),
        "header_section": mix(win, text, 0.06),
    }
    return c


def _arrow_files(color):
    """Small SVG arrows (combo box / spin box) in the theme colour, written once to the temp folder."""
    col = QColor(color).name()
    folder = os.path.join(tempfile.gettempdir(), "fmb_tools_theme", hashlib.md5(col.encode()).hexdigest()[:8])
    os.makedirs(folder, exist_ok=True)
    shapes = {"down": "M2 4 L6 8 L10 4", "up": "M2 8 L6 4 L10 8"}
    out = {}
    for name, d in shapes.items():
        p = os.path.join(folder, name + ".svg")
        if not os.path.isfile(p):
            with open(p, "w") as f:
                f.write("<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'>"
                        "<path d='{}' fill='none' stroke='{}' stroke-width='1.8' stroke-linecap='round' "
                        "stroke-linejoin='round'/></svg>".format(d, col))
        out[name] = p.replace("\\", "/")
    return out


def stylesheet(palette=None, accent=ACCENT):
    c = colors(palette, accent)
    h = {k: (v.name() if isinstance(v, QColor) else v) for k, v in c.items()}
    arrows = _arrow_files(c["muted"])
    h["down"], h["up"] = arrows["down"], arrows["up"]
    return """
#FmbMain {{ background: {bg}; }}
#FmbMain QWidget#FmbPage {{ background: {bg}; }}
#FmbMain QScrollArea {{ border: none; background: transparent; }}
#FmbMain QScrollArea > QWidget > QWidget {{ background: transparent; }}

/* sidebar */
#FmbSidebar {{ background: {side}; border-right: 1px solid {border}; }}
#FmbSidebar QLabel#Brand {{ font-size: 13pt; font-weight: 700; color: {text}; }}
#FmbSidebar QLabel#BrandSub {{ color: {muted}; font-size: 8pt; }}
#FmbSidebar QListWidget {{ background: transparent; border: none; outline: 0; }}
#FmbSidebar QToolButton {{ border: none; border-radius: 6px; padding: 4px; color: {muted}; }}
#FmbSidebar QToolButton:hover {{ background: {hover}; }}

/* header */
#FmbHeader {{ background: {card}; border-bottom: 1px solid {border}; }}
#FmbHeader QLabel#ModelName {{ font-size: 14pt; font-weight: 700; color: {text}; }}
#FmbHeader QLabel#ModelPath {{ color: {muted}; }}
#FmbMain QLabel[chip="true"] {{ border-radius: 9px; padding: 1px 9px; background: {accent_soft}; color: {accent_text};
    font-weight: 600; }}
#FmbMain QLabel[chip="warn"] {{ border-radius: 9px; padding: 1px 9px; background: #fff1d6; color: #8a5300;
    font-weight: 600; }}
#FmbMain QPushButton#SearchButton {{ text-align: left; color: {muted}; background: {base}; border: 1px solid {border};
    border-radius: 15px; padding: 5px 14px; min-width: 240px; }}
#FmbMain QPushButton#SearchButton:hover {{ border-color: {accent}; }}

/* status bar */
#FmbStatus {{ background: {card}; border-top: 1px solid {border}; }}
#FmbStatus QLabel {{ color: {muted}; }}

/* buttons */
#FmbMain QPushButton {{ padding: 4px 9px; border: 1px solid {border}; border-radius: 6px; background: {card};
    color: {text}; }}
#FmbMain QPushButton:hover {{ border-color: {accent}; background: {hover}; }}
#FmbMain QPushButton:pressed {{ background: {accent_soft}; }}
#FmbMain QPushButton:disabled {{ color: {muted}; border-color: {border}; background: {bg}; }}
#FmbMain QPushButton[compact="true"] {{ padding: 3px 6px; }}
#FmbMain QPushButton[primary="true"] {{ background: {accent}; color: #ffffff; border: 1px solid {accent};
    font-weight: 600; }}
#FmbMain QPushButton[primary="true"]:hover {{ background: {accent_hover}; border-color: {accent_hover}; }}
#FmbMain QPushButton[flat="true"] {{ border: none; background: transparent; color: {accent}; padding: 2px 6px;
    font-weight: 600; }}
#FmbMain QPushButton[flat="true"]:hover {{ text-decoration: underline; }}
#FmbMain QToolButton {{ border: 1px solid {border}; border-radius: 6px; padding: 3px 6px; background: {card};
    color: {text}; }}
#FmbMain QToolButton:hover {{ border-color: {accent}; background: {hover}; }}

/* group boxes = cards */
#FmbMain QGroupBox {{ border: 1px solid {border}; border-radius: 8px; margin-top: 18px; padding: 12px 8px 8px 8px;
    background: {card}; }}
#FmbMain QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top left; left: 10px;
    padding: 0 4px; color: {accent_text}; font-weight: 700; }}
#FmbMain QFrame#Card {{ background: {card}; border: 1px solid {border}; border-radius: 10px; }}
#FmbMain QFrame#Card QLabel#CardTitle {{ font-size: 11pt; font-weight: 700; color: {text}; }}
#FmbMain QFrame#Hero {{ border-radius: 12px; border: 1px solid {accent}; background: {accent_soft}; }}
#FmbMain QLabel#Muted {{ color: {muted}; }}
#FmbMain QLabel#PageTitle {{ font-size: 13pt; font-weight: 700; color: {text}; padding-right: 10px; }}

/* inputs */
#FmbMain QLineEdit, #FmbMain QPlainTextEdit, #FmbMain QTextEdit, #FmbMain QTextBrowser {{
    border: 1px solid {border}; border-radius: 5px; padding: 3px 5px; background: {base}; color: {text};
    selection-background-color: {accent}; selection-color: #ffffff; }}
#FmbMain QLineEdit:focus, #FmbMain QPlainTextEdit:focus, #FmbMain QTextEdit:focus {{ border-color: {accent}; }}
#FmbMain QComboBox, #FmbMain QAbstractSpinBox {{ border: 1px solid {border}; border-radius: 5px;
    padding: 2px 6px; background: {base}; color: {text}; min-height: 20px;
    selection-background-color: {accent}; selection-color: #ffffff; }}
#FmbMain QComboBox:focus, #FmbMain QAbstractSpinBox:focus {{ border-color: {accent}; }}
#FmbMain QComboBox:disabled, #FmbMain QAbstractSpinBox:disabled, #FmbMain QLineEdit:disabled {{ color: {muted};
    background: {bg}; }}
#FmbMain QComboBox::drop-down {{ border: none; width: 20px; }}
#FmbMain QComboBox::down-arrow {{ image: url({down}); width: 10px; height: 10px; }}
#FmbMain QComboBox QAbstractItemView {{ border: 1px solid {border}; background: {base};
    selection-background-color: {accent_soft}; selection-color: {text}; outline: 0; }}
#FmbMain QAbstractSpinBox::up-button, #FmbMain QAbstractSpinBox::down-button {{ border: none; width: 16px;
    subcontrol-origin: border; }}
#FmbMain QAbstractSpinBox::up-button {{ subcontrol-position: top right; }}
#FmbMain QAbstractSpinBox::down-button {{ subcontrol-position: bottom right; }}
#FmbMain QAbstractSpinBox::up-arrow {{ image: url({up}); width: 9px; height: 9px; }}
#FmbMain QAbstractSpinBox::down-arrow {{ image: url({down}); width: 9px; height: 9px; }}
#FmbMain QComboBox QLineEdit, #FmbMain QAbstractSpinBox QLineEdit {{ border: none; padding: 0; background: transparent; }}

/* lists, trees, tables */
#FmbMain QTreeWidget, #FmbMain QTableWidget, #FmbMain QListWidget, #FmbMain QTreeView, #FmbMain QTableView {{
    border: 1px solid {border}; border-radius: 6px; background: {base}; color: {text};
    selection-background-color: {accent_soft}; selection-color: {text}; outline: 0; }}
#FmbMain QHeaderView::section {{ background: {header_section}; color: {text}; border: none;
    border-bottom: 1px solid {border}; border-right: 1px solid {border}; padding: 4px 6px; font-weight: 600; }}
#FmbMain QTableCornerButton::section {{ background: {header_section}; border: none; }}

/* inner tab widgets */
#FmbMain QTabWidget::pane {{ border: 1px solid {border}; border-radius: 6px; top: -1px; background: {card}; }}
#FmbMain QTabBar::tab {{ padding: 6px 14px; border: 1px solid transparent; border-bottom: none; margin-right: 2px;
    color: {muted}; background: transparent; }}
#FmbMain QTabBar::tab:selected {{ color: {text}; background: {card}; border-color: {border};
    border-top-left-radius: 6px; border-top-right-radius: 6px; font-weight: 600; }}
#FmbMain QTabBar::tab:hover:!selected {{ color: {accent}; }}

/* scroll bars */
#FmbMain QScrollBar:vertical {{ width: 11px; background: transparent; margin: 2px; }}
#FmbMain QScrollBar:horizontal {{ height: 11px; background: transparent; margin: 2px; }}
#FmbMain QScrollBar::handle {{ background: {border}; border-radius: 4px; min-height: 28px; min-width: 28px; }}
#FmbMain QScrollBar::handle:hover {{ background: {muted}; }}
#FmbMain QScrollBar::add-line, #FmbMain QScrollBar::sub-line {{ width: 0; height: 0; }}
#FmbMain QScrollBar::add-page, #FmbMain QScrollBar::sub-page {{ background: transparent; }}
#FmbMain QSplitter::handle {{ background: transparent; }}
#FmbMain QProgressBar {{ border: none; border-radius: 4px; background: {header_section}; height: 8px;
    text-align: center; color: transparent; }}
#FmbMain QProgressBar::chunk {{ border-radius: 4px; background: {accent}; }}
""".format(**h)
