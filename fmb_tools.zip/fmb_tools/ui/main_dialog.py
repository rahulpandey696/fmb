# -*- coding: utf-8 -*-
"""Main window of the FMB tools plugin."""
import os

from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel, QPushButton, QMessageBox,
                                 QFormLayout, QDialogButtonBox, QWidget)

from ..core.catalog import FILE_TYPE_INFO
from ..core.control_file import Entry, to_tuflow_path
from ..core.catalog import catalog
from ..core.project import TuflowProject
from . import qgis_utils as qu
from .control_file_editor import ControlFileEditor
from .tabs import ProjectTab, DatabaseTab, BatchTab, QcTab, LogsTab, ResultsTab, HelpTab, EventWizard
from .widgets import PathEdit, qexec
from .empty_tab import EmptyLayersTab

MAIN_TABS = ["TCF", "TGC", "TBC", "ECF", "TEF"]
OTHER_TABS = ["QCF", "TRFC", "TOC", "TESF", "TSCF", "ADCF"]
TAB_TITLES = {"TCF": "TCF", "TGC": "TGC", "TBC": "TBC", "ECF": "ECF (1D)",
              "TEF": "TEF", "QCF": "QCF (quadtree)", "TRFC": "TRFC (rainfall)", "TOC": "TOC (operations)",
              "TESF": "TESF (wind)", "TSCF": "TSCF (SWMM)", "ADCF": "ADCF (AD)"}


class MainDialog(QDialog):
    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        qu.set_iface(iface)
        self.setWindowTitle("FMB tools")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowMinimizeButtonHint)
        icon = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        self.setWindowIcon(QIcon(icon))
        self.resize(1400, 860)
        self.project = None
        self.dir_override = {}
        self.editors = {}
        self._build()

    # ------------------------------------------------------------------ UI
    def _build(self):
        lay = QVBoxLayout(self)
        head = QHBoxLayout()
        self.title = QLabel("<b>No model loaded</b>")
        head.addWidget(self.title, 1)
        for text, slot in (("Save all", self.save_all), ("Run QC", self.run_qc), ("Help", lambda: self.show_tab("Help"))):
            b = QPushButton(text)
            b.clicked.connect(slot)
            head.addWidget(b)
        lay.addLayout(head)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        self.project_tab = ProjectTab()
        self.project_tab.newModelRequested.connect(self.new_model)
        self.project_tab.openModelRequested.connect(self.open_model)
        self.project_tab.saveAllRequested.connect(self.save_all)
        self.project_tab.showTab.connect(self.show_tab)
        self.tabs.addTab(self.project_tab, "Project")
        self.empty_tab = EmptyLayersTab(self)
        self.empty_tab.commandsReady.connect(self.add_read_commands)
        i = self.tabs.addTab(self.empty_tab, "Empty layers")
        self.tabs.setTabToolTip(i, "Create TUFLOW empty GIS layers (GeoPackage / Shapefile) ready to draw in")

        for ft in MAIN_TABS:
            ed = self._make_editor(ft)
            if ft == "TEF":
                host = QWidget()
                hl = QVBoxLayout(host)
                hl.setContentsMargins(0, 0, 0, 0)
                self.event_wizard = EventWizard()
                self.event_wizard.generate.connect(self._add_events)
                hl.addWidget(self.event_wizard)
                hl.addWidget(ed, 1)
                self.tef_host = host
                i = self.tabs.addTab(host, TAB_TITLES[ft])
            else:
                i = self.tabs.addTab(ed, TAB_TITLES[ft])
            self.tabs.setTabToolTip(i, "{} - {}".format(FILE_TYPE_INFO[ft][0], FILE_TYPE_INFO[ft][1]))
        self.other_tabs = QTabWidget()
        for ft in OTHER_TABS:
            self.other_tabs.addTab(self._make_editor(ft), TAB_TITLES[ft])
        self.tabs.addTab(self.other_tabs, "Other files")

        self.db_tab = DatabaseTab()
        self.tabs.addTab(self.db_tab, "Databases")
        self.batch_tab = BatchTab()
        self.batch_tab.names_fn = lambda kind: self.project.names(kind) if self.project is not None else []
        self.batch_tab.runsFinished.connect(self._after_runs)
        self.tabs.addTab(self.batch_tab, "Batch && Run")
        self.qc_tab = QcTab(self)
        self.tabs.addTab(self.qc_tab, "QC")
        self.logs_tab = LogsTab(self)
        self.tabs.addTab(self.logs_tab, "Logs")
        self.results_tab = ResultsTab(self)
        self.tabs.addTab(self.results_tab, "Results")
        self.help_tab = HelpTab()
        self.tabs.addTab(self.help_tab, "Help")
        self.tabs.currentChanged.connect(self._tab_changed)
        self.status = QLabel("")
        lay.addWidget(self.status)

        last = QSettings().value("fmb_tools/last_tcf", "")
        exe = QSettings().value("fmb_tools/exe", "")
        if exe:
            self.batch_tab.exe.setValue(exe)
        if last and os.path.isfile(last):
            self.status.setText("Last model: {}".format(last))
            self.project_tab.set_last(last)

    def _make_editor(self, ft):
        ed = ControlFileEditor(ft)
        ed.createRequested.connect(self.create_control_file)
        ed.openChildRequested.connect(self.open_child)
        ed.openDatabaseRequested.connect(self.open_database)
        ed.fileReplaced.connect(self._file_replaced)
        ed.changed.connect(self._update_title)
        ed.names_fn = self.model_names
        self.editors[ft] = ed
        return ed

    # --------------------------------------------------------- context API
    def current_project(self):
        return self.project

    def model_names(self, kind):
        """Names offered in the value dropdowns (scenarios, events, BC names, material IDs)."""
        names = list(self.project.names(kind)) if self.project is not None else []
        if kind in ("scenarios", "events") and hasattr(self, "batch_tab"):
            cfg = self.batch_tab.config()
            for slot in (cfg.scenarios if kind == "scenarios" else cfg.events):
                for v in slot:
                    if v not in names:
                        names.append(v)
        return names

    def dirs(self):
        """(results, check, log) folders."""
        if self.project is None:
            return "", "", ""
        res, chk, log = self.project.output_dirs()
        return (self.dir_override.get("results", res), self.dir_override.get("check", chk),
                self.dir_override.get("log", log))

    def edit_dirs(self):
        d = QDialog(self)
        d.setWindowTitle("Output folders")
        f = QFormLayout(d)
        res, chk, log = self.dirs()
        edits = {}
        for key, val in (("results", res), ("check", chk), ("log", log)):
            pe = PathEdit("folder", "", lambda: "")
            pe.setValue(val)
            edits[key] = pe
            f.addRow(key.title(), pe)
        f.addRow(QLabel("<i>Folders are read from the TCF; override them here if you use ~s~/~e~ sub-folders.</i>"))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        f.addRow(bb)
        if qexec(d):
            for k, pe in edits.items():
                self.dir_override[k] = pe.value().rstrip("\\/")
            self.logs_tab.refresh()
            self.results_tab.refresh()
            self.qc_tab.refresh_sims()

    def batch_first(self):
        return self.batch_tab.first_scenarios_events()

    def run_test(self):
        self._sync_batch()
        self.save_all(quiet=True)
        self.tabs.setCurrentWidget(self.batch_tab)
        self.batch_tab.run_test()

    # ------------------------------------------------------------- project
    def set_project(self, project):
        self.project = project
        self.dir_override = {}
        for ft, ed in self.editors.items():
            ed.set_control_file(project.files.get(ft) if project else None)
        if project:
            tcf = project.files.get("TCF")
            self.batch_tab.set_config(project.state.get("batch", {}))
            if tcf:
                self.batch_tab.set_tcf(tcf.path)
                QSettings().setValue("fmb_tools/last_tcf", tcf.path)
            self.empty_tab.set_project(project)
        self._refresh_databases()
        self._update_title()

    def new_model(self, opts):
        root = self.project_tab.root.value().strip()
        prj = TuflowProject(root, opts["name"])
        tcf_path = prj.default_path("TCF")
        if os.path.exists(tcf_path) and QMessageBox.question(
                self, "New model", "{} already exists. Overwrite the control files?".format(tcf_path)) \
                != QMessageBox.StandardButton.Yes:
            return
        try:
            prj.create_folders()
            prj.new_from_template(opts)
            prj.write_databases(overwrite=False, direct_rainfall=opts.get("direct_rainfall"))
            if opts.get("events"):
                prj.state["batch"] = {"events": [opts["events"]] + [[]] * 8}
            prj.save_all()
        except Exception as ex:
            QMessageBox.critical(self, "New model", "Could not create the model:\n{}".format(ex))
            return
        self.set_project(prj)
        self.tabs.setCurrentWidget(self.editors["TCF"])
        qu.message("Model created in {}".format(root), "success")

    def open_model(self, path):
        try:
            prj = TuflowProject.from_tcf(path)
        except Exception as ex:
            QMessageBox.critical(self, "Open", "Could not read {}:\n{}".format(path, ex))
            return
        self.set_project(prj)
        missing = [ft for ft, cf in prj.files.items() if cf.path and not os.path.isfile(cf.path)]
        if missing:
            QMessageBox.warning(self, "Open", "These referenced control files were not found (tabs are empty "
                                              "until saved):\n" + "\n".join(prj.files[m].path for m in missing))
        self.tabs.setCurrentWidget(self.editors["TCF"])

    def create_control_file(self, ftype):
        if self.project is None:
            QMessageBox.information(self, "Create", "Create or open a model in the Project tab first.")
            self.tabs.setCurrentWidget(self.project_tab)
            return
        if ftype == "TCF":
            return
        self.project.ensure(ftype)
        self.project.link_child(ftype)
        parent = "ECF" if ftype == "TOC" else "TCF"
        self.editors[parent].set_control_file(self.project.files[parent])
        self.editors[parent].dirty = True
        self.editors[ftype].set_control_file(self.project.files[ftype])
        self.editors[ftype].dirty = True
        self._update_title()

    def open_child(self, ftype):
        if self.project is None:
            return
        if ftype not in self.project.files:
            self.create_control_file(ftype)
        self.show_tab(ftype)

    def show_tab(self, name):
        if name in self.editors:
            ed = self.editors[name]
            if name in OTHER_TABS:
                self.tabs.setCurrentWidget(self.other_tabs)
                self.other_tabs.setCurrentWidget(ed)
            elif name == "TEF":
                self.tabs.setCurrentWidget(self.tef_host)
            else:
                self.tabs.setCurrentWidget(ed)
            return
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i).replace("&&", "&").startswith(name):
                self.tabs.setCurrentIndex(i)
                return

    def open_database(self, path):
        self.tabs.setCurrentWidget(self.db_tab)
        self.db_tab.load(path)

    def _file_replaced(self, ftype):
        ed = self.editors[ftype]
        if self.project is None:
            self.project = TuflowProject(os.path.dirname(os.path.dirname(ed.cf.path)),
                                         os.path.splitext(os.path.basename(ed.cf.path))[0])
        self.project.files[ftype] = ed.cf
        if ftype == "TCF":
            self.project.discover_children()
            self.set_project(self.project)
        else:
            parent_t = "ECF" if ftype == "TOC" else "TCF"
            parent = self.project.files.get(parent_t)
            cmd = FILE_TYPE_INFO[ftype][2]
            if parent is not None and cmd:
                parent.set_value(cmd, to_tuflow_path(ed.cf.path, os.path.dirname(parent.path)))
                self.editors[parent_t].set_control_file(parent)
                self.editors[parent_t].dirty = True
        self._update_title()

    def _add_events(self, events):
        if self.project is None or "TEF" not in self.project.files:
            self.create_control_file("TEF")
            if self.project is None:
                return
        tef = self.project.files["TEF"]
        existing = set(self.project.events_defined())
        cat = catalog()
        for name, sources in events:
            if name in existing:
                continue
            tef.entries.append(Entry("blank"))
            s, ch = cat.match("TEF", "Define Event")
            tef.entries.append(Entry("command", lhs="Define Event", value=name, spec=s, choices=ch))
            for text, val in sources:
                s, ch = cat.match("TEF", "BC Event Source")
                tef.entries.append(Entry("command", lhs="BC Event Source", value="{} | {}".format(text, val),
                                         spec=s, choices=ch))
            s, ch = cat.match("TEF", "End Define")
            tef.entries.append(Entry("command", lhs="End Define", value="", spec=s, choices=ch))
        self.editors["TEF"].set_control_file(tef)
        self.editors["TEF"].dirty = True
        self.batch_tab.refresh_names()
        self._update_title()

    def add_read_commands(self, cmds):
        """Add Read GIS commands (from the Empty layers tab) to the control files.
        An existing command of the same kind with no value is filled in; exact duplicates are skipped."""
        if self.project is None or not cmds:
            return
        added = []
        for ftype, lhs, value in cmds:
            if ftype not in self.project.files:
                self.create_control_file(ftype)
            cf = self.project.files.get(ftype)
            if cf is None:
                continue
            spec, ch = catalog().match(ftype, lhs)
            same = [e for e in cf.commands() if " ".join(e.lhs.lower().split()) == lhs.lower()]
            if any(e.value.strip().lower() == value.lower() for e in same):
                continue
            blank = [e for e in same if not e.value.strip()]
            if blank:
                blank[0].value = value
            else:
                entry = Entry("command", lhs=lhs, value=value, spec=spec, choices=ch or [])
                pos = len(cf.entries)
                if lhs in ("Read GIS Location",):
                    # grid location must come before the grid size / cell size commands
                    first = [i for i, e in enumerate(cf.entries) if e.kind == "command"]
                    pos = first[0] if first else pos
                if ftype == "TCF":
                    ev = [i for i, e in enumerate(cf.entries) if e.kind == "command" and e.key == "Event File"]
                    if ev:
                        pos = ev[-1]
                        while pos > 0 and cf.entries[pos - 1].kind in ("comment", "blank"):
                            pos -= 1
                cf.entries.insert(pos, entry)
            added.append("{}: {}".format(ftype, lhs))
            ed = self.editors.get(ftype)
            if ed is not None:
                ed.set_control_file(cf)
                ed.dirty = True
        self._update_title()
        if added:
            self.status.setText("Added {} Read GIS command(s) - Save all to write them: {}".format(
                len(added), "; ".join(added)))

    def _sync_batch(self):
        if self.project is not None:
            cfg = self.batch_tab.config()
            self.project.state["batch"] = cfg.to_dict()
            self.project.state["scenarios"] = [v[0] for v in cfg.scenarios if v]
            self.project.state["events"] = [v[0] for v in cfg.events if v]
            QSettings().setValue("fmb_tools/exe", cfg.exe)

    def save_all(self, quiet=False):
        if self.project is None:
            if not quiet:
                QMessageBox.information(self, "Save", "No model loaded.")
            return
        self._sync_batch()
        try:
            saved = self.project.save_all()
        except Exception as ex:
            QMessageBox.critical(self, "Save", "Could not save:\n{}".format(ex))
            return
        for ed in self.editors.values():
            if ed.cf is not None:
                ed.dirty = False
                ed.path_label.setText(ed.cf.path)
        self._update_title()
        self._refresh_databases()
        if not quiet:
            qu.message("Saved {} control files".format(len(saved)), "success", 3)
            self.status.setText("Saved: " + ", ".join(os.path.basename(s) for s in saved))

    def run_qc(self):
        self._sync_batch()
        self.tabs.setCurrentWidget(self.qc_tab)
        self.qc_tab.run_checks()

    def _refresh_databases(self):
        items = []
        if self.project is not None:
            from ..core.control_file import resolve_path
            for ft, cf in self.project.files.items():
                for e in cf.commands():
                    if e.spec is not None and e.spec.database and e.value.strip():
                        p = resolve_path(e.value.split("|")[0].split(">>")[0], os.path.dirname(cf.path))
                        items.append(("{} ({})".format(e.spec.key, ft), p))
        self.db_tab.set_known(items)

    def _update_title(self):
        if self.project is None:
            self.title.setText("<b>No model loaded</b> - start in the Project tab")
            return
        dirty = [ft for ft, ed in self.editors.items() if ed.dirty and ed.cf is not None]
        self.title.setText("<b>{}</b>  -  {}{}".format(
            self.project.name, self.project.root,
            "   <span style='color:#d68400'>unsaved: {}</span>".format(", ".join(dirty)) if dirty else ""))
        self.project_tab.show_project(self.project, self.editors)

    def _tab_changed(self, _i):
        w = self.tabs.currentWidget()
        if w is self.db_tab:
            self._refresh_databases()
        elif w is self.logs_tab:
            self.logs_tab.refresh()
        elif w is self.results_tab:
            self.results_tab.refresh()
        elif w is self.qc_tab:
            self.qc_tab.refresh_sims()
        elif w is self.batch_tab and self.project and self.project.files.get("TCF"):
            self.batch_tab.set_tcf(self.project.files["TCF"].path)
            self.batch_tab.refresh_names()
        elif w is self.project_tab:
            self.project_tab.refresh_layers()
            self._update_title()

    def _after_runs(self):
        self.logs_tab.refresh()
        self.results_tab.refresh()
        self.qc_tab.refresh_sims()

    def closeEvent(self, ev):
        dirty = [ft for ft, ed in self.editors.items() if ed.dirty and ed.cf is not None]
        if dirty:
            r = QMessageBox.question(self, "FMB tools",
                                     "Save changes to {} before closing?".format(", ".join(dirty)),
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No |
                                     QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel:
                ev.ignore()
                return
            if r == QMessageBox.StandardButton.Yes:
                self.save_all(quiet=True)
        if self.batch_tab.runner.running:
            if QMessageBox.question(self, "FMB tools", "Simulations are running. Stop them?") \
                    == QMessageBox.StandardButton.Yes:
                self.batch_tab.runner.stop()
        ev.accept()
