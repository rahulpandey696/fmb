# -*- coding: utf-8 -*-
"""Thin wrappers around QGIS so the rest of the UI stays testable."""
import os

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices

try:
    from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer, QgsRectangle
    HAS_QGIS = True
except Exception:          # pragma: no cover - running outside QGIS
    HAS_QGIS = False

_IFACE = None


def set_iface(iface):
    global _IFACE
    _IFACE = iface


def iface():
    return _IFACE


def open_url(url):
    if url:
        QDesktopServices.openUrl(QUrl(url))


def open_path(path):
    if path and os.path.exists(path):
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


def project_layers(kind=None):
    """[(name, source, 'vector'|'raster', layer)] from the current QGIS project."""
    if not HAS_QGIS:
        return []
    out = []
    try:
        for lyr in QgsProject.instance().mapLayers().values():
            t = "vector" if isinstance(lyr, QgsVectorLayer) else (
                "raster" if isinstance(lyr, QgsRasterLayer) else "other")
            if kind and t != kind:
                continue
            out.append((lyr.name(), lyr.source(), t, lyr))
    except Exception:
        return []
    return sorted(out, key=lambda x: x[0].lower())


def layer_path_and_name(source):
    """Split a QGIS data source into (file path, layer name or '')."""
    src = source.split("|")
    path = src[0]
    name = ""
    for part in src[1:]:
        if part.lower().startswith("layername="):
            name = part.split("=", 1)[1]
    return path, name


def add_layer(path, name=None):
    """Add a vector/raster file (all layers of a GeoPackage) to the map."""
    if not HAS_QGIS or not path or not os.path.exists(path):
        return []
    name = name or os.path.splitext(os.path.basename(path))[0]
    added = []
    ext = os.path.splitext(path)[1].lower()
    prj = QgsProject.instance()
    if ext in (".tif", ".tiff", ".asc", ".flt", ".nc", ".vrt"):
        lyr = QgsRasterLayer(path, name)
        if lyr.isValid():
            prj.addMapLayer(lyr)
            added.append(lyr)
        return added
    if ext == ".gpkg":
        from ..core.qc import gpkg_layers
        names = gpkg_layers(path) or []
        for n in names:
            lyr = QgsVectorLayer("{}|layername={}".format(path, n), n, "ogr")
            if lyr.isValid():
                prj.addMapLayer(lyr)
                added.append(lyr)
            else:
                rl = QgsRasterLayer("GPKG:{}:{}".format(path, n), n)
                if rl.isValid():
                    prj.addMapLayer(rl)
                    added.append(rl)
        return added
    lyr = QgsVectorLayer(path, name, "ogr")
    if lyr.isValid():
        prj.addMapLayer(lyr)
        added.append(lyr)
    else:
        rl = QgsRasterLayer(path, name)
        if rl.isValid():
            prj.addMapLayer(rl)
            added.append(rl)
    return added


def layer_extent(layer):
    try:
        e = layer.extent()
        return e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum()
    except Exception:
        return None


def zoom_to(x, y, scale_m=200.0):
    if not HAS_QGIS or _IFACE is None:
        return
    try:
        x, y = float(x), float(y)
        canvas = _IFACE.mapCanvas()
        canvas.setExtent(QgsRectangle(x - scale_m, y - scale_m, x + scale_m, y + scale_m))
        canvas.refresh()
    except Exception:
        pass


def message(text, level="info", duration=5):
    if _IFACE is None:
        return
    try:
        from qgis.core import Qgis
        ml = getattr(Qgis, "MessageLevel", Qgis)
        names = {"info": "Info", "warning": "Warning", "error": "Critical", "success": "Success"}
        lv = getattr(ml, names[level])
        _IFACE.messageBar().pushMessage("FMB tools", text, level=lv, duration=duration)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# empty layers
def load_empty_layer(job, group_name="", defaults=None, closed=None, save_style=True, start_editing=False):
    """Load a newly written empty layer, set default values and dropdown widgets,
    store them as the layer's default style and put it in a layer-tree group.
    `defaults`: {field index: expression}; `closed`: {field index: [(value, meaning)]}."""
    if not HAS_QGIS:
        return None
    try:
        from qgis.core import QgsDefaultValue, QgsEditorWidgetSetup
    except Exception:
        QgsDefaultValue = QgsEditorWidgetSetup = None
    lyr = QgsVectorLayer(job.uri, job.name, "ogr")
    if not lyr.isValid():
        return None
    try:
        if QgsDefaultValue is not None:
            for idx, expr in (defaults or {}).items():
                if expr:
                    lyr.setDefaultValueDefinition(idx, QgsDefaultValue(expr))
        if QgsEditorWidgetSetup is not None:
            for idx, choices in (closed or {}).items():
                vmap = [{"{}  -  {}".format(v, m) if v else "(blank)": v} for v, m in choices]
                lyr.setEditorWidgetSetup(idx, QgsEditorWidgetSetup("ValueMap", {"map": vmap}))
        if save_style:
            if job.path.lower().endswith(".gpkg"):
                try:
                    lyr.saveStyleToDatabase(job.name, "FMB tools defaults", True, "")
                except TypeError:
                    pass
            else:
                lyr.saveNamedStyle(os.path.splitext(job.path)[0] + ".qml")
    except Exception:
        pass
    prj = QgsProject.instance()
    prj.addMapLayer(lyr, False)
    root = prj.layerTreeRoot()
    parent = root
    for part in [p for p in (group_name or "").split("/") if p]:
        g = parent.findGroup(part)
        parent = g if g is not None else parent.insertGroup(0, part)
    parent.addLayer(lyr)
    if start_editing and _IFACE is not None:
        try:
            _IFACE.setActiveLayer(lyr)
            lyr.startEditing()
        except Exception:
            pass
    return lyr


def project_crs():
    """(authid, wkt) of the QGIS project CRS or ('', '')."""
    if not HAS_QGIS:
        return "", ""
    try:
        crs = QgsProject.instance().crs()
        return crs.authid(), crs.toWkt()
    except Exception:
        return "", ""
