# -*- coding: utf-8 -*-
"""FMB tools - QGIS plugin entry point."""


def classFactory(iface):  # noqa: N802 (QGIS API name)
    from .plugin import FmbToolsPlugin
    return FmbToolsPlugin(iface)
