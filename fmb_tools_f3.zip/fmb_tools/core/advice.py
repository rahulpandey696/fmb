# -*- coding: utf-8 -*-
"""
Suggested values for improving a TUFLOW model - timestep, cell size, 1D timestep, output intervals,
run length, wet/dry depth, HPC control - from the control files and, when a simulation has run,
from its log, mass balance, HPC timestep file and plot-output time series.

    rows = suggest(project, tlf=None, hpc=None, mb=None, dt=None, po=None)

Every core setting always gets a row with a value: either a change ('change'), the current value
confirmed ('keep') or something to look into ('check'). Rows with ftype / command / value can be
applied to the control file directly.
"""
import math
import os
import re

CHANGE, KEEP, CHECK, INFO = "change", "keep", "check", "info"
G = 9.81


class Advice(object):
    __slots__ = ("level", "setting", "current", "suggested", "why", "ftype", "command", "value", "url")

    def __init__(self, level, setting, current, suggested, why, ftype="", command="", value=None, url=""):
        self.level = level            # change | keep | check | info
        self.setting = setting        # what it is about, e.g. '2D timestep'
        self.current = current        # text
        self.suggested = suggested    # text
        self.why = why
        self.ftype = ftype            # control file + command + value -> can be applied
        self.command = command
        self.value = value
        self.url = url

    @property
    def can_apply(self):
        return bool(self.ftype and self.command and self.value not in (None, "") and self.level == CHANGE)

    def __repr__(self):
        return "Advice({} {}: {} -> {})".format(self.level, self.setting, self.current, self.suggested)


def _num(text, default=None):
    if text is None:
        return default
    m = re.search(r"-?\d+(\.\d+)?([eE]-?\d+)?", str(text))
    return float(m.group(0)) if m else default


def _nums(text):
    return [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?(?:[eE]-?\d+)?", str(text or ""))]


def nice(x, up=False):
    """Round to 1, 2, 2.5, 5 x 10^n (down by default)."""
    if x is None or x <= 0:
        return x
    e = math.floor(math.log10(x))
    steps = [1, 2, 2.5, 5, 10]
    base = 10 ** e
    if up:
        for s in steps:
            if s * base >= x * 0.999:
                return round(s * base, 6)
    out = base
    for s in steps:
        if s * base <= x * 1.001:
            out = s * base
    return round(out, 6)


def fmt(v, digits=4):
    if v is None:
        return "-"
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return ("{:.%dg}" % digits).format(v)


def _manual(anchor):
    try:
        from .catalog import manual_url
        return manual_url(anchor)
    except Exception:
        return ""


# ---------------------------------------------------------------------------
def model_facts(project):
    """Numbers the advice needs, read from the control files."""
    f = {}
    tcf = project.files.get("TCF")
    tgc = project.files.get("TGC")
    ecf = project.files.get("ECF")
    if tcf is None:
        return f
    f["hpc"] = (tcf.value("Solution Scheme", "CLASSIC") or "").upper().startswith("HPC")
    f["gpu"] = (tcf.value("Hardware", "") or "").upper() == "GPU"
    f["sgs"] = (tcf.value("SGS", "") or "").upper() == "ON"
    f["dt"] = _num(tcf.value("Timestep"))
    f["start"] = _num(tcf.value("Start Time"), 0.0)
    f["end"] = _num(tcf.value("End Time"))
    f["map_int"] = _num(tcf.value("Map Output Interval"))
    f["ts_int"] = _num(tcf.value("Time Series Output Interval"))
    f["wetdry"] = _num(tcf.value("Cell Wet/Dry Depth"))
    f["cnf"] = _num(tcf.value("Control Number Factor"))
    f["rain"] = bool(tcf.find("Global Rainfall BC")) or bool(project.files.get("TBC") and
                                                            project.files["TBC"].find("Global Rainfall BC"))
    f["fm_linked"] = any(e.key.lower().startswith(("read gis x1d", "read gis isis")) for e in tcf.commands())
    cell = _num(tgc.value("Cell Size")) if tgc is not None else None
    if cell is None and "QCF" in project.files:
        cell = _num(project.files["QCF"].value("Base Cell Size"))
    f["cell"] = cell
    gs = _nums(tgc.value("Grid Size (X,Y)")) if tgc is not None else []
    f["grid"] = gs[:2] if len(gs) >= 2 else None
    f["ecf_dt"] = _num(ecf.value("Timestep")) if ecf is not None else None
    f["has_1d"] = ecf is not None
    f["min_channel"] = _shortest_channel(project) if ecf is not None else None
    return f


def _shortest_channel(project):
    """Shortest open-channel / culvert length in the 1d_nwk layers (m), or None."""
    try:
        from .model_inputs import model_inputs
        from osgeo import ogr
    except Exception:
        return None
    best = None
    try:
        refs = [r for r in model_inputs(project) if r.ftype == "ECF" and r.command.lower().startswith("read gis network")
                and r.exists]
    except Exception:
        return None
    for r in refs:
        try:
            ds = ogr.Open(r.path)
            if ds is None:
                continue
            lyr = ds.GetLayerByName(r.layer) if r.layer else ds.GetLayer(0)
            if lyr is None:
                continue
            names = [lyr.GetLayerDefn().GetFieldDefn(i).GetName().lower() for i in range(lyr.GetLayerDefn().GetFieldCount())]
            for feat in lyr:
                g = feat.GetGeometryRef()
                if g is None or "LINE" not in g.GetGeometryName().upper():
                    continue
                typ = (feat.GetField(names.index("type")) if "type" in names else "") or ""
                if typ.upper().startswith(("W", "X", "Q", "M", "P")):        # weirs, connectors ... have no length limit
                    continue
                L = None
                if "len_or_ana" in names:
                    L = feat.GetField(names.index("len_or_ana"))
                if not L or L <= 0:
                    L = g.Length()
                if L and L > 0 and (best is None or L < best):
                    best = L
            ds = None
        except Exception:
            continue
    return best


# ---------------------------------------------------------------------------
def suggest(project, tlf=None, hpc=None, mb=None, dt=None, po=None, cme_warn=1.0):
    """List of Advice for the open model (and the selected simulation, when given)."""
    out = []
    if project is None or project.files.get("TCF") is None:
        return out
    f = model_facts(project)
    cell, hpc_on = f.get("cell"), f.get("hpc")
    unstable = bool(tlf is not None and (tlf.status == "UNSTABLE" or tlf.nan_lines)) or \
        bool(hpc is not None and hpc.nan_lines)
    cme = None
    if mb is not None and getattr(mb, "ok", False):
        cme = mb.peak_abs_cme(ignore_first_fraction=0.05)
    elif tlf is not None and tlf.peak_cme is not None:
        cme = tlf.peak_cme
    bad_mass = cme is not None and abs(cme) > cme_warn
    neg_depth = bool(tlf is not None and tlf.negative_depth_lines)
    dts = dt.stats() if dt is not None and getattr(dt, "ok", False) else {}
    ran = tlf is not None or bool(dts)

    # -- 2D timestep -----------------------------------------------------------
    cur = f.get("dt")
    if cell:
        if not hpc_on:
            lo, hi, mid = cell / 5.0, cell / 2.0, cell / 4.0
            if unstable or neg_depth or bad_mass:
                target = nice(min(cur / 2.0 if cur else mid, cell / 5.0))
                why = ("The run was unstable" if unstable else "Negative depths were reported" if neg_depth else
                       "The mass error is {:.2f}%".format(cme)) + \
                    " - a smaller Classic timestep (about 1/5 of the cell size in m, or half the current value) " \
                    "usually fixes it. Also check the boundaries and steep / thin features at the flagged locations."
                out.append(Advice(CHANGE, "2D timestep (Classic)", "{} s".format(fmt(cur)), "{} s".format(fmt(target)),
                                  why, "TCF", "Timestep", fmt(target), _manual("tcf-Timestep")))
            elif cur is None:
                out.append(Advice(CHANGE, "2D timestep (Classic)", "not set", "{} s".format(fmt(nice(mid))),
                                  "Classic guidance: 1/4 to 1/2 of the cell size in metres, in seconds.",
                                  "TCF", "Timestep", fmt(nice(mid)), _manual("tcf-Timestep")))
            elif cur > hi * 1.001:
                out.append(Advice(CHANGE, "2D timestep (Classic)", "{} s".format(fmt(cur)), "{} s".format(fmt(nice(mid))),
                                  "{} s is more than half the {} m cell size - risk of instability.".format(fmt(cur), fmt(cell)),
                                  "TCF", "Timestep", fmt(nice(mid)), _manual("tcf-Timestep")))
            elif cur < lo * 0.999 and ran and not (bad_mass or unstable):
                out.append(Advice(CHANGE, "2D timestep (Classic)", "{} s".format(fmt(cur)), "{} s".format(fmt(nice(mid))),
                                  "The run was stable; a timestep near 1/4 of the cell size runs faster with the same "
                                  "results - re-check the mass error after.", "TCF", "Timestep", fmt(nice(mid)),
                                  _manual("tcf-Timestep")))
            else:
                out.append(Advice(KEEP, "2D timestep (Classic)", "{} s".format(fmt(cur)),
                                  "{} s (range {}-{} s)".format(fmt(cur), fmt(nice(lo)), fmt(nice(hi))),
                                  "Within the usual 1/5 to 1/2 of the {} m cell size.".format(fmt(cell)),
                                  url=_manual("tcf-Timestep")))
        else:
            start_dt = nice(cell / 4.0)
            txt = "HPC adapts the timestep; Timestep is only the first one."
            if dts:
                txt += " This run: min {} s, median {} s, max {} s.".format(fmt(dts["min_dt"]), fmt(dts["median_dt"]),
                                                                            fmt(dts["max_dt"]))
            if f.get("fm_linked"):
                out.append(Advice(INFO, "2D timestep (HPC)", "set in the Flood Modeller .ief", "-",
                                  "Flood Modeller sets the run times and 2D timestep of a linked model."))
            elif cur is None:
                out.append(Advice(CHANGE, "2D timestep (HPC start)", "not set", "{} s".format(fmt(start_dt)), txt,
                                  "TCF", "Timestep", fmt(start_dt), _manual("tcf-Timestep")))
            else:
                out.append(Advice(KEEP, "2D timestep (HPC start)", "{} s".format(fmt(cur)), "{} s".format(fmt(cur)), txt,
                                  url=_manual("tcf-Timestep")))
            # control numbers
            cnf = f.get("cnf")
            exceeded = dts and (dts.get("repeats") or any((dts.get(k) or 0) > lim * 1.001 for k, lim in
                                                          (("max_nu", 1.0), ("max_nc", 1.0), ("max_nd", 0.3))))
            if unstable or exceeded or (bad_mass and dts):
                target = 0.8 if (cnf is None or cnf >= 0.9) else round(max(0.5, cnf - 0.1), 2)
                out.append(Advice(CHANGE, "HPC Control Number Factor", fmt(cnf) if cnf is not None else "1 (default)",
                                  fmt(target), "Control numbers were exceeded / timesteps repeated" +
                                  (" or the run went unstable" if unstable else "") +
                                  ". A factor below 1 makes HPC take smaller, safer timesteps.",
                                  "TCF", "Control Number Factor", fmt(target), _manual("tcf-ControlNumberFactor")))
            else:
                out.append(Advice(KEEP, "HPC Control Number Factor", fmt(cnf) if cnf is not None else "1 (default)",
                                  fmt(cnf) if cnf is not None else "1 (default)",
                                  "No control-number problems" + (" in this run." if dts else " known yet - run the model "
                                                                                                "to check."),
                                  url=_manual("tcf-ControlNumberFactor")))
            if dts and dts.get("dt_drops"):
                out.append(Advice(CHECK, "HPC timestep drops", "min {} s vs median {} s".format(
                    fmt(dts["min_dt"]), fmt(dts["median_dt"])), "find the hot-spot",
                    "The timestep fell below 10% of its median {} times. Load the 'dt' map output (add dt to Map Output "
                    "Data Types) or the messages layer to find the cells - usually a deep hole, a steep drop, a "
                    "boundary or a 1D/2D link; smooth the topography or move the boundary.".format(dts["dt_drops"]),
                    "TCF", "", None, _manual("tcf-MapOutputDataTypes")))
    else:
        out.append(Advice(CHECK, "Cell size", "not set", "-", "Set Cell Size in the TGC (or Base Cell Size in the QCF)."))

    # -- cell size -------------------------------------------------------------
    if cell and f.get("grid"):
        w, h = f["grid"]
        n = (w / cell) * (h / cell)
        limit = 30e6 if (hpc_on and f.get("gpu")) else (8e6 if hpc_on else 2e6)
        if n > limit:
            target = nice(cell * math.sqrt(n / (limit * 0.5)), up=True)
            out.append(Advice(CHANGE, "Cell size", "{} m ({:,.0f} cells)".format(fmt(cell), n),
                              "{} m (~{:,.0f} cells)".format(fmt(target), n * (cell / target) ** 2),
                              "The grid is very large for {} - expect long runs / memory limits. Use a coarser cell "
                              "(with SGS on to keep channel conveyance) or a Quadtree mesh with fine cells only where "
                              "needed.".format("HPC on GPU" if hpc_on and f.get("gpu") else
                                               ("HPC on CPU" if hpc_on else "Classic")),
                              "TGC", "Cell Size", fmt(target), _manual("tgc-CellSize")))
        else:
            finer = cell / 2.0
            out.append(Advice(KEEP, "Cell size", "{} m ({:,.0f} cells)".format(fmt(cell), n),
                              "{} m; finer option {} m".format(fmt(cell), fmt(finer)),
                              "Aim for at least 4-5 cells across the main flow paths. Halving the cell size gives "
                              "~{:,.0f} cells and roughly 8x the run time (4x cells, half the timestep).".format(n * 4),
                              url=_manual("tgc-CellSize")))
        if hpc_on and not f.get("sgs") and cell >= 2:
            out.append(Advice(CHANGE, "Sub-grid sampling (SGS)", "off", "ON",
                              "With {} m cells, SGS samples the DEM inside each cell so narrow channels and banks keep "
                              "their storage and conveyance - often allowing a coarser, faster grid.".format(fmt(cell)),
                              "TCF", "SGS", "ON", _manual("tcf-SGS")))

    # -- wet / dry depth -------------------------------------------------------
    if f.get("rain"):
        wd = f.get("wetdry")
        if wd is None or wd > 0.0002 * 1.001:
            out.append(Advice(CHANGE, "Cell Wet/Dry Depth", fmt(wd) if wd is not None else "default (0.002 m)",
                              "0.0002 m", "Direct rainfall: a small wet/dry depth stops shallow sheet flow being "
                              "held back and keeps the mass balance right.",
                              "TCF", "Cell Wet/Dry Depth", "0.0002", _manual("tcf-CellWetDryDepth")))
        else:
            out.append(Advice(KEEP, "Cell Wet/Dry Depth", fmt(wd), fmt(wd), "Suitable for direct rainfall."))

    # -- 1D timestep -----------------------------------------------------------
    if f.get("has_1d"):
        cur1 = f.get("ecf_dt")
        L = f.get("min_channel")
        if L:
            # explicit 1D scheme: dt < L / (celerity + velocity); 5 m depth and 2 m/s as a safe guess
            lim = L / (math.sqrt(G * 5.0) + 2.0)
            target = nice(min(lim, (f.get("dt") or lim) if not hpc_on else lim))
            why = "Shortest channel {} m: the explicit 1D solver needs about dt < L / (sqrt(g d) + V) = {} s.".format(
                fmt(L, 3), fmt(lim, 3))
            if unstable and cur1:
                target = nice(min(target, cur1 / 2.0))
            if cur1 is None or cur1 > lim * 1.001 or (unstable and cur1 and cur1 > target):
                out.append(Advice(CHANGE, "1D timestep (ECF)", "{} s".format(fmt(cur1)) if cur1 else "not set",
                                  "{} s".format(fmt(target)), why + (" The run was unstable." if unstable else "") +
                                  " Or lengthen / merge very short channels.",
                                  "ECF", "Timestep", fmt(target), _manual("ecf-Timestep")))
            else:
                out.append(Advice(KEEP, "1D timestep (ECF)", "{} s".format(fmt(cur1)), "{} s (max ~{} s)".format(
                    fmt(cur1), fmt(nice(lim))), why))
        elif cur1 is None:
            guess = nice(max(0.5, (f.get("dt") or 2.0) / 2.0))
            out.append(Advice(CHANGE, "1D timestep (ECF)", "not set", "{} s".format(fmt(guess)),
                              "Typical ESTRY timestep: half the 2D Classic timestep; reduce it for short channels.",
                              "ECF", "Timestep", fmt(guess), _manual("ecf-Timestep")))
        else:
            out.append(Advice(KEEP, "1D timestep (ECF)", "{} s".format(fmt(cur1)), "{} s".format(fmt(cur1)),
                              "Channel lengths could not be read - keep the 1D timestep below about L/10 s for the "
                              "shortest channel L (m)."))

    # -- run length --------------------------------------------------------------
    st, et = f.get("start") or 0.0, f.get("end")
    late = _peak_at_end(po, mb)
    if et is not None and not f.get("fm_linked"):
        dur = et - st
        if late:
            target = nice(et + max(0.25 * dur, 0.5), up=True) if et > 1 else round(et + max(0.25 * dur, 0.5), 2)
            out.append(Advice(CHANGE, "End Time", "{} h".format(fmt(et)), "{} h".format(fmt(target)),
                              "{} still rising at the end of the run - the peak may be missed.".format(late),
                              "TCF", "End Time", fmt(target), _manual("tcf-EndTime")))
        else:
            out.append(Advice(KEEP if ran else INFO, "End Time", "{} h".format(fmt(et)), "{} h".format(fmt(et)),
                              "The peaks fall before the end of the run." if ran and (po or mb) else
                              "Run long enough for the flood peak to pass every location of interest "
                              "(checked after a run from the plot output)."))
        # -- output intervals
        if dur > 0:
            mi = f.get("map_int")
            want = nice(dur * 3600.0 / 100.0)
            if mi is None or mi <= 0:
                out.append(Advice(CHANGE, "Map Output Interval", "not set", "{} s".format(fmt(want)),
                                  "About 100 map outputs over the {} h run.".format(fmt(dur)),
                                  "TCF", "Map Output Interval", fmt(want), _manual("tcf-MapOutputInterval")))
            else:
                n_out = dur * 3600.0 / mi
                if n_out > 400 or n_out < 10:
                    out.append(Advice(CHANGE, "Map Output Interval", "{} s ({:,.0f} outputs)".format(fmt(mi), n_out),
                                      "{} s (~100 outputs)".format(fmt(want)),
                                      "Too many map outputs make large, slow result files." if n_out > 400 else
                                      "Too few map outputs to see how the flood develops.",
                                      "TCF", "Map Output Interval", fmt(want), _manual("tcf-MapOutputInterval")))
                else:
                    out.append(Advice(KEEP, "Map Output Interval", "{} s ({:,.0f} outputs)".format(fmt(mi), n_out),
                                      "{} s".format(fmt(mi)), "A reasonable number of map outputs. Maximums are "
                                                              "tracked every timestep anyway."))
            ti = f.get("ts_int")
            ts_want = 60.0 if dur * 3600.0 / 60.0 <= 20000 else nice(dur * 3600.0 / 10000.0)
            if ti is None or ti <= 0 or ti > max(300.0, (mi or 0) / 2.0):
                out.append(Advice(CHANGE, "Time Series Output Interval", "{} s".format(fmt(ti)) if ti else "not set",
                                  "{} s".format(fmt(ts_want)), "Plot-output and 1D time series should be finer than "
                                                               "the map output to catch the peaks.",
                                  "TCF", "Time Series Output Interval", fmt(ts_want),
                                  _manual("tcf-TimeSeriesOutputInterval")))
            else:
                out.append(Advice(KEEP, "Time Series Output Interval", "{} s".format(fmt(ti)), "{} s".format(fmt(ti)),
                                  "Fine enough to capture the hydrograph peaks."))

    # -- results quality ----------------------------------------------------------
    if cme is not None:
        if bad_mass:
            out.append(Advice(CHECK, "Mass error", "{:.2f}%".format(cme), "within +/-{:g}%".format(cme_warn),
                              "Look at when the error peaks (Mass error chart): early = initial conditions / dry "
                              "start; at boundaries = inflow location or HQ slope; with 1D = 1D/2D link or 1D "
                              "timestep. Classic: reduce the timestep.", url="https://wiki.tuflow.com/TUFLOW_Modelling_Guidance"))
        else:
            out.append(Advice(KEEP, "Mass error", "{:.2f}%".format(cme), "within +/-{:g}%".format(cme_warn),
                              "Volume is conserved well."))
    if tlf is not None and tlf.warnings:
        out.append(Advice(CHECK, "Log warnings", "{} warning(s)".format(len(tlf.warnings)), "0 unexplained",
                          "Review each warning (Logs tab or messages layer) - each links to its wiki page.",
                          url="https://wiki.tuflow.com/TUFLOW_Messages"))
    if not ran:
        out.append(Advice(INFO, "Simulation", "not run yet", "run a test (-t), then the model",
                          "More suggestions (timestep, control numbers, mass error, run length) appear once the "
                          "model has run."))
    return out


def _peak_at_end(po, mb):
    """Name of what is still rising at the end of the run (plot output or 2D volume), or ''."""
    if po:
        header, rows = po
        if header and rows and len(rows) > 5:
            hits = []
            for c in range(1, len(header)):
                vals = [r[c] for r in rows if len(r) > c and isinstance(r[c], float)]
                if len(vals) < 6:
                    continue
                vmax, vmin = max(vals), min(vals)
                if vmax - vmin < 1e-3:
                    continue
                tail = vals[-max(2, len(vals) // 20):]
                if vals[-1] >= vmax - 1e-6 and tail[-1] > tail[0] + 1e-6:
                    hits.append(header[c])
            if hits:
                return "{} ({})".format("Plot output" if len(hits) > 1 else "Plot output", ", ".join(hits[:3]) +
                                        (" ..." if len(hits) > 3 else ""))
    if mb is not None and getattr(mb, "vol", None):
        v = mb.vol
        if len(v) > 10 and v[-1] >= max(v) - 1e-9 and v[-1] > v[-len(v) // 10] * 1.01:
            return "The 2D volume"
    return ""
