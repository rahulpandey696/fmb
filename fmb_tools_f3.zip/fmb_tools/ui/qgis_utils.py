# -*- coding: utf-8 -*-
"""Thin wrappers around QGIS so the rest of the UI stays testable."""
import os

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices

try:
    from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer, QgsRectangle
    HAS_QGIS = True
except Exception:          # pragma: no cover - running outside QGIS
    HAS_QGIS = False

_IFACE = None


def set_iface(iface):
    global _IFACE
    _IFACE = iface


def iface():
    return _IFACE


def open_url(url):
    if url:
        QDesktopServices.openUrl(QUrl(url))


def open_path(path):
    if path and os.path.exists(path):
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


def project_layers(kind=None):
    """[(name, source, 'vector'|'raster', layer)] from the current QGIS project."""
    if not HAS_QGIS:
        return []
    out = []
    try:
        for lyr in QgsProject.instance().mapLayers().values():
            t = "vector" if isinstance(lyr, QgsVectorLayer) else (
                "raster" if isinstance(lyr, QgsRasterLayer) else "other")
            if kind and t != kind:
                continue
            out.append((lyr.name(), lyr.source(), t, lyr))
    except Exception:
        return []
    return sorted(out, key=lambda x: x[0].lower())


def layer_path_and_name(source):
    """Split a QGIS data source into (file path, layer name or '')."""
    src = source.split("|")
    path = src[0]
    name = ""
    for part in src[1:]:
        if part.lower().startswith("layername="):
            name = part.split("=", 1)[1]
    return path, name


def add_layer(path, name=None):
    """Add a vector/raster file (all layers of a GeoPackage) to the map."""
    if not HAS_QGIS or not path or not os.path.exists(path):
        return []
    name = name or os.path.splitext(os.path.basename(path))[0]
    added = []
    ext = os.path.splitext(path)[1].lower()
    prj = QgsProject.instance()
    if ext in (".tif", ".tiff", ".asc", ".flt", ".nc", ".vrt"):
        lyr = QgsRasterLayer(path, name)
        if lyr.isValid():
            prj.addMapLayer(lyr)
            added.append(lyr)
        return added
    if ext == ".gpkg":
        from ..core.qc import gpkg_layers
        names = gpkg_layers(path) or []
        for n in names:
            lyr = QgsVectorLayer("{}|layername={}".format(path, n), n, "ogr")
            if lyr.isValid():
                prj.addMapLayer(lyr)
                added.append(lyr)
            else:
                rl = QgsRasterLayer("GPKG:{}:{}".format(path, n), n)
                if rl.isValid():
                    prj.addMapLayer(rl)
                    added.append(rl)
        return added
    lyr = QgsVectorLayer(path, name, "ogr")
    if lyr.isValid():
        prj.addMapLayer(lyr)
        added.append(lyr)
    else:
        rl = QgsRasterLayer(path, name)
        if rl.isValid():
            prj.addMapLayer(rl)
            added.append(rl)
    return added


def layer_extent(layer):
    try:
        e = layer.extent()
        return e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum()
    except Exception:
        return None


def zoom_to(x, y, scale_m=200.0):
    if not HAS_QGIS or _IFACE is None:
        return
    try:
        x, y = float(x), float(y)
        canvas = _IFACE.mapCanvas()
        canvas.setExtent(QgsRectangle(x - scale_m, y - scale_m, x + scale_m, y + scale_m))
        canvas.refresh()
    except Exception:
        pass


def message(text, level="info", duration=5):
    if _IFACE is None:
        return
    try:
        from qgis.core import Qgis
        ml = getattr(Qgis, "MessageLevel", Qgis)
        names = {"info": "Info", "warning": "Warning", "error": "Critical", "success": "Success"}
        lv = getattr(ml, names[level])
        _IFACE.messageBar().pushMessage("FMB tools", text, level=lv, duration=duration)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# empty layers
def _field_index(lyr, key):
    """Field index from a name (Shapefile names are cut to 10 characters) or an int."""
    if isinstance(key, int):
        return key
    names = [f.name() for f in lyr.fields()]
    low = [n.lower() for n in names]
    k = str(key).lower()
    if k in low:
        return low.index(k)
    if k[:10] in low:
        return low.index(k[:10])
    return -1


def set_field_choices(lyr, key, choices):
    """Editable dropdown (pick a suggested value or type any value) for one field."""
    from .choice_widget import setup
    idx = _field_index(lyr, key)
    if idx >= 0 and choices:
        lyr.setEditorWidgetSetup(idx, setup(choices))
    return idx


def tuflow_layer_code(name):
    """'1d_nwk_M01_L' -> '1d_nwk' (the longest known TUFLOW layer prefix) or ''."""
    from ..core.empty_layers import BY_CODE
    low = (name or "").lower()
    best = ""
    for code in BY_CODE:
        if (low == code or low.startswith(code + "_")) and len(code) > len(best):
            best = code
    return best


def apply_tuflow_widgets(lyr, project=None):
    """Editable dropdowns (suggested values, free typing) on the TUFLOW fields of a loaded layer:
    1d_nwk Type, 2d_bc Type, 2d_code Code, 2d_mat Material, BC Name ... Returns the fields set."""
    if not HAS_QGIS or lyr is None:
        return []
    from ..core.empty_layers import BY_CODE
    code = tuflow_layer_code(lyr.name()) or tuflow_layer_code(os.path.basename(lyr.source().split("|")[0]))
    lt = BY_CODE.get(code)
    if lt is None or not lt.fields:
        return []
    done = []
    for f in lt.fields:
        choices = list(f.choices or [])
        try:
            if project is not None and code == "2d_mat" and f.name.lower().startswith("material"):
                choices = list(project.names("materials")) or choices
            elif project is not None and f.name.lower() == "name" and code in ("2d_bc", "1d_bc", "2d_sa", "2d_rf",
                                                                                "2d_sa_rf", "2d_sa_tr"):
                choices = list(project.names("bc")) or choices
        except Exception:
            pass
        if choices and set_field_choices(lyr, f.name, choices) >= 0:
            done.append(f.name)
    return done


def load_empty_layer(job, group_name="", defaults=None, closed=None, save_style=True, start_editing=False):
    """Load a newly written empty layer, set default values and dropdown widgets,
    store them as the layer's default style and put it in a layer-tree group.
    `defaults`: {field name: expression}; `closed`: {field name: [(value, meaning)]} - the dropdowns
    suggest these values but any value can be typed. Field names are matched to the layer's own
    fields (a GeoPackage adds 'fid' first; Shapefiles cut names to 10 characters)."""
    if not HAS_QGIS:
        return None
    try:
        from qgis.core import QgsDefaultValue
    except Exception:
        QgsDefaultValue = None
    lyr = QgsVectorLayer(job.uri, job.name, "ogr")
    if not lyr.isValid():
        return None
    try:
        if QgsDefaultValue is not None:
            for key, expr in (defaults or {}).items():
                idx = _field_index(lyr, key)
                if expr and idx >= 0:
                    lyr.setDefaultValueDefinition(idx, QgsDefaultValue(expr))
        for key, choices in (closed or {}).items():
            set_field_choices(lyr, key, choices)
        if save_style:
            if job.path.lower().endswith(".gpkg"):
                try:
                    lyr.saveStyleToDatabase(job.name, "FMB tools defaults", True, "")
                except TypeError:
                    pass
            else:
                lyr.saveNamedStyle(os.path.splitext(job.path)[0] + ".qml")
    except Exception:
        pass
    add_to_group(lyr, group_name)
    if start_editing and _IFACE is not None:
        try:
            _IFACE.setActiveLayer(lyr)
            lyr.startEditing()
        except Exception:
            pass
    return lyr


def project_crs():
    """(authid, wkt) of the QGIS project CRS or ('', '')."""
    if not HAS_QGIS:
        return "", ""
    try:
        crs = QgsProject.instance().crs()
        return crs.authid(), crs.toWkt()
    except Exception:
        return "", ""


def add_to_group(lyr, group_path="", replace=False, top=True):
    """Add a map layer to the project inside nested groups 'A/B/C' (created if needed).
    With replace=True layers of the same name in that group are removed first."""
    if not HAS_QGIS or lyr is None:
        return None
    prj = QgsProject.instance()
    root = prj.layerTreeRoot()
    parent = root
    for part in [p for p in (group_path or "").split("/") if p]:
        g = parent.findGroup(part)
        parent = g if g is not None else (parent.insertGroup(0, part) if top else parent.addGroup(part))
    if replace:
        for node in list(parent.findLayers()):
            if node.parent() is parent and node.name() == lyr.name():
                prj.removeMapLayer(node.layerId())
    prj.addMapLayer(lyr, False)
    parent.addLayer(lyr)
    return parent


# ---------------------------------------------------------------------------
# model inputs
def load_model_inputs(project, inputs=None, replace=True):
    """Load every GIS / grid input the model reads into a layer group '<model> - inputs',
    one sub-group per control file, points above lines above regions above grids.
    Returns (loaded_count, [skipped descriptions])."""
    if not HAS_QGIS or project is None:
        return 0, ["QGIS not available"]
    from ..core.model_inputs import model_inputs, GROUP_TITLES
    from .styles import tuflow_qml_for
    inputs = model_inputs(project) if inputs is None else inputs
    top = "{} - inputs".format(project.name)
    rank = {"P": 0, "L": 1, "R": 2, "": 3}
    order = sorted(range(len(inputs)), key=lambda i: (inputs[i].ftype, 4 if inputs[i].kind == "raster" else
                                                      rank.get(inputs[i].geom, 3), i))
    root = QgsProject.instance().layerTreeRoot()
    if replace:
        old = root.findGroup(top)
        if old is not None:
            for node in old.findLayers():
                QgsProject.instance().removeMapLayer(node.layerId())
            root.removeChildNode(old)
    loaded, skipped, seen = 0, [], set()
    for i in order:
        ref = inputs[i]
        key = (ref.uri, ref.kind)
        if key in seen:
            continue
        seen.add(key)
        if ref.exists is not True:
            skipped.append("{} ({}): {}".format(ref.name, ref.command, "not found" if ref.exists is False else ref.note))
            continue
        if ref.kind == "tin":
            skipped.append("{}: TIN files are not loaded".format(ref.name))
            continue
        lyr = QgsRasterLayer(ref.uri, ref.name) if ref.kind == "raster" else QgsVectorLayer(ref.uri, ref.name, "ogr")
        if not lyr.isValid():
            skipped.append("{}: could not be opened".format(ref.name))
            continue
        qml = tuflow_qml_for(ref.name) if ref.kind != "raster" else ""
        if qml:
            try:
                lyr.loadNamedStyle(qml)
            except Exception:
                pass
        if ref.kind != "raster":
            try:
                apply_tuflow_widgets(lyr, project)
            except Exception:
                pass
        add_to_group(lyr, "{}/{}".format(top, GROUP_TITLES.get(ref.ftype, ref.ftype)), top=False)
        loaded += 1
    grp = root.findGroup(top)
    if grp is not None and grp.parent() is root:
        clone = grp.clone()
        root.insertChildNode(0, clone)
        root.removeChildNode(grp)
    return loaded, skipped
