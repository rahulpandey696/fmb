# -*- coding: utf-8 -*-
"""
'FMB choice' attribute editor for the QGIS attribute form and table: an editable dropdown that
offers the usual TUFLOW values (with what they mean) but also takes anything you type -
e.g. 1d_nwk Type 'S', 'C', 'R', 'BB' ... or a culvert type with flags such as 'CU'.

Registered once per QGIS session (register()). Layers that use it but are opened without the
plugin fall back to QGIS's plain text editor, so values stay editable everywhere.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QComboBox, QLabel, QVBoxLayout

WIDGET_TYPE = "FmbChoice"
SEP = "  -  "

try:
    from qgis.gui import QgsGui, QgsEditorWidgetFactory, QgsEditorWidgetWrapper, QgsEditorConfigWidget
    HAS_GUI = True
except Exception:                                   # pragma: no cover - outside QGIS
    HAS_GUI = False


def _label(value, meaning):
    if value in (None, ""):
        return "(blank)" + (SEP + meaning if meaning else "")
    return "{}{}".format(value, SEP + meaning if meaning else "")


if HAS_GUI:
    class FmbChoiceWrapper(QgsEditorWidgetWrapper):
        """Editable combo box: pick a suggested value or type your own."""

        def __init__(self, vl, idx, editor, parent):
            super().__init__(vl, idx, editor, parent)
            self.combo = None

        def createWidget(self, parent):           # noqa: N802
            c = QComboBox(parent)
            c.setEditable(True)
            c.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
            return c

        def initWidget(self, editor):             # noqa: N802
            self.combo = editor if isinstance(editor, QComboBox) else None
            if self.combo is None:
                return
            self.combo.clear()
            for item in self.config().get("choices", []) or []:
                try:
                    v, m = (list(item) + ["", ""])[:2]
                except TypeError:
                    v, m = item, ""
                self.combo.addItem(_label(v, m), "" if v is None else str(v))
                self.combo.setItemData(self.combo.count() - 1, m or str(v), Qt.ItemDataRole.ToolTipRole)
            self.combo.setCurrentIndex(-1)
            self.combo.setToolTip("Pick a value or type any other value")
            if self.combo.lineEdit() is not None:
                self.combo.lineEdit().setPlaceholderText("pick or type a value")
            self.combo.currentTextChanged.connect(lambda _t: self.emitValueChanged())

        def valid(self):
            return self.combo is not None

        def _text(self):
            t = (self.combo.currentText() if self.combo is not None else "").strip()
            i = self.combo.findText(t) if self.combo is not None and t else -1
            if i >= 0:
                return self.combo.itemData(i) or ""
            if SEP in t:                          # a label that was edited - keep the value part
                t = t.split(SEP, 1)[0].strip()
            return "" if t == "(blank)" else t

        def value(self):
            t = self._text()
            if t == "":
                return None
            fld = self.field()
            try:
                if fld.isNumeric():
                    v = float(t.replace(",", "."))
                    if "int" in fld.typeName().lower():
                        return int(round(v))
                    return v
            except (ValueError, AttributeError):
                return t                          # QGIS shows it as invalid for a number field
            return t

        def updateValues(self, value, additionalValues=None):     # noqa: N802
            if self.combo is None:
                return
            v = "" if value is None or str(value) == "NULL" else str(value)
            if v.endswith(".0") and v[:-2].lstrip("-").isdigit():
                v = v[:-2]
            self.combo.blockSignals(True)
            i = self.combo.findData(v)
            if i >= 0:
                self.combo.setCurrentIndex(i)
            else:
                self.combo.setCurrentIndex(-1)
                self.combo.setEditText(v)
            self.combo.blockSignals(False)

        def setEnabled(self, on):                 # noqa: N802
            if self.combo is not None:
                self.combo.setEnabled(on)

    class FmbChoiceConfig(QgsEditorConfigWidget):
        def __init__(self, vl, idx, parent):
            super().__init__(vl, idx, parent)
            self._cfg = {}
            lay = QVBoxLayout(self)
            lab = QLabel("Editable dropdown set by FMB tools: suggested TUFLOW values, any other value can be typed.")
            lab.setWordWrap(True)
            lay.addWidget(lab)

        def config(self):
            return self._cfg

        def setConfig(self, cfg):                 # noqa: N802
            self._cfg = dict(cfg or {})

    class FmbChoiceFactory(QgsEditorWidgetFactory):
        def __init__(self):
            super().__init__("FMB choice (pick or type)")

        def create(self, vl, idx, editor, parent):
            return FmbChoiceWrapper(vl, idx, editor, parent)

        def fieldScore(self, vl, idx):           # noqa: N802 - never picked automatically for other fields
            return 0

        def configWidget(self, vl, idx, parent):  # noqa: N802
            return FmbChoiceConfig(vl, idx, parent)


def register():
    """Register the editor once per QGIS session. Returns True when it is available."""
    if not HAS_GUI:
        return False
    try:
        reg = QgsGui.editorWidgetRegistry()
        if WIDGET_TYPE in reg.factories():
            return True
        from qgis.core import QgsApplication
        app = QgsApplication.instance()
        factory = FmbChoiceFactory()
        ok = reg.registerWidget(WIDGET_TYPE, factory)
        if ok and app is not None:
            app._fmb_choice_factory = factory     # keep the Python object alive for the whole session
        return bool(ok)
    except Exception:
        return False


def setup(choices):
    """QgsEditorWidgetSetup for `choices` [(value, meaning)] - the FMB choice editor when available,
    otherwise a plain (free) text editor."""
    from qgis.core import QgsEditorWidgetSetup
    if register():
        return QgsEditorWidgetSetup(WIDGET_TYPE, {"choices": [[str(v), str(m or "")] for v, m in choices]})
    return QgsEditorWidgetSetup("TextEdit", {"IsMultiline": False, "UseHtml": False})
