# -*- coding: utf-8 -*-
"""
Home page: a welcome screen when no model is open, otherwise a model dashboard with build
progress (what is done, what is missing, where to fix it), key model facts, live checks,
the last simulation, the model's input layers and quick actions.
"""
import os
import re

from qgis.PyQt.QtCore import Qt, QSettings, QTimer
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QFrame,
                                 QScrollArea, QProgressBar, QListWidget, QListWidgetItem, QSizePolicy, QMessageBox)

from ..core import workflow as WF
from ..core.model_inputs import model_inputs
from ..core.domain import fmt
from . import qgis_utils as qu
from .theme import STATE_COLORS

STATE_LABEL = {"done": "Done", "todo": "To do", "warn": "Check", "error": "Fix", "optional": "Optional"}
RECENT_KEY = "fmb_tools/recent"


def add_recent(path, limit=8):
    if not path:
        return
    s = QSettings()
    cur = [p for p in (s.value(RECENT_KEY, []) or []) if p and os.path.normcase(p) != os.path.normcase(path)]
    if isinstance(cur, str):
        cur = [cur]
    s.setValue(RECENT_KEY, [path] + cur[:limit - 1])


def recent_models():
    v = QSettings().value(RECENT_KEY, []) or []
    return [v] if isinstance(v, str) else list(v)


def card(title, subtitle=""):
    f = QFrame()
    f.setObjectName("Card")
    f.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
    lay = QVBoxLayout(f)
    lay.setContentsMargins(16, 12, 16, 14)
    lay.setSpacing(6)
    t = QLabel(title)
    t.setObjectName("CardTitle")
    lay.addWidget(t)
    if subtitle:
        s = QLabel(subtitle)
        s.setObjectName("Muted")
        s.setWordWrap(True)
        lay.addWidget(s)
    return f, lay


def pill(text, state):
    col = STATE_COLORS.get(state, STATE_COLORS["todo"])
    lab = QLabel(text)
    lab.setStyleSheet("QLabel {{ background: {}; color: #ffffff; border-radius: 8px; padding: 1px 8px; "
                      "font-weight: 600; }}".format(col))
    lab.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
    return lab


def dot(state):
    lab = QLabel("●")
    lab.setStyleSheet("color: {}; font-size: 13pt;".format(STATE_COLORS.get(state, STATE_COLORS["todo"])))
    lab.setFixedWidth(16)
    return lab


def link(text, slot, tip=""):
    b = QPushButton(text)
    b.setProperty("flat", True)
    b.setFlat(True)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if tip:
        b.setToolTip(tip)
    b.clicked.connect(slot)
    return b


def button(text, slot, tip="", primary=False):
    b = QPushButton(text)
    if primary:
        b.setProperty("primary", True)
    if tip:
        b.setToolTip(tip)
    b.clicked.connect(slot)
    return b


def _num(v):
    try:
        return float(re.findall(r"-?\d+(?:\.\d+)?", v or "")[0])
    except (IndexError, ValueError):
        return None


class DashboardPage(QWidget):
    def __init__(self, main, parent=None):
        super().__init__(parent)
        self.setObjectName("FmbPage")
        self.main = main
        self.findings = None
        self.inputs = []
        self.steps = []
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        outer.addWidget(self.scroll)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.refresh)
        self.refresh()

    def schedule(self, ms=150):
        self._timer.start(ms)

    # ------------------------------------------------------------------------
    def refresh(self, run_checks=True):
        p = self.main.project
        if p is not None:
            try:
                self.inputs = model_inputs(p)
            except Exception:
                self.inputs = []
            if run_checks:
                try:
                    from ..core.qc import ModelChecker
                    sc, ev = self.main.batch_first()
                    self.findings = ModelChecker(p, scenarios=sc, events=ev).run()
                except Exception:
                    self.findings = None
            try:
                self.steps = WF.steps(p, self.inputs, self.findings, dirs=self.main.dirs())
            except Exception as ex:
                self.steps = [WF.Step("setup", "Model set up", "Project", WF.WARN, str(ex))]
        else:
            self.inputs, self.findings, self.steps = [], None, []
        host = QWidget()
        host.setObjectName("FmbPage")
        lay = QVBoxLayout(host)
        lay.setContentsMargins(24, 20, 24, 24)
        lay.setSpacing(16)
        if p is None:
            self._welcome(lay)
        else:
            self._model(lay, p)
        lay.addStretch(1)
        old = self.scroll.takeWidget()
        self.scroll.setWidget(host)
        if old is not None:
            old.deleteLater()
        self.main.update_badges(self.steps, self.findings)

    # -- no model -----------------------------------------------------------------
    def _welcome(self, lay):
        hero = QFrame()
        hero.setObjectName("Hero")
        hl = QVBoxLayout(hero)
        hl.setContentsMargins(26, 22, 26, 22)
        t = QLabel("Build TUFLOW models in QGIS")
        t.setStyleSheet("font-size: 20pt; font-weight: 700;")
        hl.addWidget(t)
        s = QLabel("Set up the model, draw the 2D domain on the map, create the GIS layers, write every control file "
                   "with guided inputs, check it, run it and load the results - one workflow, step by step on the left.")
        s.setWordWrap(True)
        s.setObjectName("Muted")
        hl.addWidget(s)
        row = QHBoxLayout()
        row.addWidget(button("New model", self.main.new_project, "Start the quick set-up", primary=True))
        row.addWidget(button("Open existing .tcf...", self.main.project_tab._open))
        row.addWidget(button("Import Flood Modeller model...", self.main.import_fm,
                             "Write a TUFLOW model from a Flood Modeller .ief / .dat / .xml"))
        row.addWidget(button("Create TUFLOW folder structure...", self.main.project_tab.create_folders))
        row.addStretch(1)
        hl.addLayout(row)
        lay.addWidget(hero)
        grid = QGridLayout()
        grid.setSpacing(16)
        c, cl = card("Recent models", "Double-click to open.")
        lst = QListWidget()
        lst.setMinimumHeight(170)
        for path in recent_models():
            it = QListWidgetItem("{}\n{}".format(os.path.splitext(os.path.basename(path))[0], path))
            it.setData(Qt.ItemDataRole.UserRole, path)
            if not os.path.isfile(path):
                it.setForeground(QColor(STATE_COLORS["todo"]))
                it.setToolTip("File not found")
            lst.addItem(it)
        if not lst.count():
            lst.addItem("No models opened yet")
        lst.itemDoubleClicked.connect(lambda it: it.data(Qt.ItemDataRole.UserRole) and
                                      self.main.open_model(it.data(Qt.ItemDataRole.UserRole)))
        cl.addWidget(lst)
        grid.addWidget(c, 0, 0)
        c, cl = card("How it works", "Follow the steps in the sidebar - each one turns green when it is done.")
        for n, (title, text) in enumerate((
                ("Project & domain", "Name, solver, cell size; draw the 2D domain on the map"),
                ("GIS layers", "Create 2d_code, 2d_mat, 2d_bc, 2d_po ... ready to draw in"),
                ("Control files", "TCF, TGC, TBC, ECF, TEF with guided commands"),
                ("Run", "Batch files for every scenario and event, or run from QGIS"),
                ("Check", "QC before the run, colour-coded logs and stability after it"),
                ("Results", "Load depth, velocity and hazard with TUFLOW styling")), 1):
            r = QHBoxLayout()
            num = QLabel(str(n))
            num.setFixedSize(22, 22)
            num.setAlignment(Qt.AlignmentFlag.AlignCenter)
            num.setStyleSheet("background: #1f6fd1; color: white; border-radius: 11px; font-weight: 700;")
            r.addWidget(num)
            lab = QLabel("<b>{}</b> &nbsp;<span style='color:gray'>{}</span>".format(title, text))
            lab.setWordWrap(True)
            r.addWidget(lab, 1)
            cl.addLayout(r)
        grid.addWidget(c, 0, 1)
        c, cl = card("Learn")
        for text, url in (("Tutorial Module 1 - your first 2D model", "https://wiki.tuflow.com/Tutorial_M01"),
                          ("TUFLOW Classic/HPC manual", "https://docs.tuflow.com/classic-hpc/manual/latest/"),
                          ("TUFLOW Wiki", "https://wiki.tuflow.com/Main_Page")):
            cl.addWidget(link(text, lambda _=False, u=url: qu.open_url(u)), 0, Qt.AlignmentFlag.AlignLeft)
        cl.addWidget(link("Help page in FMB tools", lambda: self.main.go("Help")), 0, Qt.AlignmentFlag.AlignLeft)
        grid.addWidget(c, 1, 0, 1, 2)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)

    # -- model --------------------------------------------------------------------
    def _model(self, lay, p):
        pct = WF.progress(self.steps)
        nxt = WF.next_step(self.steps)
        hero = QFrame()
        hero.setObjectName("Hero")
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(22, 16, 22, 16)
        left = QVBoxLayout()
        t = QLabel("{}% of the model is ready".format(pct))
        t.setStyleSheet("font-size: 16pt; font-weight: 700;")
        left.addWidget(t)
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(pct)
        bar.setFixedHeight(8)
        bar.setTextVisible(False)
        left.addWidget(bar)
        if nxt is not None:
            n = QLabel("<b>Next:</b> {} - {}".format(nxt.title, nxt.detail))
        else:
            n = QLabel("<b>Everything is in place.</b> Run the model or load the results.")
        n.setWordWrap(True)
        left.addWidget(n)
        hl.addLayout(left, 1)
        if nxt is not None:
            target = "{} \u203a {}".format(nxt.page, nxt.command) if nxt.command and nxt.page in self.main.editors \
                else self.main.page_title(nxt.page)
            hl.addWidget(button("Go to {}".format(target), lambda _=False, st=nxt: self.main.go_step(st), primary=True))
        else:
            hl.addWidget(button("Run simulation", self.main.run_now, primary=True))
        lay.addWidget(hero)

        grid = QGridLayout()
        grid.setSpacing(16)
        col0 = QVBoxLayout()
        col0.setSpacing(16)
        col1 = QVBoxLayout()
        col1.setSpacing(16)
        col0.addWidget(self._progress_card())
        col0.addWidget(self._files_card(p))
        col0.addStretch(1)
        col1.addWidget(self._facts_card(p))
        col1.addWidget(self._health_card())
        col1.addWidget(self._run_card(p))
        col1.addWidget(self._inputs_card())
        col1.addStretch(1)
        grid.addLayout(col0, 0, 0)
        grid.addLayout(col1, 0, 1)
        grid.setColumnStretch(0, 5)
        grid.setColumnStretch(1, 4)
        lay.addLayout(grid)

    def _progress_card(self):
        c, cl = card("Build progress", "Every step of a TUFLOW model - click Open to fix or finish one.")
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        for r, s in enumerate(self.steps):
            g.addWidget(dot(s.state), r, 0)
            t = QLabel("<b>{}</b><br><span style='color:gray'>{}</span>".format(s.title, s.detail or ""))
            t.setWordWrap(True)
            g.addWidget(t, r, 1)
            g.addWidget(pill(STATE_LABEL[s.state], s.state), r, 2)
            g.addWidget(link("Open", lambda _=False, st=s: self.main.go_step(st),
                             "{} \u203a {}".format(s.page, s.command) if s.command else self.main.page_title(s.page)), r, 3)
        g.setColumnStretch(1, 1)
        cl.addLayout(g)
        return c

    def _facts_card(self, p):
        c, cl = card("Model")
        tcf, tgc, qcf = p.files.get("TCF"), p.files.get("TGC"), p.files.get("QCF")
        val = lambda cf, k, d="": ((cf.value(k) if cf is not None else None) or d).strip()
        solver = val(tcf, "Solution Scheme", "CLASSIC")
        hw = val(tcf, "Hardware", "CPU") if solver.upper().startswith("HPC") else ""
        cell = val(tgc, "Cell Size") or (val(qcf, "Base Cell Size") if qcf is not None else "")
        gs = val(tgc, "Grid Size (X,Y)")
        cells = ""
        cs, parts = _num(cell), [_num(x) for x in gs.split(",")] if gs else []
        if cs and len(parts) == 2 and all(parts):
            cells = "{:,} cells".format(int(round(parts[0] / cs)) * int(round(parts[1] / cs)))
        loc = val(tgc, "Read GIS Location") or (("Origin " + val(tgc, "Origin")) if val(tgc, "Origin") else "")
        evs = p.events_defined()
        sc = p.scenario_names() if hasattr(p, "scenario_names") else []
        rows = [("Solver", "{}{}".format(solver, " on " + hw if hw else "")),
                ("Cell size", (cell + " m") if cell else "not set" + (" (Quadtree)" if qcf is not None else "")),
                ("Grid", "{} m{}".format(gs, "  -  " + cells if cells else "") if gs else "not set"),
                ("Location", loc or "not set"),
                ("Time", "{} to {} h, timestep {} s".format(val(tcf, "Start Time", "0"), val(tcf, "End Time", "?"),
                                                           val(tcf, "Timestep", "?"))),
                ("Map output", "{} | {} every {} s".format(val(tcf, "Map Output Format", "-"),
                                                          val(tcf, "Map Output Data Types", "-"),
                                                          val(tcf, "Map Output Interval", "-"))),
                ("Events", ", ".join(evs) if evs else "single event"),
                ("Scenarios", ", ".join(sc) if sc else "none")]
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(3)
        for r, (k, v) in enumerate(rows):
            kl = QLabel(k)
            kl.setObjectName("Muted")
            g.addWidget(kl, r, 0, Qt.AlignmentFlag.AlignTop)
            vl = QLabel(v)
            vl.setWordWrap(True)
            vl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            g.addWidget(vl, r, 1)
        g.setColumnStretch(1, 1)
        cl.addLayout(g)
        return c

    def _health_card(self):
        c, cl = card("Model checks", "Checked automatically: required commands, files, layers, timestep, "
                                     "materials, BC database, events ...")
        if self.findings is None:
            cl.addWidget(QLabel("Checks could not run."))
            return c
        counts = {}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        r = QHBoxLayout()
        for sev, state in (("ERROR", "error"), ("WARNING", "warn"), ("INFO", "todo")):
            r.addWidget(pill("{} {}".format(counts.get(sev, 0), sev.lower() + ("s" if counts.get(sev, 0) != 1 else "")),
                             state if counts.get(sev, 0) else "done"))
        r.addStretch(1)
        cl.addLayout(r)
        for f in [f for f in self.findings if f.severity in ("ERROR", "WARNING")][:5]:
            row = QHBoxLayout()
            row.addWidget(dot("error" if f.severity == "ERROR" else "warn"), 0, Qt.AlignmentFlag.AlignTop)
            lab = QLabel("<b>{}</b> {}".format(f.ftype, f.message))
            lab.setWordWrap(True)
            row.addWidget(lab, 1)
            cl.addLayout(row)
        cl.addWidget(link("Open all checks in QC  →", self.main.run_qc), 0, Qt.AlignmentFlag.AlignLeft)
        return c

    def _run_card(self, p):
        c, cl = card("Last simulation")
        try:
            state, detail, sim = WF.run_status(p, self.main.dirs())
        except Exception:
            state, detail, sim = WF.TODO, "", ""
        r = QHBoxLayout()
        r.addWidget(pill({"done": "Finished", "warn": "Check", "error": "Problem", "todo": "Not run"}.get(state, state),
                         state))
        lab = QLabel(detail or "No simulation log found yet.")
        lab.setWordWrap(True)
        r.addWidget(lab, 1)
        cl.addLayout(r)
        r = QHBoxLayout()
        r.addWidget(button("Test run (-t)", self.main.run_test, "Read the inputs and write check files only"))
        r.addWidget(button("Run", self.main.run_now, "Run the simulation(s) set in Batch & Run"))
        r.addWidget(link("Logs", lambda: self.main.go("Logs")))
        r.addWidget(link("Stability", lambda: self.main.go("Stability")))
        r.addWidget(link("Results", lambda: self.main.go("Outputs")))
        r.addStretch(1)
        cl.addLayout(r)
        return c

    def _inputs_card(self):
        c, cl = card("Input layers", "Every GIS layer and grid the control files read.")
        ok = sum(1 for i in self.inputs if i.exists is True)
        bad = [i for i in self.inputs if i.exists is False]
        unk = sum(1 for i in self.inputs if i.exists is None)
        r = QHBoxLayout()
        r.addWidget(pill("{} found".format(ok), "done" if ok else "todo"))
        if bad:
            r.addWidget(pill("{} missing".format(len(bad)), "error"))
        if unk:
            r.addWidget(pill("{} with tokens".format(unk), "todo"))
        r.addStretch(1)
        cl.addLayout(r)
        for i in bad[:4]:
            lab = QLabel("<span style='color:{}'>●</span> {} <span style='color:gray'>({}: {})</span>".format(
                STATE_COLORS["error"], i.name, i.ftype, i.command))
            lab.setWordWrap(True)
            cl.addWidget(lab)
        b = button("Load model inputs to map", self.load_inputs,
                   "Add every input layer to a '<model> - inputs' group, one sub-group per control file",
                   primary=bool(ok))
        b.setEnabled(bool(ok))
        cl.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        return c

    def _files_card(self, p):
        c, cl = card("Control files")
        from ..core.catalog import CONTROL_FILE_TYPES, FILE_TYPE_INFO
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(4)
        r = 0
        for ft in CONTROL_FILE_TYPES:
            cf = p.files.get(ft)
            if cf is None:
                continue
            ed = self.main.editors.get(ft)
            if not cf.path or not os.path.isfile(cf.path):
                st, txt = "warn", "not saved"
            elif ed is not None and ed.dirty:
                st, txt = "warn", "modified"
            else:
                st, txt = "done", "saved"
            g.addWidget(QLabel("<b>{}</b>".format(ft)), r, 0)
            nm = QLabel(os.path.basename(cf.path) if cf.path else "-")
            nm.setToolTip(cf.path or "")
            nm.setObjectName("Muted")
            g.addWidget(nm, r, 1)
            g.addWidget(pill(txt, st), r, 2)
            g.addWidget(link("Open", lambda _=False, f=ft: self.main.show_tab(f)), r, 3)
            r += 1
        g.setColumnStretch(1, 1)
        cl.addLayout(g)
        row = QHBoxLayout()
        row.addWidget(button("Save all", self.main.save_all, primary=True))
        row.addWidget(button("Open model folder", lambda: qu.open_path(p.root)))
        row.addWidget(button("Add a control file...", lambda: self.main.go("Other files")))
        row.addStretch(1)
        cl.addLayout(row)
        return c

    def load_inputs(self):
        n, skipped = qu.load_model_inputs(self.main.project, self.inputs)
        msg = "{} input layer(s) loaded into '{} - inputs'.".format(n, self.main.project.name)
        if skipped:
            msg += "\n\nNot loaded:\n" + "\n".join(skipped[:15])
        QMessageBox.information(self, "Model inputs", msg)
