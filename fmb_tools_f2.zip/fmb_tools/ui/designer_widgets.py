# -*- coding: utf-8 -*-
"""
Qt Designer support.

FMB tools' own widgets appear in the .ui files (folder ui/designer) as *promoted* widgets:
in Qt Designer they look like their base class (QWidget, QDoubleSpinBox ...) and their
settings are dynamic properties you can edit in the Property Editor:

    FmbPathEdit     fmbKind (file | folder | gis | grid), fmbFilter, fmbPlaceholder
    FmbRadioChoice  fmbOptions ('HPC|CLASSIC'), fmbDefault (underlined TUFLOW default), fmbValue
    FmbNumberSpin   fmbUnit, fmbIsInt, fmbMin, fmbMax, fmbStep, fmbDefault, fmbPrefix
    FmbTokenListEdit  fmbSeparator, fmbPlaceholder (tokens are filled by the code)
    FmbChoiceEdit   items and 'editable' as for a normal QComboBox
    SmartDoubleSpin / SmartIntSpin  normal spin-box properties (with reliable paste)

load_ui(widget, 'project_tab.ui') builds the widget from the file and applies those properties.
Keep the objectName of every widget the code uses (the .ui file lists them); everything else -
layout, order, labels, tooltips, sizes, group boxes - can be changed freely in Designer.
"""
import os
import sys

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QWidget

from .widgets import (PathEdit, RadioChoice, NumberSpin, TokenListEdit, ChoiceEdit, SmartDoubleSpin,
                      SmartIntSpin, LogView, LineChart, NumberEdit)

DESIGNER_DIR = os.path.join(os.path.dirname(__file__), "designer")
UI_MODULE = "fmb_tools.ui.designer_widgets"       # the 'header' used in the .ui files


def _prop(w, name, default=None):
    v = w.property(name)
    if v is None:
        return default
    try:                                # QVariant from older bindings
        v = v.toPyObject() if hasattr(v, "toPyObject") else v
    except Exception:
        pass
    return v


def _num(w, name, default=None):
    v = _prop(w, name, None)
    if v in (None, ""):
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _bool(w, name, default=False):
    v = _prop(w, name, None)
    if v is None:
        return default
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on")
    return bool(v)


class FmbPathEdit(PathEdit):
    def __init__(self, parent=None):
        super().__init__("file", "", None, None, parent)

    def apply_designer_properties(self):
        self.set_kind(_prop(self, "fmbKind", "file") or "file", _prop(self, "fmbFilter", "") or None,
                      _prop(self, "fmbPlaceholder", "") or None)


class FmbRadioChoice(RadioChoice):
    def __init__(self, parent=None):
        super().__init__([], "", parent)

    def apply_designer_properties(self):
        opts = [o.strip() for o in str(_prop(self, "fmbOptions", "") or "").split("|") if o.strip()]
        self.set_options(opts, str(_prop(self, "fmbDefault", "") or ""))
        val = str(_prop(self, "fmbValue", "") or "")
        if val:
            self.setValue(val)


class FmbNumberSpin(NumberSpin):
    def __init__(self, parent=None):
        super().__init__(parent=parent)

    def apply_designer_properties(self):
        self.configure(unit=str(_prop(self, "fmbUnit", "") or ""), is_int=_bool(self, "fmbIsInt"),
                       lo=_num(self, "fmbMin", -1e9), hi=_num(self, "fmbMax", 1e9), step=_num(self, "fmbStep", 1.0),
                       default=_num(self, "fmbDefault", None), prefix=str(_prop(self, "fmbPrefix", "") or ""))
        self.unset()


class FmbTokenListEdit(TokenListEdit):
    def __init__(self, parent=None):
        super().__init__([], parent)

    def apply_designer_properties(self):
        sep = _prop(self, "fmbSeparator", None)
        if sep:
            self.sep = str(sep)
        ph = _prop(self, "fmbPlaceholder", "")
        if ph:
            self.line.setPlaceholderText(str(ph))


class FmbChoiceEdit(ChoiceEdit):
    def __init__(self, parent=None):
        super().__init__([], False, "", parent)
        self.clear()


class FmbLogView(LogView):
    """Colour-coded log view (fmbPlaceholder)."""

    def __init__(self, parent=None):
        super().__init__("", 0, parent)

    def apply_designer_properties(self):
        ph = _prop(self, "fmbPlaceholder", "")
        if ph:
            self.edit.setPlaceholderText(str(ph))


class FmbNumberEdit(NumberEdit):
    """X, Y pair (or more) of number boxes - fmbParts = number of boxes, fmbUnit."""

    def __init__(self, parent=None):
        super().__init__([{}, {}], None, parent)


# names used in the .ui <customwidgets> section
CUSTOM_WIDGETS = {
    "FmbPathEdit": "QWidget", "FmbRadioChoice": "QWidget", "FmbNumberSpin": "QDoubleSpinBox",
    "FmbTokenListEdit": "QWidget", "FmbChoiceEdit": "QComboBox", "SmartDoubleSpin": "QDoubleSpinBox",
    "SmartIntSpin": "QSpinBox", "FmbLogView": "QWidget", "FmbNumberEdit": "QWidget", "LineChart": "QWidget",
}


def _alias_package():
    """The .ui files name their custom widgets' module 'fmb_tools.ui.designer_widgets'. If the
    plugin folder has another name, make that import path point at this module."""
    me = sys.modules[__name__]
    if UI_MODULE in sys.modules:
        return
    root = __name__.split(".")[0]
    sys.modules.setdefault("fmb_tools", sys.modules[root])
    sys.modules.setdefault("fmb_tools.ui", sys.modules[__name__.rsplit(".", 1)[0]])
    sys.modules[UI_MODULE] = me


def ui_path(name):
    return os.path.join(DESIGNER_DIR, name)


def load_ui(widget, name):
    """Build `widget` from ui/designer/<name> and apply the fmb* properties."""
    _alias_package()
    uic.loadUi(ui_path(name), widget)
    for w in widget.findChildren(QWidget):
        fn = getattr(w, "apply_designer_properties", None)
        if fn is not None:
            fn()
    return widget


# make SmartDoubleSpin / SmartIntSpin importable from this module as well
__all__ = ["FmbPathEdit", "FmbRadioChoice", "FmbNumberSpin", "FmbTokenListEdit", "FmbChoiceEdit",
           "SmartDoubleSpin", "SmartIntSpin", "FmbLogView", "FmbNumberEdit", "LineChart", "load_ui", "ui_path"]
