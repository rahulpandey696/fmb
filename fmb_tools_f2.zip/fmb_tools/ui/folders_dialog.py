# -*- coding: utf-8 -*-
"""Dialog that creates the standard TUFLOW folder structure at a chosen location."""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QCheckBox,
                                 QTreeWidget, QTreeWidgetItem, QPlainTextEdit, QPushButton, QMessageBox,
                                 QHeaderView, QSplitter, QWidget)

from ..core.folders import FOLDER_TREE, with_parents, normalise, create_folder_structure
from . import qgis_utils as qu
from .widgets import PathEdit, mono_font

ROLE_REL = Qt.ItemDataRole.UserRole


class FolderStructureDialog(QDialog):
    """Pick a location and the folders, preview, create. After exec() `root` holds the created
    model root folder (or '' if nothing was created)."""

    def __init__(self, start_dir="", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create TUFLOW folder structure")
        self.resize(900, 600)
        self.root = ""
        lay = QVBoxLayout(self)
        intro = QLabel("Creates the folder layout used by the TUFLOW tutorial models. Existing folders and files "
                       "are never changed - only missing folders are added.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        form = QFormLayout()
        self.location = PathEdit("folder", "", lambda: "")
        self.location.line.setPlaceholderText("Where to create the folders, e.g. D:\\Projects\\River_Study")
        self.location.setValue(start_dir or "")
        self.location.changed.connect(self._preview)
        form.addRow("Location", self.location)
        row = QHBoxLayout()
        self.use_sub = QCheckBox("Create inside a new sub-folder named")
        self.use_sub.setChecked(True)
        self.sub = QLineEdit("TUFLOW")
        self.sub.setMaximumWidth(220)
        self.use_sub.toggled.connect(self.sub.setEnabled)
        self.use_sub.toggled.connect(self._preview)
        self.sub.textChanged.connect(self._preview)
        row.addWidget(self.use_sub)
        row.addWidget(self.sub)
        row.addStretch(1)
        form.addRow("", row)
        lay.addLayout(form)

        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Folder", "What goes in it"])
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self._items = {}
        for rel, on, note in FOLDER_TREE:
            parent_rel, _sep, name = rel.rpartition("/")
            it = QTreeWidgetItem([name, note])
            it.setToolTip(1, note)
            it.setData(0, ROLE_REL, rel)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(0, Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
            parent = self._items.get(parent_rel)
            if parent is None:
                self.tree.addTopLevelItem(it)
            else:
                parent.addChild(it)
            self._items[rel] = it
        self.tree.expandAll()
        self.tree.resizeColumnToContents(0)
        self.tree.itemChanged.connect(self._item_changed)
        ll.addWidget(self.tree, 1)
        erow = QHBoxLayout()
        erow.addWidget(QLabel("Extra folders"))
        self.extra = QLineEdit()
        self.extra.setPlaceholderText("optional, comma separated - e.g. model/gis/survey, bc_dbase/rainfall")
        self.extra.textChanged.connect(self._preview)
        erow.addWidget(self.extra, 1)
        ll.addLayout(erow)
        split.addWidget(left)
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setFont(mono_font())
        split.addWidget(self.preview)
        split.setSizes([560, 320])
        lay.addWidget(split, 1)

        opts = QHBoxLayout()
        self.readme = QCheckBox("Write a readme.txt in each new folder")
        self.readme.setToolTip("A short note in each folder saying what belongs there")
        self.set_root = QCheckBox("Use it as the model root in the Project tab")
        self.set_root.setChecked(True)
        self.open_after = QCheckBox("Open the folder afterwards")
        for w in (self.readme, self.set_root, self.open_after):
            opts.addWidget(w)
        opts.addStretch(1)
        lay.addLayout(opts)
        btns = QHBoxLayout()
        btns.addStretch(1)
        self.create_btn = QPushButton("Create folders")
        self.create_btn.setDefault(True)
        self.create_btn.setStyleSheet("font-weight: bold; padding: 5px 14px;")
        self.create_btn.clicked.connect(self.create)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        btns.addWidget(self.create_btn)
        btns.addWidget(close)
        lay.addLayout(btns)
        self._preview()

    # -- selection ---------------------------------------------------------
    def _item_changed(self, item, col):
        if col != 0:
            return
        self.tree.blockSignals(True)
        state = item.checkState(0)
        if state == Qt.CheckState.Unchecked:          # untick children too
            stack = [item.child(i) for i in range(item.childCount())]
            while stack:
                c = stack.pop()
                c.setCheckState(0, Qt.CheckState.Unchecked)
                stack += [c.child(i) for i in range(c.childCount())]
        else:                                         # a ticked folder needs its parents
            p = item.parent()
            while p is not None:
                p.setCheckState(0, Qt.CheckState.Checked)
                p = p.parent()
        self.tree.blockSignals(False)
        self._preview()

    def selected(self):
        rels = [rel for rel, it in self._items.items() if it.checkState(0) == Qt.CheckState.Checked]
        rels += [normalise(x) for x in self.extra.text().replace(";", ",").split(",")]
        return with_parents([r for r in rels if r])

    def target(self):
        loc = (self.location.value() or "").strip().strip('"').replace("\\", os.sep).replace("/", os.sep)
        if not loc:
            return ""
        sub = self.sub.text().strip().strip("/\\")
        return os.path.join(loc, sub) if self.use_sub.isChecked() and sub else loc

    def _preview(self, *_):
        base = self.target()
        rels = self.selected()
        lines = [(base or "<choose a location>").rstrip("/\\") + os.sep]
        for r in sorted(rels, key=lambda s: s.lower().split("/")):
            exists = bool(base) and os.path.isdir(os.path.join(base, *r.split("/")))
            lines.append("    " * (r.count("/") + 1) + r.split("/")[-1] + "/" + ("   (exists)" if exists else ""))
        self.preview.setPlainText("\n".join(lines))
        self.create_btn.setEnabled(bool(base and rels))

    # -- create ---------------------------------------------------------------
    def create(self):
        base = self.target()
        if not base:
            QMessageBox.warning(self, "Folders", "Choose a location first.")
            return
        if not os.path.isdir(os.path.dirname(base.rstrip("/\\")) or base):
            QMessageBox.warning(self, "Folders", "The location does not exist:\n{}".format(self.location.value()))
            return
        try:
            created, existing = create_folder_structure(base, self.selected(), self.readme.isChecked())
        except OSError as e:
            QMessageBox.critical(self, "Folders", "Could not create the folders:\n{}".format(e))
            return
        self.root = base
        msg = "{} folder(s) created in\n{}".format(len(created), base)
        if existing:
            msg += "\n\n{} already existed and were left unchanged.".format(len(existing))
        qu.message("TUFLOW folder structure: {} created, {} existing - {}".format(
            len(created), len(existing), base), "success" if created else "info")
        QMessageBox.information(self, "Folders", msg)
        if self.open_after.isChecked():
            qu.open_path(base)
        self.accept()
