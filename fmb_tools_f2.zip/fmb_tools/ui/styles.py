# -*- coding: utf-8 -*-
"""
Symbology for TUFLOW results.

* Vector layers (check files, plot output, 1D results, messages): the .qml
  styles shipped with the official TUFLOW QGIS plugin are used when that plugin
  is installed (matched by layer-name suffix, longest first - the same rule the
  TUFLOW plugin uses). FMB tools does not copy those files.
* Grids and meshes: FMB flood-mapping classes - depth, velocity and hazard in
  fixed classes, water level and other types stretched between min and max.
"""
import glob
import os

from qgis.PyQt.QtGui import QColor

INF = float("inf")

# class schemes: (upper bound, colour, label); None as bound = min/max stretch
CLASSES = {
    "d": ("Depth (m)", [(0.15, "#c6dbef", "0 - 0.15"), (0.3, "#9ecae1", "0.15 - 0.3"), (0.5, "#6baed6", "0.3 - 0.5"),
                        (1.0, "#3182bd", "0.5 - 1.0"), (2.0, "#08519c", "1.0 - 2.0"), (INF, "#08306b", "> 2.0")]),
    "V": ("Velocity (m/s)", [(0.5, "#ffffb2", "0 - 0.5"), (1.0, "#fed976", "0.5 - 1.0"), (1.5, "#feb24c", "1.0 - 1.5"),
                             (2.0, "#fd8d3c", "1.5 - 2.0"), (3.0, "#f03b20", "2.0 - 3.0"), (INF, "#bd0026", "> 3.0")]),
    "Z0": ("Velocity x depth (m2/s)", [(0.1, "#1a9850", "0 - 0.1"), (0.3, "#a6d96a", "0.1 - 0.3"),
                                       (0.6, "#fee08b", "0.3 - 0.6"), (1.0, "#fc8d59", "0.6 - 1.0"),
                                       (INF, "#d73027", "> 1.0")]),
    "ZAEM1": ("Hazard category", [(1, "#66bd63", "H1"), (2, "#d9ef8b", "H2"), (3, "#fee08b", "H3"),
                                  (4, "#fdae61", "H4"), (5, "#f46d43", "H5"), (6, "#a50026", "H6")]),
}
STRETCH = {
    "h": ("Water level (m)", ["#2b83ba", "#abdda4", "#ffffbf", "#fdae61", "#d7191c"]),
    "q": ("Unit flow (m2/s)", ["#fcfbfd", "#bcbddc", "#807dba", "#54278f", "#3f007d"]),
    "time": ("Time (h)", ["#440154", "#3b528b", "#21918c", "#5ec962", "#fde725"]),
    "DEM_Z": ("Elevation (m)", ["#1a9641", "#a6d96a", "#ffffbf", "#fdae61", "#a6611a"]),
    "n": ("Manning's n", ["#ffffcc", "#c2e699", "#78c679", "#31a354", "#006837"]),
    "other": ("Value", ["#f7fcf5", "#c7e9c0", "#74c476", "#238b45", "#00441b"]),
}
MESH_KEYWORDS = [("hazard", "ZAEM1"), ("z0", "Z0"), ("depth", "d"), ("water level", "h"), ("velocity", "V"),
                 ("unit flow", "q"), ("time", "time"), ("bed elevation", "DEM_Z")]


def scheme_for(dtype):
    if dtype in CLASSES:
        return "classes", CLASSES[dtype]
    d = dtype or ""
    if d.lower().startswith(("tmax", "tmin", "tdur", "tinun")):
        return "stretch", STRETCH["time"]
    if d in STRETCH:
        return "stretch", STRETCH[d]
    if d == "DEM_M":
        return "stretch", STRETCH["other"]
    return "stretch", STRETCH["other"]


def legend_html(dtype):
    """Small HTML legend for the Outputs tab preview."""
    kind, (title, spec) = scheme_for(dtype)
    rows = ["<b>{}</b><table cellspacing='2'>".format(title)]
    if kind == "classes":
        for _v, col, lbl in spec:
            rows.append("<tr><td bgcolor='{}' width='28'>&nbsp;</td><td>{}</td></tr>".format(col, lbl))
    else:
        rows.append("<tr>" + "".join("<td bgcolor='{}' width='22'>&nbsp;</td>".format(c) for c in spec) + "</tr>")
        rows.append("<tr><td colspan='{}'>minimum &rarr; maximum of the layer</td></tr>".format(len(spec)))
    rows.append("</table>")
    return "".join(rows)


# ---------------------------------------------------------------------------
def _qgis():
    from qgis import core
    return core


def _ramp_type(name):
    core = _qgis()
    try:
        return getattr(core.Qgis.ShaderInterpolationMethod, name)
    except AttributeError:
        return getattr(core.QgsColorRampShader, name)


def _interp_colors(colors, n):
    cols = [QColor(c) for c in colors]
    out = []
    for i in range(n):
        t = i / float(max(1, n - 1)) * (len(cols) - 1)
        a = int(t)
        b = min(a + 1, len(cols) - 1)
        f = t - a
        c1, c2 = cols[a], cols[b]
        out.append(QColor(int(c1.red() + (c2.red() - c1.red()) * f), int(c1.green() + (c2.green() - c1.green()) * f),
                          int(c1.blue() + (c2.blue() - c1.blue()) * f)))
    return out


def make_shader(dtype, vmin=None, vmax=None, cutoff=None):
    """QgsColorRampShader for a data type."""
    core = _qgis()
    kind, (title, spec) = scheme_for(dtype)
    sh = core.QgsColorRampShader()
    items = []
    if kind == "classes":
        exact = dtype == "ZAEM1"
        sh.setColorRampType(_ramp_type("Exact" if exact else "Discrete"))
        if cutoff and dtype == "d" and cutoff > 0:
            items.append(core.QgsColorRampShader.ColorRampItem(cutoff, QColor(0, 0, 0, 0), "< {:g} (hidden)".format(cutoff)))
        for k, (v, col, lbl) in enumerate(spec):
            if k == 0 and cutoff and dtype == "d" and cutoff > 0:
                lbl = "{:g} - {}".format(cutoff, lbl.split(" - ")[-1])
            items.append(core.QgsColorRampShader.ColorRampItem(v, QColor(col), lbl))
    else:
        sh.setColorRampType(_ramp_type("Interpolated"))
        lo = 0.0 if vmin is None else vmin
        hi = 1.0 if vmax is None or vmax <= lo else vmax
        cols = _interp_colors(spec, 5)
        for i, c in enumerate(cols):
            v = lo + (hi - lo) * i / 4.0
            items.append(core.QgsColorRampShader.ColorRampItem(v, c, "{:.3g}".format(v)))
        sh.setClip(True)
        try:
            sh.setMinimumValue(lo)
            sh.setMaximumValue(hi)
        except AttributeError:
            pass
    sh.setColorRampItemList(items)
    return sh


def _band_min_max(layer):
    core = _qgis()
    try:
        flags = core.Qgis.RasterBandStatistic.All
    except AttributeError:
        flags = core.QgsRasterBandStats.All
    try:
        st = layer.dataProvider().bandStatistics(1, flags)
        return st.minimumValue, st.maximumValue
    except Exception:
        return None, None


def style_raster(layer, dtype, cutoff=None, opacity=1.0):
    core = _qgis()
    vmin, vmax = _band_min_max(layer)
    shader = make_shader(dtype, vmin, vmax, cutoff)
    rs = core.QgsRasterShader()
    rs.setRasterShaderFunction(shader)
    renderer = core.QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, rs)
    try:
        renderer.setClassificationMin(vmin if vmin is not None else 0)
        renderer.setClassificationMax(vmax if vmax is not None else 1)
    except Exception:
        pass
    renderer.setOpacity(opacity)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


def style_mesh(layer, cutoff=None, opacity=1.0):
    """Colour every scalar dataset group by its name; show maximum depth (or depth) first."""
    core = _qgis()
    try:
        settings = layer.rendererSettings()
        active, best = None, -1
        for i in layer.datasetGroupsIndexes():
            meta = layer.datasetGroupMetadata(core.QgsMeshDatasetIndex(i))
            name = meta.name().lower()
            dtype = next((d for k, d in MESH_KEYWORDS if k in name), "other")
            ss = settings.scalarSettings(i)
            ss.setColorRampShader(make_shader(dtype, meta.minimum(), meta.maximum(), cutoff))
            ss.setClassificationMinimumMaximum(meta.minimum(), meta.maximum())
            ss.setOpacity(opacity)
            settings.setScalarSettings(i, ss)
            score = (2 if "depth" in name else 1 if "water level" in name else 0) + (1 if "max" in name else 0)
            if score > best:
                best, active = score, i
        if active is not None:
            settings.setActiveScalarDatasetGroup(active)
        layer.setRendererSettings(settings)
        layer.triggerRepaint()
    except Exception:
        pass


# ---------------------------------------------------------------------------
def tuflow_style_dir():
    """QGIS_Styles folder of the official TUFLOW plugin if it is installed."""
    try:
        import qgis.utils as qu
        bases = list(getattr(qu, "plugin_paths", []) or []) + [getattr(qu, "home_plugin_path", "")]
    except Exception:
        bases = []
    for b in bases:
        p = os.path.join(b or "", "tuflow", "QGIS_Styles")
        if b and os.path.isdir(p):
            return p
    return ""


def tuflow_qml_for(name, style_dir=None):
    style_dir = style_dir if style_dir is not None else tuflow_style_dir()
    if not style_dir:
        return ""
    qmls = sorted(glob.glob(os.path.join(style_dir, "*.qml")) + glob.glob(os.path.join(style_dir, "*.QML")),
                  key=lambda s: -len(os.path.basename(s)))
    low = name.lower()
    for q in qmls:
        stem = os.path.splitext(os.path.basename(q))[0].lower()
        if stem and stem in low:
            return q
    return ""


def style_vector(layer, key, use_tuflow=True, opacity=1.0):
    """Apply the TUFLOW plugin style if available, otherwise a simple FMB style."""
    if use_tuflow:
        qml = tuflow_qml_for(layer.name())
        if qml:
            try:
                layer.loadNamedStyle(qml)
                layer.triggerRepaint()
                return "tuflow"
            except Exception:
                pass
    try:
        sym = layer.renderer().symbol()
        colours = {"PLOT_P": "#d7191c", "PLOT_L": "#2b83ba", "1d_mmH_P": "#1f78b4", "1d_mmQ_P": "#33a02c",
                   "1d_mmV_P": "#ff7f00", "1d_ccA_L": "#6a3d9a", "messages": "#e31a1c"}
        if key in colours:
            sym.setColor(QColor(colours[key]))
        sym.setOpacity(opacity)
        layer.triggerRepaint()
    except Exception:
        pass
    return "fmb"
