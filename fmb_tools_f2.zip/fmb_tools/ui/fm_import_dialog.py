# -*- coding: utf-8 -*-
"""Wizard: import a Flood Modeller (Jacobs) model and write a TUFLOW model from it."""
import os
import re

from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal, QSettings
from qgis.PyQt.QtGui import QColor, QBrush
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout, QLabel, QLineEdit,
                                 QCheckBox, QPushButton, QTreeWidget, QTreeWidgetItem, QStackedWidget, QWidget,
                                 QGroupBox, QRadioButton, QButtonGroup, QScrollArea, QFrame, QHeaderView, QTextBrowser,
                                 QApplication, QMessageBox, QSizePolicy)

from ..core import floodmodeller as fm
from ..core import fm_import as fi
from . import qgis_utils as qu
from .theme import STATE_COLORS
from .widgets import PathEdit, RadioChoice, NumberSpin

LEVEL_STYLE = {"todo": ("You need to finish these", STATE_COLORS["error"]),
               "review": ("Check these", STATE_COLORS["warn"]),
               "done": ("Converted", STATE_COLORS["done"]),
               "info": ("Notes", "#1f6fd1")}
FM_FILTER = "Flood Modeller (*.ief *.IEF *.dat *.DAT *.ied *.IED *.xml *.XML);;All files (*)"


def _muted(text):
    l = QLabel(text)
    l.setObjectName("Muted")
    l.setWordWrap(True)
    return l


class _Choice(QFrame):
    """A radio button with a title and a one-line explanation under it."""

    def __init__(self, title, text, group, value):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 2, 4, 4)
        lay.setSpacing(0)
        self.rb = QRadioButton(title)
        f = self.rb.font()
        f.setBold(True)
        self.rb.setFont(f)
        self.rb.setProperty("value", value)
        group.addButton(self.rb)
        lay.addWidget(self.rb)
        t = _muted(text)
        t.setContentsMargins(22, 0, 0, 0)
        lay.addWidget(t)


class FmImportDialog(QDialog):
    """Pick a Flood Modeller .ief / .dat / .xml, choose how to convert, write the TUFLOW model and
    show the import report. Emits imported(tcf_path) when a model was written."""
    imported = pyqtSignal(str)

    def __init__(self, parent=None, root="", source=""):
        super().__init__(parent)
        self.setObjectName("FmbMain")                 # picks up the plugin theme
        self.setWindowTitle("Import a Flood Modeller model")
        self.resize(1180, 800)
        self.fmp = None
        self.result = None
        self._root_auto = True
        self._name_auto = True
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 12)
        head = QLabel("Import a Flood Modeller model")
        head.setObjectName("PageTitle")
        lay.addWidget(head)
        lay.addWidget(_muted("Reads a Jacobs Flood Modeller model - the event file (.ief), 1D network (.dat), event "
                             "data (.ied) and 2D model (.xml) - and writes a TUFLOW model from it: control files, "
                             "GIS layers, cross-section tables, boundary database and materials. Anything that "
                             "cannot be converted exactly is listed in an import report."))
        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        self.stack.addWidget(self._setup_page())
        self.stack.addWidget(self._result_page())
        # buttons
        bar = QHBoxLayout()
        self.status = QLabel("")
        self.status.setObjectName("Muted")
        bar.addWidget(self.status, 1)
        self.back_btn = QPushButton("← Back")
        self.back_btn.clicked.connect(lambda: self._page(0))
        self.close_btn = QPushButton("Cancel")
        self.close_btn.clicked.connect(self.reject)
        self.go_btn = QPushButton("Create TUFLOW model")
        self.go_btn.setProperty("primary", True)
        self.go_btn.clicked.connect(self.run_import)
        for b in (self.back_btn, self.close_btn, self.go_btn):
            bar.addWidget(b)
        lay.addLayout(bar)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(350)
        self._timer.timeout.connect(self.read_source)
        self.root.setValue(root or "")
        self._root_auto = not bool(root)
        self._page(0)
        last = QSettings().value("fmb_tools/fm_import_last", "")
        if source or last:
            self.source.setValue(source or "")
            if not source:
                self.source.line.setPlaceholderText("last: " + str(last))
        self._update_enabled()

    # ------------------------------------------------------------------ pages
    def _setup_page(self):
        page = QWidget()
        h = QHBoxLayout(page)
        h.setContentsMargins(0, 8, 0, 0)
        h.setSpacing(14)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        host = QWidget()
        col = QVBoxLayout(host)
        col.setContentsMargins(0, 0, 6, 0)
        scroll.setWidget(host)
        h.addWidget(scroll, 3)

        # 1. source
        g = QGroupBox("1. Flood Modeller model")
        gl = QVBoxLayout(g)
        self.source = PathEdit("file", FM_FILTER, lambda: "")
        self.source.line.setPlaceholderText("event file (.ief), 1D network (.dat / .ied) or 2D model (.xml)")
        self.source.changed.connect(lambda _t: self._timer.start())
        gl.addWidget(self.source)
        gl.addWidget(_muted("Best: the event file (.ief). It brings the 1D network, the boundaries of that event, the "
                            "run times and the linked 2D model. A .dat gives the 1D network only; a 2D .xml gives the "
                            "2D model and follows its link to the 1D."))
        col.addWidget(g)

        # 2. target
        g = QGroupBox("2. New TUFLOW model")
        form = QFormLayout(g)
        self.root = PathEdit("folder", "", lambda: "")
        self.root.line.setPlaceholderText("model root folder - runs, model, bc_dbase ... are created inside it")
        self.root.changed.connect(self._root_edited)
        form.addRow("Root folder", self.root)
        self.name = QLineEdit()
        self.name.setPlaceholderText("model name (TCF file name)")
        self.name.textEdited.connect(self._name_edited)
        form.addRow("Model name", self.name)
        self.solver = RadioChoice(["HPC", "CLASSIC"], "HPC")
        self.solver.setValue("HPC")
        self.solver.changed.connect(lambda v: self.hardware.setEnabled(v == "HPC"))
        form.addRow("Solver", self.solver)
        self.hardware = RadioChoice(["GPU", "CPU"], "CPU")
        self.hardware.setValue("GPU")
        form.addRow("Hardware", self.hardware)
        self.gisfmt = RadioChoice(["GPKG", "SHP"], "")
        self.gisfmt.setValue("GPKG")
        form.addRow("GIS format", self.gisfmt)
        self.crs = None
        try:
            from qgis.gui import QgsProjectionSelectionWidget
            self.crs = QgsProjectionSelectionWidget()
            from qgis.core import QgsProject
            self.crs.setCrs(QgsProject.instance().crs())
            form.addRow("Projection", self.crs)
        except Exception:
            pass
        col.addWidget(g)

        # 3. 1D
        g = QGroupBox("3. 1D river network")
        gl = QVBoxLayout(g)
        self.mode_group = QButtonGroup(self)
        self.c_estry = _Choice("Convert to TUFLOW 1D (ESTRY)",
                               "River sections become 'S' channels with XZ cross-section tables (Manning's n per "
                               "point), conduits become culverts, spills / weirs / sluices become weirs, junctions "
                               "become shared nodes and QT / HT / QH boundaries go to 1d_bc + bc_dbase.",
                               self.mode_group, "estry")
        self.c_linked = _Choice("Keep Flood Modeller for the 1D (linked model)",
                                "Flood Modeller keeps solving the river; TUFLOW solves the 2D. Writes the X1D node "
                                "layer, HX / CN links and a copy of the event file that points at the new TCF - run "
                                "that event file in Flood Modeller.", self.mode_group, "linked")
        self.c_estry.rb.setChecked(True)
        gl.addWidget(self.c_estry)
        gl.addWidget(self.c_linked)
        self.mode_group.buttonClicked.connect(lambda _b: self._refresh_plan())
        col.addWidget(g)

        # 4. 2D
        g = QGroupBox("4. 2D floodplain")
        grid = QGridLayout(g)
        self.make_2d = QCheckBox("Build a 2D domain around the river")
        self.make_2d.setChecked(True)
        self.make_2d.toggled.connect(lambda _on: self._update_enabled())
        grid.addWidget(self.make_2d, 0, 0, 1, 4)
        self.from_xml = _muted("")
        grid.addWidget(self.from_xml, 1, 0, 1, 4)
        grid.addWidget(QLabel("Cell size"), 2, 0)
        self.cell = NumberSpin("m", False, 0.1, 1000, 1.0, None)
        self.cell.setValue(10)
        grid.addWidget(self.cell, 2, 1)
        grid.addWidget(QLabel("Margin around the river"), 2, 2)
        self.margin = NumberSpin("m", False, 0, 100000, 50, None)
        self.margin.setValue(200)
        grid.addWidget(self.margin, 2, 3)
        grid.addWidget(QLabel("DTM"), 3, 0)
        self.dem = PathEdit("grid", "Grids (*.tif *.tiff *.asc *.flt *.vrt);;All files (*)", lambda: "")
        self.dem.line.setPlaceholderText("optional - replaces the Flood Modeller topography (Read Grid Zpts)")
        grid.addWidget(self.dem, 3, 1, 1, 3)
        self.banks = QCheckBox("Link 1D and 2D along both banks")
        self.banks.setToolTip("HX lines through the section ends (or the LEFT / RIGHT bank markers) with CN lines to "
                              "each node - used when the Flood Modeller model has no 1D-2D link file")
        self.banks.setChecked(True)
        grid.addWidget(self.banks, 4, 0, 1, 4)
        self.copy_grids = QCheckBox("Copy the DTM grids into model\\grid")
        self.copy_grids.setToolTip("Keeps the TUFLOW model self-contained")
        self.copy_grids.setChecked(True)
        grid.addWidget(self.copy_grids, 5, 0, 1, 4)
        self.sgs = QCheckBox("Sub-grid sampling (SGS)")
        self.sgs.setToolTip("Off keeps the Flood Modeller cell-centre topography; on samples the DTM inside each cell")
        grid.addWidget(self.sgs, 6, 0, 1, 4)
        self.load_cb = QCheckBox("Load the new layers into the map")
        self.load_cb.setChecked(True)
        grid.addWidget(self.load_cb, 7, 0, 1, 4)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        col.addWidget(g)
        col.addStretch(1)

        # preview
        right = QFrame()
        right.setObjectName("Card")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(14, 12, 14, 12)
        t = QLabel("What was found")
        t.setObjectName("CardTitle")
        rl.addWidget(t)
        self.found = QLabel("")
        self.found.setWordWrap(True)
        self.found.setTextFormat(Qt.TextFormat.RichText)
        self.found.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.found.setMinimumWidth(330)
        self._found = []
        rl.addWidget(self.found)
        rl.addSpacing(10)
        t = QLabel("Will be created")
        t.setObjectName("CardTitle")
        rl.addWidget(t)
        self.plan = QLabel("")
        self.plan.setWordWrap(True)
        self.plan.setTextFormat(Qt.TextFormat.RichText)
        self.plan.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        rl.addWidget(self.plan)
        rl.addStretch(1)
        h.addWidget(right, 2)
        return page

    def _result_page(self):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 8, 0, 0)
        self.res_title = QLabel("")
        self.res_title.setObjectName("CardTitle")
        self.res_title.setStyleSheet("font-size: 12pt; font-weight: 700;")
        v.addWidget(self.res_title)
        self.res_path = _muted("")
        self.res_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        v.addWidget(self.res_path)
        chips = QHBoxLayout()
        self.chips = {}
        for lv in ("todo", "review", "done", "info"):
            c = QLabel("")
            c.setStyleSheet("border-radius: 9px; padding: 2px 10px; font-weight: 600; color: white; "
                            "background: {};".format(LEVEL_STYLE[lv][1]))
            chips.addWidget(c)
            self.chips[lv] = c
        chips.addStretch(1)
        v.addLayout(chips)
        self.report = QTextBrowser()
        self.report.setOpenExternalLinks(False)
        v.addWidget(self.report, 1)
        row = QHBoxLayout()
        b = QPushButton("Open report file")
        b.clicked.connect(lambda: self.result and qu.open_path(self.result.report_path))
        row.addWidget(b)
        b = QPushButton("Open model folder")
        b.clicked.connect(lambda: self.result and qu.open_path(os.path.dirname(os.path.dirname(self.result.tcf))))
        row.addWidget(b)
        self.ief_btn = QPushButton("Show the linked event file")
        self.ief_btn.clicked.connect(lambda: self.result and qu.open_path(os.path.dirname(self.result.ief)))
        row.addWidget(self.ief_btn)
        row.addStretch(1)
        v.addLayout(row)
        return page

    def _page(self, i):
        self.stack.setCurrentIndex(i)
        self.back_btn.setVisible(i == 1)
        self.go_btn.setVisible(i == 0)
        self.close_btn.setText("Close" if i == 1 else "Cancel")

    # ------------------------------------------------------------------ source
    def _root_edited(self, _t):
        if self.root.hasFocus() or self.root.line.hasFocus():
            self._root_auto = False

    def _name_edited(self, _t):
        self._name_auto = False

    def read_source(self):
        path = self.source.value().strip().strip('"')
        self._found = []
        self.found.setText("")
        self.fmp = None
        if not path:
            self._refresh_plan()
            return
        if not os.path.isfile(path):
            self._found_row("File not found", STATE_COLORS["error"])
            self._refresh_plan()
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self.fmp = fm.read_project(path)
        except Exception as ex:
            self._found_row("Could not read the file: {}".format(ex), STATE_COLORS["error"])
            self.fmp = None
        finally:
            QApplication.restoreOverrideCursor()
        if self.fmp is not None:
            for line in self.fmp.summary():
                self._found_row(line, STATE_COLORS["done"])
            for n in self.fmp.notes:
                self._found_row(n, STATE_COLORS["warn"])
            if self.fmp.dat is None and self.fmp.xml is None:
                self._found_row("No 1D network or 2D model found", STATE_COLORS["error"])
            base = os.path.dirname(path)
            name = re.sub(r"[^\w\-]+", "_", self.fmp.name).strip("_") or "FM_import"
            if self._name_auto:
                self.name.setText(name)
            if self._root_auto:
                self.root.setValue(os.path.join(base, "TUFLOW_" + name))
            d2 = self.fmp.xml.domains[0] if self.fmp.xml is not None and self.fmp.xml.domains else None
            if d2 is not None and d2.dx:
                self.cell.setValue(d2.dx)
            self._crs_from_source()
        self._update_enabled()
        self._refresh_plan()

    def _found_row(self, text, color):
        from html import escape
        self._found.append('<tr><td style="color:{0}; padding-right:6px;">●</td><td>{1}</td></tr>'.format(
            color, escape(text)))
        self.found.setText('<table cellspacing="0" cellpadding="2">{}</table>'.format("".join(self._found)))

    def _crs_from_source(self):
        if self.crs is None or self.fmp is None or self.fmp.xml is None:
            return
        try:
            from qgis.core import QgsCoordinateReferenceSystem
            d2 = self.fmp.xml.domains[0] if self.fmp.xml.domains else None
            for p in ([d2.active_area] if d2 else []) + list(self.fmp.xml.link_files):
                wkt = fi._prj_wkt(p) if p else ""
                if wkt:
                    crs = QgsCoordinateReferenceSystem.fromWkt(wkt)
                    if crs.isValid():
                        self.crs.setCrs(crs)
                        return
        except Exception:
            pass

    def _update_enabled(self):
        has_xml = self.fmp is not None and self.fmp.xml is not None and bool(self.fmp.xml.domains)
        has_dat = self.fmp is not None and self.fmp.dat is not None
        linked = self.mode() == "linked"
        self.make_2d.setEnabled(not has_xml)
        if has_xml:
            self.make_2d.setChecked(True)
            d2 = self.fmp.xml.domains[0]
            self.from_xml.setText("From the Flood Modeller 2D model '{}': {} x {} cells of {} m, origin {}, {}.".format(
                d2.name, d2.ncols, d2.nrows, fi.fmt(d2.dx or 0), fi.fmt(d2.xll or 0), fi.fmt(d2.yll or 0)))
        else:
            self.from_xml.setText("No 2D model in the Flood Modeller files - a grid is made around the river with the "
                                  "margin below. Pick a DTM for the ground levels.")
        on = self.make_2d.isChecked()
        self.margin.setEnabled(on and not has_xml)
        for w in (self.cell, self.dem, self.copy_grids, self.sgs):
            w.setEnabled(on)
        self.banks.setEnabled(on and has_dat)
        self.c_linked.setEnabled(has_dat or self.fmp is None)
        self.c_estry.setEnabled(has_dat or self.fmp is None)
        self.go_btn.setEnabled(self.fmp is not None and (has_dat or has_xml))

    def mode(self):
        b = self.mode_group.checkedButton()
        return b.property("value") if b is not None else "estry"

    def options(self):
        crs_wkt = None
        if self.crs is not None:
            try:
                c = self.crs.crs()
                crs_wkt = c.toWkt() if c.isValid() else None
            except Exception:
                crs_wkt = None
        return {"root": self.root.value().strip(), "name": self.name.text().strip(), "mode": self.mode(),
                "make_2d": self.make_2d.isChecked(), "solver": self.solver.value() or "HPC",
                "hardware": self.hardware.value() or "GPU", "sgs": self.sgs.isChecked(),
                "gis_format": self.gisfmt.value() or "GPKG",
                "cell_size": self.cell.value() if self.cell.is_set() else None,
                "dem": self.dem.value().strip(), "margin": self.margin.value() if self.margin.is_set() else 0.0,
                "banks": self.banks.isChecked(),
                "copy_grids": self.copy_grids.isChecked(), "crs_wkt": crs_wkt}

    def _refresh_plan(self):
        from html import escape
        if self.fmp is None:
            self.plan.setText('<span style="color:gray;">Pick a Flood Modeller file to see what will be created.</span>')
            return
        try:
            rows = fi.plan(self.fmp, self.options())
        except Exception as ex:
            rows = [("Error", str(ex))]
        o = self.options()
        rows = [("Model", "{}  ({}, {})".format(o["name"] or "-", o["solver"], o["gis_format"])),
                ("1D engine", "TUFLOW ESTRY (converted)" if o["mode"] == "estry" else
                 "Flood Modeller (linked, new .ief)")] + rows
        self.plan.setText('<table cellspacing="0" cellpadding="3">{}</table>'.format("".join(
            '<tr><td style="font-weight:600; padding-right:10px; white-space:nowrap;">{}</td><td>{}</td></tr>'.format(
                escape(k), escape(v)) for k, v in rows)))

    # ------------------------------------------------------------------ run
    def run_import(self):
        if self.fmp is None:
            return
        o = self.options()
        if not o["root"]:
            QMessageBox.warning(self, "Import", "Choose the root folder of the new TUFLOW model.")
            return
        tcf = os.path.join(o["root"], "runs", (o["name"] or self.fmp.name) + ".tcf")
        if os.path.exists(tcf) and QMessageBox.question(
                self, "Import", "{} already exists. Overwrite the model files?".format(tcf)) \
                != QMessageBox.StandardButton.Yes:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.go_btn.setEnabled(False)

        def step(text):
            self.status.setText(text + "...")
            QApplication.processEvents()

        try:
            self.result = fi.convert(self.fmp, o, progress=step)
        except Exception as ex:
            QApplication.restoreOverrideCursor()
            self.go_btn.setEnabled(True)
            self.status.setText("")
            import traceback
            QMessageBox.critical(self, "Import", "The import failed:\n{}\n\n{}".format(ex, traceback.format_exc()[-1500:]))
            return
        QApplication.restoreOverrideCursor()
        self.go_btn.setEnabled(True)
        self.status.setText("")
        QSettings().setValue("fmb_tools/fm_import_last", self.fmp.source)
        self._show_result()
        self.imported.emit(self.result.tcf)

    def _show_result(self):
        r = self.result
        rep = r.report
        self.res_title.setText("TUFLOW model created - {}".format(os.path.splitext(os.path.basename(r.tcf))[0]))
        self.res_path.setText("{}\nReport: {}".format(r.tcf, r.report_path))
        for lv, chip in self.chips.items():
            n = rep.count(lv)
            chip.setText("{} {}".format(n, LEVEL_STYLE[lv][0].lower()))
            chip.setVisible(n > 0)
        from html import escape
        parts = []
        for lv in ("todo", "review", "done", "info"):
            rows = rep.of(lv)
            if not rows:
                continue
            title, color = LEVEL_STYLE[lv]
            parts.append('<h4 style="color:{}; margin:10px 0 4px 0;">{} ({})</h4>'.format(color, title, len(rows)))
            parts.append('<table cellspacing="0" cellpadding="3" width="100%">')
            for _l, area, text in rows:
                parts.append('<tr><td width="140" style="color:{}; padding-right:12px; vertical-align:top;">'
                             '{}</td><td>{}</td></tr>'.format(color, escape(area), escape(text)))
            parts.append("</table>")
        self.report.setHtml("".join(parts))
        self.ief_btn.setVisible(bool(r.ief))
        self._page(1)
