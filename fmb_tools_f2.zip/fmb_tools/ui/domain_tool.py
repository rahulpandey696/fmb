# -*- coding: utf-8 -*-
"""
Map tools to define the 2D domain on the QGIS canvas, and a persistent preview.

DomainDrawTool modes
    'polygon'  click the corners of the area to model, right-click / double-click / Enter to
               finish -> the smallest (optionally rotated) grid rectangle around it
    'rect3'    3 clicks: origin corner, a point along the grid X axis, then the Y extent
    'rect2'    2 clicks (or drag): an unrotated rectangle
Common keys: Esc cancels, Backspace removes the last point, Shift constrains the X axis to
15 degree steps (rect3) or draws a square (rect2). Points snap to the QGIS snapping settings.

DomainPreview draws the domain outline, the origin, the X-axis arrow and (when not too many)
the cell grid, plus the drawn area, and stays until cleared.
"""
import math

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsPointXY, QgsGeometry, QgsCoordinateTransform, QgsProject, QgsRectangle
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker

from ..core import domain as D

BLUE = QColor(31, 120, 214)
ORANGE = QColor(230, 120, 20)
RED = QColor(205, 40, 40)
MAX_GRID_LINES = 800


def _gtype(kind):
    try:
        from qgis.core import Qgis
        return getattr(Qgis.GeometryType, kind)
    except AttributeError:
        from qgis.core import QgsWkbTypes
        return getattr(QgsWkbTypes, kind + "Geometry")


def _band(canvas, kind, color, fill_alpha=0, width=2, dash=False):
    b = QgsRubberBand(canvas, _gtype(kind))
    b.setStrokeColor(color)
    fill = QColor(color)
    fill.setAlpha(fill_alpha)
    b.setFillColor(fill)
    b.setWidth(width)
    if dash:
        b.setLineStyle(Qt.PenStyle.DashLine)
    return b


def _xy(p):
    return (p.x(), p.y())


def _qp(t):
    return QgsPointXY(t[0], t[1])


def polygon_geom(points):
    return QgsGeometry.fromPolygonXY([[_qp(p) for p in list(points) + [points[0]]]])


# ---------------------------------------------------------------------------
class DomainDrawTool(QgsMapTool):
    finished = pyqtSignal(str, list)      # mode, [(x, y), ...]
    cancelled = pyqtSignal()
    status = pyqtSignal(str)

    HELP = {
        "polygon": "Click the corners of the area to model. Right-click, double-click or Enter to finish; "
                   "Backspace removes the last point; Esc cancels.",
        "rect3": "Click 1: grid origin corner.  Click 2: a point along the grid X axis.  Click 3: the far side "
                 "(sets the Y size).  Shift = 15 deg steps, Esc cancels.",
        "rect2": "Click two opposite corners (or drag). Shift = square, Esc cancels.",
    }

    def __init__(self, canvas, mode="polygon"):
        super().__init__(canvas)
        self.mode = mode
        self.points = []
        self._press = None
        self.band = _band(canvas, "Polygon", ORANGE if mode == "polygon" else BLUE, 50, 2)
        self.line = _band(canvas, "Line", RED, 0, 2, dash=True)
        self.setCursor(Qt.CursorShape.CrossCursor)

    # -- helpers ---------------------------------------------------------------
    def _point(self, e):
        try:
            m = self.canvas().snappingUtils().snapToMap(e.pos())
            if m.isValid():
                return _xy(m.point())
        except Exception:
            pass
        return _xy(self.toMapCoordinates(e.pos()))

    @staticmethod
    def _shift(e):
        return bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)

    def _constrain(self, p, e):
        """Shift: X axis in 15 deg steps (rect3, 2nd point) or a square (rect2)."""
        if not self._shift(e) or not self.points:
            return p
        a = self.points[0]
        dx, dy = p[0] - a[0], p[1] - a[1]
        if self.mode == "rect3" and len(self.points) == 1:
            ang = round(math.degrees(math.atan2(dy, dx)) / 15.0) * 15.0
            r = math.hypot(dx, dy)
            return (a[0] + r * math.cos(math.radians(ang)), a[1] + r * math.sin(math.radians(ang)))
        if self.mode == "rect2":
            s = max(abs(dx), abs(dy))
            return (a[0] + math.copysign(s, dx or 1), a[1] + math.copysign(s, dy or 1))
        return p

    def _show(self, pts, closed=True):
        if len(pts) >= 3 and closed:
            self.band.setToGeometry(polygon_geom(pts), None)
        else:
            self.band.reset(_gtype("Polygon"))
        if len(pts) >= 2 and (not closed or len(pts) < 3):
            self.line.setToGeometry(QgsGeometry.fromPolylineXY([_qp(p) for p in pts]), None)
        else:
            self.line.reset(_gtype("Line"))

    def _preview(self, cur):
        pts = self.points + [cur]
        try:
            if self.mode == "polygon":
                self._show(pts)
                if len(self.points) >= 2:
                    area = D.polygon_area(pts)
                    self.status.emit("{} points | area {:,.0f} m2 - right-click to finish".format(len(pts), area))
            elif self.mode == "rect2" and len(self.points) == 1:
                d = D.from_box(pts[0][0], pts[0][1], cur[0], cur[1])
                self._show(d.corners())
                self.status.emit("{:,.1f} x {:,.1f} m".format(d.width, d.height))
            elif self.mode == "rect3" and len(self.points) == 1:
                self._show(pts, closed=False)
                ang = math.degrees(math.atan2(cur[1] - pts[0][1], cur[0] - pts[0][0]))
                self.status.emit("X axis {:,.1f} m at {:.2f} deg from east - click to fix it".format(
                    math.hypot(cur[0] - pts[0][0], cur[1] - pts[0][1]), ang))
            elif self.mode == "rect3" and len(self.points) == 2:
                d = D.from_points(self.points[0], self.points[1], cur)
                self._show(d.corners())
                self.line.setToGeometry(QgsGeometry.fromPolylineXY([_qp(self.points[0]), _qp(self.points[1])]), None)
                self.status.emit("{:,.1f} x {:,.1f} m, X axis {:.2f} deg - click to finish".format(
                    d.width, d.height, d.angle))
        except ValueError:
            pass

    # -- events ------------------------------------------------------------------
    def canvasMoveEvent(self, e):
        if self.points:
            self._preview(self._constrain(self._point(e), e))

    def canvasPressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = self._point(e)

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.RightButton:
            if self.mode == "polygon" and len(self.points) >= 3:
                self._finish()
            else:
                self.cancel()
            return
        if e.button() != Qt.MouseButton.LeftButton:
            return
        p = self._constrain(self._point(e), e)
        # rect2 drag: press and release far apart
        if self.mode == "rect2" and not self.points and self._press is not None:
            dx = abs(p[0] - self._press[0]) / max(self.canvas().mapUnitsPerPixel(), 1e-12)
            dy = abs(p[1] - self._press[1]) / max(self.canvas().mapUnitsPerPixel(), 1e-12)
            if dx > 6 and dy > 6:
                self.points = [self._press, p]
                self._finish()
                return
        if self.points and math.hypot(p[0] - self.points[-1][0], p[1] - self.points[-1][1]) < 1e-9:
            return                                  # double-click duplicate
        self.points.append(p)
        if (self.mode == "rect2" and len(self.points) == 2) or (self.mode == "rect3" and len(self.points) == 3):
            self._finish()

    def canvasDoubleClickEvent(self, e):
        if self.mode == "polygon" and len(self.points) >= 3:
            self._finish()

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key.Key_Escape:
            self.cancel()
        elif k in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete) and self.points:
            self.points.pop()
            self._show(self.points, closed=self.mode != "rect3")
        elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.mode == "polygon" and len(self.points) >= 3:
            self._finish()
        else:
            e.ignore()

    def _finish(self):
        pts = list(self.points)
        self._clear()
        try:
            if self.mode == "rect3":
                D.from_points(*pts[:3])
            elif self.mode == "rect2":
                D.from_box(pts[0][0], pts[0][1], pts[1][0], pts[1][1])
            else:
                D.from_polygon(pts)
        except (ValueError, IndexError) as ex:
            self.status.emit("Not a valid domain ({}) - try again.".format(ex))
            return
        self.finished.emit(self.mode, pts)

    def cancel(self):
        self._clear()
        self.cancelled.emit()

    def _clear(self):
        self.points = []
        self._press = None
        self.band.reset(_gtype("Polygon"))
        self.line.reset(_gtype("Line"))

    def deactivate(self):
        self._clear()
        super().deactivate()

    def remove_bands(self):
        for b in (self.band, self.line):
            try:
                self.canvas().scene().removeItem(b)
            except Exception:
                pass


# ---------------------------------------------------------------------------
class DomainPreview(object):
    """Domain outline + origin + X axis + cell grid + drawn area on the canvas."""

    def __init__(self, canvas):
        self.canvas = canvas
        self.outline = _band(canvas, "Polygon", BLUE, 35, 2)
        self.grid = _band(canvas, "Line", QColor(31, 120, 214, 110), 0, 1)
        self.axis = _band(canvas, "Line", RED, 0, 3)
        self.area = _band(canvas, "Polygon", ORANGE, 25, 2, dash=True)
        self.origin = QgsVertexMarker(canvas)
        self.origin.setColor(RED)
        self.origin.setIconSize(14)
        self.origin.setPenWidth(3)
        try:
            self.origin.setIconType(QgsVertexMarker.IconType.ICON_CIRCLE)
        except AttributeError:
            self.origin.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self.origin.hide()

    def show(self, dom, cell=None, show_cells=True, area=None):
        self.clear()
        if dom is None:
            return
        c = dom.corners()
        self.outline.setToGeometry(polygon_geom(c), None)
        # X-axis arrow along the bottom edge with a head
        ux, uy = dom.u
        L = min(dom.width, dom.height) * 0.25 or dom.width * 0.25
        tip = (dom.ox + ux * L, dom.oy + uy * L)
        h = L * 0.25
        left = (tip[0] - ux * h - uy * h * 0.6, tip[1] - uy * h + ux * h * 0.6)
        right = (tip[0] - ux * h + uy * h * 0.6, tip[1] - uy * h - ux * h * 0.6)
        self.axis.setToGeometry(QgsGeometry.fromMultiPolylineXY(
            [[_qp((dom.ox, dom.oy)), _qp(tip)], [_qp(left), _qp(tip), _qp(right)]]), None)
        self.origin.setCenter(_qp((dom.ox, dom.oy)))
        self.origin.show()
        if show_cells and cell and cell > 0:
            nx, ny = dom.cells(cell)
            if 0 < nx + ny <= MAX_GRID_LINES:
                (vx, vy) = dom.n
                lines = []
                for i in range(1, nx):
                    a = (dom.ox + ux * i * cell, dom.oy + uy * i * cell)
                    lines.append([_qp(a), _qp((a[0] + vx * dom.height, a[1] + vy * dom.height))])
                for j in range(1, ny):
                    a = (dom.ox + vx * j * cell, dom.oy + vy * j * cell)
                    lines.append([_qp(a), _qp((a[0] + ux * dom.width, a[1] + uy * dom.width))])
                if lines:
                    self.grid.setToGeometry(QgsGeometry.fromMultiPolylineXY(lines), None)
        if area and len(area) >= 3:
            self.area.setToGeometry(polygon_geom(area), None)

    def clear(self):
        for b, kind in ((self.outline, "Polygon"), (self.grid, "Line"), (self.axis, "Line"), (self.area, "Polygon")):
            b.reset(_gtype(kind))
        self.origin.hide()

    def remove(self):
        self.clear()
        for item in (self.outline, self.grid, self.axis, self.area, self.origin):
            try:
                self.canvas.scene().removeItem(item)
            except Exception:
                pass

    def zoom(self, dom, pad=0.08):
        xs = [p[0] for p in dom.corners()]
        ys = [p[1] for p in dom.corners()]
        dx, dy = (max(xs) - min(xs)) * pad, (max(ys) - min(ys)) * pad
        self.canvas.setExtent(QgsRectangle(min(xs) - dx, min(ys) - dy, max(xs) + dx, max(ys) + dy))
        self.canvas.refresh()


# ---------------------------------------------------------------------------
def view_corners(canvas):
    """The 4 corners of the visible map (respects map rotation)."""
    poly = canvas.mapSettings().visiblePolygon()
    pts = [(poly[i].x(), poly[i].y()) for i in range(poly.size())]
    if len(pts) >= 5 and pts[0] == pts[-1]:
        pts = pts[:-1]
    return pts[:4]


def layer_points(layer, canvas_crs, selected_only=True, max_vertices=300000):
    """Vertices of a vector layer (selected features if any) or the 4 corners of a raster,
    in the canvas CRS. Returns (points, note)."""
    tr = None
    try:
        if layer.crs().isValid() and canvas_crs.isValid() and layer.crs() != canvas_crs:
            tr = QgsCoordinateTransform(layer.crs(), canvas_crs, QgsProject.instance())
    except Exception:
        tr = None

    def out(p):
        if tr is not None:
            p = tr.transform(p)
        return (p.x(), p.y())

    if not hasattr(layer, "getFeatures"):                 # raster / mesh: extent corners
        e = layer.extent()
        corners = [QgsPointXY(e.xMinimum(), e.yMinimum()), QgsPointXY(e.xMaximum(), e.yMinimum()),
                   QgsPointXY(e.xMaximum(), e.yMaximum()), QgsPointXY(e.xMinimum(), e.yMaximum())]
        return [out(p) for p in corners], "raster extent"
    feats = layer.selectedFeatures() if selected_only and layer.selectedFeatureCount() else layer.getFeatures()
    note = "{} selected feature(s)".format(layer.selectedFeatureCount()) if selected_only and \
        layer.selectedFeatureCount() else "all features"
    geoms = []
    count = 0
    for f in feats:
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = g.convexHull()            # only the hull matters for the bounding rectangle
        geoms.append(g)
        count += 1
        if count > 200000:
            break
    if not geoms:
        return [], "no geometries"
    hull = QgsGeometry.collectGeometry(geoms).convexHull()
    pts = [out(QgsPointXY(v.x(), v.y())) for v in hull.vertices()]
    if len(pts) > max_vertices:
        pts = pts[::max(1, len(pts) // max_vertices)]
    return pts, note
