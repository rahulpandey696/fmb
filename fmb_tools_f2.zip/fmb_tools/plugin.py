# -*- coding: utf-8 -*-
"""QGIS plugin wrapper: menu entry, toolbar button and the main window."""
import os

from qgis.PyQt.QtCore import Qt, QObject, QEvent
from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:          # Qt6 / QGIS 4
    from qgis.PyQt.QtGui import QAction

MENU = "&FMB tools"


class _MainWindowWatcher(QObject):
    """When QGIS is closed, close the FMB tools window first (it asks to save unsaved control
    files; choosing Cancel there also keeps QGIS open)."""

    def __init__(self, plugin):
        super().__init__(plugin.iface.mainWindow())
        self.plugin = plugin

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.Close and self.plugin.dialog is not None and self.plugin.dialog.isVisible():
            if not self.plugin.dialog.close():
                ev.ignore()
                return True
        return False


class FmbToolsPlugin(object):
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.actions = []
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):  # noqa: N802
        icon = QIcon(os.path.join(self.plugin_dir, "icon.png"))
        a = QAction(icon, "FMB tools", self.iface.mainWindow())
        a.setToolTip("Build, check and run TUFLOW models")
        a.triggered.connect(self.show)
        self.iface.addToolBarIcon(a)
        self.iface.addPluginToMenu(MENU, a)
        self.actions.append(a)
        h = QAction("Help (TUFLOW Wiki)", self.iface.mainWindow())
        h.triggered.connect(self._wiki)
        self.iface.addPluginToMenu(MENU, h)
        self.actions.append(h)
        self._watcher = _MainWindowWatcher(self)
        self.iface.mainWindow().installEventFilter(self._watcher)

    def unload(self):
        try:
            self.iface.mainWindow().removeEventFilter(self._watcher)
        except Exception:
            pass
        for a in self.actions:
            self.iface.removePluginMenu(MENU, a)
            self.iface.removeToolBarIcon(a)
        self.actions = []
        if self.dialog is not None:
            self.dialog.close()
            self.dialog.deleteLater()
            self.dialog = None

    def show(self):
        """Open the window - or bring it back if it is minimised or behind QGIS."""
        if self.dialog is None:
            from .ui.main_dialog import MainDialog
            # a top-level window (no parent) gets its own taskbar button, so minimising it never
            # makes it disappear behind QGIS
            self.dialog = MainDialog(self.iface, None)
        d = self.dialog
        d.setWindowState((d.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
        d.show()
        d.raise_()
        d.activateWindow()

    def _wiki(self):
        from .ui.qgis_utils import open_url
        open_url("https://wiki.tuflow.com/Main_Page")
