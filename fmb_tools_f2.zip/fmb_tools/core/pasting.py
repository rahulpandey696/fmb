# -*- coding: utf-8 -*-
"""
Turn clipboard text into numbers for the number boxes.

Handles what people typically copy: '312345.6', '312,345.60 m', '5,25' (decimal
comma), 'X: 312345.6 Y: 6789012.3', '312345.6, 6789012.3', 'POINT(312345.6 6789012.3)',
tab-separated cells from Excel and the unicode minus sign.
"""
import re

_NUM = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")
# 1,234,567.89 (thousands separators) - not part of a longer comma list of digits
_THOUSANDS = re.compile(r"(?<![\d.,])(\d{1,3}(?:,\d{3})+)(?![\d,]*\d)(?=\.\d+|[^\d,]|$)")
_DECIMAL_COMMA = re.compile(r"^\s*[-+]?\d+,\d+(?:\s*[^\d\s,.;]\S*)?\s*$")


def numbers_from_text(text, multi=False):
    """All numbers in `text`, in order.

    multi=False (a single number box): thousands separators are removed and a lone
    decimal comma ('5,25') becomes a point.
    multi=True (an X, Y pair ...): a comma between numbers separates values, unless the
    text also uses spaces, tabs or ';' as separators - then commas inside numbers are
    treated as thousands separators.
    """
    t = (text or "").replace("−", "-").replace(" ", " ").replace(" ", " ").strip()
    if not t:
        return []
    if multi and re.match(r"^[-+]?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:\s*[^\d\s,.;]\S*)?$", t):
        multi = False                     # one number with thousands separators, e.g. '1,250.5'
    if not multi:
        if _DECIMAL_COMMA.match(t) and not re.search(r"\d,\d{3}(?!\d)", t):
            t = t.replace(",", ".", 1)
        t = _THOUSANDS.sub(lambda m: m.group(1).replace(",", ""), t)
    elif re.search(r"[;\t]|,\s|\d\s+[-+]?\d|[A-Za-z]", t):
        t = _THOUSANDS.sub(lambda m: m.group(1).replace(",", "") if not re.search(r",\s", m.group(0))
                           else m.group(0), t)
    out = []
    for m in _NUM.finditer(t):
        try:
            out.append(float(m.group(0)))
        except ValueError:
            pass
    return out
