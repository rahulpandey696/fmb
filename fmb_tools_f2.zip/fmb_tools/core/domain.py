# -*- coding: utf-8 -*-
"""
Geometry of a 2D TUFLOW domain (pure Python, no QGIS needed).

A Domain is a rectangle given by its origin (the lower-left corner in grid
coordinates), the direction of the grid X axis (angle in degrees,
anticlockwise from east) and its length along X and Y. TUFLOW reads it as

    Origin == ox, oy                      (lower-left corner)
    Orientation == xx, yx                 (any point along the X axis)  - only if rotated
    Grid Size (X,Y) == width, height

or, more robustly, as a 2d_loc line from the origin along the X axis
(Read GIS Location) plus Grid Size (X,Y).

Ways to build one:
    from_points(p1, p2, p3)   3 clicks: origin, a point along X, a point setting the Y extent
    from_box(xmin, ymin, xmax, ymax)
    from_polygon(points, rotate=True)  minimum-area rectangle around a drawn area / layer
"""
import math

EPS = 1e-9


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


class Domain(object):
    __slots__ = ("ox", "oy", "angle", "width", "height")

    def __init__(self, ox, oy, angle, width, height):
        self.ox = float(ox)
        self.oy = float(oy)
        self.angle = normalise_angle(angle)
        self.width = float(width)
        self.height = float(height)

    # -- axes -----------------------------------------------------------------
    @property
    def u(self):
        """Unit vector of the grid X axis."""
        a = math.radians(self.angle)
        return (math.cos(a), math.sin(a))

    @property
    def n(self):
        """Unit vector of the grid Y axis (90 deg anticlockwise from X)."""
        ux, uy = self.u
        return (-uy, ux)

    @property
    def rotated(self):
        return abs(self.angle) > 1e-6

    def corners(self):
        """[lower-left (origin), lower-right, upper-right, upper-left] in map coordinates."""
        (ux, uy), (nx, ny) = self.u, self.n
        o = (self.ox, self.oy)
        w, h = self.width, self.height
        return [o, (o[0] + w * ux, o[1] + w * uy), (o[0] + w * ux + h * nx, o[1] + w * uy + h * ny),
                (o[0] + h * nx, o[1] + h * ny)]

    def orientation_point(self):
        """End of the X axis (lower-right corner) - a point for 'Orientation == xx, yx'."""
        return self.corners()[1]

    def to_local(self, p):
        d = _sub(p, (self.ox, self.oy))
        return (_dot(d, self.u), _dot(d, self.n))

    def contains(self, p, tol=1e-6):
        x, y = self.to_local(p)
        return -tol <= x <= self.width + tol and -tol <= y <= self.height + tol

    # -- adjustments ----------------------------------------------------------
    def with_margin(self, m):
        """Grow by `m` on every side."""
        if not m:
            return self.copy()
        (ux, uy), (nx, ny) = self.u, self.n
        return Domain(self.ox - m * ux - m * nx, self.oy - m * uy - m * ny, self.angle,
                      self.width + 2 * m, self.height + 2 * m)

    def snapped(self, cell, snap_origin=False):
        """Round the size up to whole cells. With snap_origin (unrotated grids only) the origin
        is also moved down/left onto a multiple of the cell size, so grids line up."""
        if not cell or cell <= 0:
            return self.copy()
        ox, oy, w, h = self.ox, self.oy, self.width, self.height
        if snap_origin and not self.rotated:
            nox = math.floor(ox / cell + EPS) * cell
            noy = math.floor(oy / cell + EPS) * cell
            w += ox - nox
            h += oy - noy
            ox, oy = nox, noy
        nx = max(1, int(math.ceil(w / cell - 1e-7)))
        ny = max(1, int(math.ceil(h / cell - 1e-7)))
        return Domain(ox, oy, self.angle, nx * cell, ny * cell)

    def cells(self, cell):
        if not cell or cell <= 0:
            return 0, 0
        return int(round(self.width / cell)), int(round(self.height / cell))

    def copy(self):
        return Domain(self.ox, self.oy, self.angle, self.width, self.height)

    # -- output -------------------------------------------------------------
    def wkt(self):
        c = self.corners()
        return "POLYGON(({}))".format(", ".join("{!r} {!r}".format(x, y) for x, y in c + [c[0]]))

    def loc_line_wkt(self):
        """2d_loc line: origin -> along the X axis (first vertex = origin)."""
        (x0, y0), (x1, y1) = (self.ox, self.oy), self.orientation_point()
        return "LINESTRING({!r} {!r}, {!r} {!r})".format(x0, y0, x1, y1)

    def tgc_values(self, digits=3):
        f = lambda v: fmt(v, digits)
        out = {"Origin": "{}, {}".format(f(self.ox), f(self.oy)),
               "Grid Size (X,Y)": "{}, {}".format(f(self.width), f(self.height))}
        if self.rotated:
            xx, yx = self.orientation_point()
            out["Orientation"] = "{}, {}".format(f(xx), f(yx))
        return out

    def summary(self, cell=None):
        s = "Origin {}, {} | X axis {} deg from east | {} x {} m".format(
            fmt(self.ox, 2), fmt(self.oy, 2), fmt(self.angle, 2), fmt(self.width, 2), fmt(self.height, 2))
        if cell:
            nx, ny = self.cells(cell)
            s += " | {} x {} = {:,} cells of {} m".format(nx, ny, nx * ny, fmt(cell))
        return s

    def __repr__(self):
        return "Domain({})".format(self.summary())

    def __eq__(self, other):
        return isinstance(other, Domain) and all(abs(getattr(self, k) - getattr(other, k)) < 1e-6
                                                  for k in self.__slots__)


def fmt(v, digits=3):
    s = "{:.{d}f}".format(float(v), d=digits).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def normalise_angle(a):
    """Angle in (-180, 180]."""
    a = math.fmod(float(a), 360.0)
    if a <= -180:
        a += 360
    elif a > 180:
        a -= 360
    return 0.0 if abs(a) < 1e-9 else a


# -----------------------------------------------------------------------------
def from_points(p1, p2, p3):
    """3 clicks: p1 = a corner (origin), p2 = a point along the X axis (sets direction and
    length), p3 = any point setting the Y extent. If p3 is on the right of p1->p2 the
    rectangle is mirrored so the origin is still the lower-left corner in grid terms."""
    d = _sub(p2, p1)
    w = math.hypot(*d)
    if w < EPS:
        raise ValueError("The first two points are the same.")
    u = (d[0] / w, d[1] / w)
    n = (-u[1], u[0])
    h = _dot(_sub(p3, p1), n)
    if abs(h) < EPS:
        raise ValueError("The third point is on the X axis line - the domain has no height.")
    ang = math.degrees(math.atan2(u[1], u[0]))
    if h > 0:
        return Domain(p1[0], p1[1], ang, w, h)
    # p3 on the right: origin moves to p1 + h*n (h negative) and Y extent is -h
    return Domain(p1[0] + h * n[0], p1[1] + h * n[1], ang, w, -h)


def from_box(xmin, ymin, xmax, ymax):
    x0, x1 = sorted((xmin, xmax))
    y0, y1 = sorted((ymin, ymax))
    if x1 - x0 < EPS or y1 - y0 < EPS:
        raise ValueError("The rectangle has no area.")
    return Domain(x0, y0, 0.0, x1 - x0, y1 - y0)


def from_corners(corners):
    """Domain from the 4 corners of any rectangle. The X axis is the edge direction closest to
    east (rotation between -45 and 45 deg); the origin is the lower-left corner in that frame."""
    pts = [tuple(map(float, c)) for c in corners[:4]]
    best = None
    for i in range(4):
        a, b = pts[i], pts[(i + 1) % 4]
        ang = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))
        for k in range(4):                     # the 4 directions of this edge pair
            t = normalise_angle(ang + 90 * k)
            if -45 < t <= 45 and (best is None or abs(t) < abs(best)):
                best = t
    return _frame_domain(pts, best or 0.0)


def _frame_domain(points, angle):
    a = math.radians(angle)
    u = (math.cos(a), math.sin(a))
    n = (-u[1], u[0])
    xs = [_dot(p, u) for p in points]
    ys = [_dot(p, n) for p in points]
    x0, y0 = min(xs), min(ys)
    ox = x0 * u[0] + y0 * n[0]
    oy = x0 * u[1] + y0 * n[1]
    return Domain(ox, oy, angle, max(xs) - x0, max(ys) - y0)


def convex_hull(points):
    pts = sorted(set((float(x), float(y)) for x, y in points))
    if len(pts) <= 2:
        return pts
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def from_polygon(points, rotate=True):
    """Smallest rectangle around a drawn area or a layer's vertices. With rotate=False the
    rectangle is aligned with the map axes (no rotation)."""
    pts = [(float(x), float(y)) for x, y in points]
    if len(pts) < 3:
        raise ValueError("Draw at least three points.")
    hull = convex_hull(pts)
    if len(hull) < 3:
        raise ValueError("The points are in a straight line.")
    if not rotate:
        return from_box(min(p[0] for p in hull), min(p[1] for p in hull),
                        max(p[0] for p in hull), max(p[1] for p in hull))
    best = None
    for i in range(len(hull)):           # the minimum-area rectangle has a side on a hull edge
        a, b = hull[i], hull[(i + 1) % len(hull)]
        if math.hypot(b[0] - a[0], b[1] - a[1]) < EPS:
            continue
        ang = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))
        ang = ((ang + 45) % 90) - 45        # the same rectangle with its X axis nearest to east
        d = _frame_domain(hull, ang)
        area = d.width * d.height
        if best is None or area < best[0] - 1e-6 or (abs(area - best[0]) <= 1e-6 and abs(ang) < abs(best[1].angle)):
            best = (area, d)
    return best[1]


def polygon_area(points):
    s = 0.0
    for i in range(len(points)):
        x0, y0 = points[i]
        x1, y1 = points[(i + 1) % len(points)]
        s += x0 * y1 - x1 * y0
    return abs(s) / 2.0
