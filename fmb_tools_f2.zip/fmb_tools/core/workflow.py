# -*- coding: utf-8 -*-
"""
Model-building progress for the dashboard and the sidebar badges.

steps(project, inputs, findings, run) -> [Step]; each step says where the model stands
(done / todo / warn / error / optional), why, and which page fixes it.
"""
import glob
import os

from .model_inputs import inputs_for

DONE, TODO, WARN, ERROR, OPTIONAL = "done", "todo", "warn", "error", "optional"
STATE_ORDER = {ERROR: 0, WARN: 1, TODO: 2, OPTIONAL: 3, DONE: 4}


# the control-file command that finishes each step (the dashboard jumps straight to it)
STEP_COMMAND = {"code": "Read GIS Code", "zpts": "Read Grid Zpts", "mat": "Read GIS Mat", "bc": "Read GIS BC",
                "oned": "Read GIS Network", "events": "Define Event", "output": "Map Output Data Types"}


class Step(object):
    __slots__ = ("key", "title", "page", "state", "detail", "required")

    def __init__(self, key, title, page, state, detail="", required=True):
        self.key, self.title, self.page, self.state, self.detail, self.required = \
            key, title, page, state, detail, required

    @property
    def command(self):
        return STEP_COMMAND.get(self.key, "")

    def __repr__(self):
        return "Step({}, {}, {})".format(self.key, self.state, self.detail)


def _has(cf, *keys):
    if cf is None:
        return False
    return any((cf.value(k) or "").strip() for k in keys)


def _inputs_state(refs, what):
    if not refs:
        return TODO, "No {} layer read yet".format(what)
    missing = [r for r in refs if r.exists is False]
    if missing:
        return ERROR, "{} of {} missing: {}".format(len(missing), len(refs), ", ".join(m.name for m in missing[:3]))
    unknown = [r for r in refs if r.exists is None]
    names = ", ".join(r.name for r in refs[:3]) + (" ..." if len(refs) > 3 else "")
    return (WARN if unknown and len(unknown) == len(refs) else DONE), names


def run_status(project, dirs=None):
    """(state, detail, simulation name) of the most recent simulation log."""
    if project is None:
        return TODO, "", ""
    from .logs import list_simulations, parse_tlf
    res, chk, log = dirs or project.output_dirs()
    sims = list_simulations(log) if log and os.path.isdir(log) else []
    if not sims:
        return TODO, "Not run yet", ""
    latest = max(sims, key=lambda s: _mtime(os.path.join(log, s + ".tlf")))
    tlf = os.path.join(log, latest + ".tlf")
    if not os.path.isfile(tlf):
        return TODO, "No log", latest
    s = parse_tlf(tlf)
    e, w, _c = s.counts
    if s.status == "FINISHED":
        return (WARN if w else DONE), "{} finished ({} warnings)".format(latest, w), latest
    if s.status in ("UNSTABLE", "ERROR", "INTERRUPTED"):
        return ERROR, "{} {} ({} errors)".format(latest, s.status.lower(), e), latest
    return WARN, "{} {}".format(latest, s.status.lower()), latest


def _mtime(p):
    try:
        return os.path.getmtime(p)
    except OSError:
        return 0


def has_results(project, dirs=None):
    if project is None:
        return False
    res = (dirs or project.output_dirs())[0]
    if not res or not os.path.isdir(res):
        return False
    for pat in ("*_Max.*", "*_max.*", "*.xmdf", "*.nc"):
        if glob.glob(os.path.join(res, "**", pat), recursive=True):
            return True
    return False


def steps(project, inputs=None, findings=None, run=None, dirs=None):
    if project is None:
        return [Step("setup", "Create or open a model", "Project", TODO, "Start in Project & domain")]
    from .model_inputs import model_inputs
    inputs = model_inputs(project) if inputs is None else inputs
    tcf, tgc, tbc = project.files.get("TCF"), project.files.get("TGC"), project.files.get("TBC")
    ecf, tef, qcf = project.files.get("ECF"), project.files.get("TEF"), project.files.get("QCF")
    out = []
    saved = tcf is not None and tcf.path and os.path.isfile(tcf.path)
    out.append(Step("setup", "Model set up", "Project", DONE if saved else WARN,
                    os.path.basename(tcf.path) if saved else "Save the control files"))
    # grid
    miss = []
    if not _has(tgc, "Cell Size") and qcf is None:
        miss.append("cell size")
    if not _has(tgc, "Grid Size (X,Y)", "Grid Size (N,M)") and qcf is None:
        miss.append("grid size")
    if not (_has(tgc, "Read GIS Location", "Origin", "Read Grid Location") or qcf is not None):
        miss.append("origin / 2d_loc")
    if tgc is None:
        out.append(Step("domain", "Grid & domain", "TGC", TODO, "No geometry control file (TGC)"))
    else:
        loc = inputs_for(inputs, "read gis location")
        st = ERROR if any(r.exists is False for r in loc) else (TODO if miss else DONE)
        detail = "Missing: " + ", ".join(miss) if miss else "Cell {} m, grid {}".format(
            tgc.value("Cell Size") or (qcf.value("Base Cell Size") if qcf else "?"),
            tgc.value("Grid Size (X,Y)") or "Quadtree")
        if st == ERROR:
            detail = "2d_loc layer not found"
        out.append(Step("domain", "Grid & domain", "Project", st, detail))
    st, d = _inputs_state(inputs_for(inputs, "read gis code", "read grid code"), "2d_code")
    out.append(Step("code", "Active area (2d_code)", "TGC", st, d))
    st, d = _inputs_state(inputs_for(inputs, "read grid zpts", "read gis zpts", "read tin zpts", "create tin zpts"),
                          "elevation")
    out.append(Step("zpts", "Elevations (DEM)", "TGC", st, d))
    mats = inputs_for(inputs, "read gis mat", "read grid mat")
    st, d = _inputs_state(mats, "2d_mat")
    if st == TODO and _has(tgc, "Set Mat"):
        st, d = WARN, "Only the default material (Set Mat)"
    mfile = (tcf.value("Read Materials File") or "").strip() if tcf else ""
    if mfile:
        from .control_file import resolve_path
        if not os.path.isfile(resolve_path(mfile, os.path.dirname(tcf.path))):
            st, d = ERROR, "Materials file not found"
    elif st == DONE:
        st, d = WARN, "No Read Materials File in the TCF"
    out.append(Step("mat", "Materials & roughness", "TGC", st, d))
    bcs = inputs_for(inputs, "read gis bc", "read gis sa", "read gis rf")
    rain = _has(tbc, "Global Rainfall BC")
    st, d = _inputs_state(bcs, "boundary")
    if rain and st == TODO:
        st, d = DONE, "Global rainfall: {}".format(tbc.value("Global Rainfall BC"))
    elif rain:
        d += " + global rainfall"
    db = (tcf.value("BC Database") or "").strip() if tcf else ""
    if st != TODO:
        from .control_file import resolve_path
        if not db:
            st, d = ERROR, "No BC Database in the TCF"
        elif not os.path.isfile(resolve_path(db, os.path.dirname(tcf.path))):
            st, d = ERROR, "BC database not found"
    out.append(Step("bc", "Boundaries", "TBC", st, d))
    if ecf is not None:
        st, d = _inputs_state(inputs_for(inputs, "read gis network"), "1d_nwk")
        out.append(Step("oned", "1D network", "ECF", st, d))
    else:
        out.append(Step("oned", "1D network", "ECF", OPTIONAL, "Not used (2D only)", required=False))
    evs = project.events_defined()
    out.append(Step("events", "Events", "TEF", DONE if evs else OPTIONAL,
                    "{} event(s): {}".format(len(evs), ", ".join(evs[:4])) if evs else "Single event (no TEF)",
                    required=False))
    ok_out = _has(tcf, "Output Folder") and _has(tcf, "Map Output Data Types")
    out.append(Step("output", "Output settings", "TCF", DONE if ok_out else TODO,
                    (tcf.value("Map Output Data Types") or "") if ok_out else "Set Output Folder and map data types"))
    if findings is None:
        out.append(Step("qc", "Model checks (QC)", "QC", TODO, "Run QC"))
    else:
        ne = sum(1 for f in findings if f.severity == "ERROR")
        nw = sum(1 for f in findings if f.severity == "WARNING")
        out.append(Step("qc", "Model checks (QC)", "QC", ERROR if ne else (WARN if nw else DONE),
                        "{} errors, {} warnings".format(ne, nw)))
    rs, rd, _sim = run if run is not None else run_status(project, dirs)
    out.append(Step("run", "Simulation", "Batch & Run", rs, rd))
    out.append(Step("results", "Results", "Outputs", DONE if has_results(project, dirs) else TODO,
                    "Results found" if has_results(project, dirs) else "No results yet"))
    return out


def progress(step_list):
    req = [s for s in step_list if s.required]
    if not req:
        return 0
    return int(round(100.0 * sum(1 for s in req if s.state == DONE) / len(req)))


LATE_STEPS = ("qc", "run", "results")


def next_step(step_list):
    """What to do next: a broken build step first, then the first unfinished build step, then
    checks, run and results (QC errors usually come from an unfinished build step)."""
    todo = [s for s in step_list if s.required and s.state != DONE]
    if not todo:
        return None
    build = [s for s in todo if s.key not in LATE_STEPS]
    for group in (build, todo):
        errs = [s for s in group if s.state == ERROR]
        if errs:
            return errs[0]
        if group:
            return group[0]
    return todo[0]


def page_states(step_list):
    """Worst state per page, for the sidebar badges."""
    out = {}
    for s in step_list:
        if s.state in (DONE, OPTIONAL):
            out.setdefault(s.page, s.state)
            if out[s.page] == OPTIONAL and s.state == DONE:
                out[s.page] = DONE
            continue
        cur = out.get(s.page)
        if cur is None or STATE_ORDER[s.state] < STATE_ORDER.get(cur, 9):
            out[s.page] = s.state
    return out
