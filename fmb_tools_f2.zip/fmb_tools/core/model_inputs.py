# -*- coding: utf-8 -*-
"""
Every GIS layer and grid a model reads (Read GIS ..., Read Grid ..., Read TIN ...),
resolved to files / GeoPackage layers, with existence checked. Used by the dashboard
workflow and by 'Load model inputs to map'.
"""
import os
import re

from .control_file import resolve_path, split_value_paths, looks_like_path, substitute_tokens, TOKEN_RE
from .qc import gpkg_layers, _file_variants

RASTER_EXT = (".tif", ".tiff", ".asc", ".flt", ".nc", ".dem", ".vrt")
GROUP_TITLES = {"TCF": "Control (TCF)", "TGC": "Geometry (TGC)", "TBC": "Boundaries (TBC)", "ECF": "1D network (ECF)",
                "QCF": "Quadtree (QCF)", "TEF": "Events (TEF)", "TRFC": "Rainfall (TRFC)", "TESF": "Wind (TESF)",
                "TOC": "Operations (TOC)", "TSCF": "SWMM (TSCF)", "ADCF": "AD (ADCF)"}
FILE_ORDER = ["TBC", "ECF", "TGC", "QCF", "TCF", "TEF", "TRFC", "TESF", "TOC", "TSCF", "ADCF"]


class InputRef(object):
    __slots__ = ("ftype", "command", "path", "layer", "kind", "exists", "note")

    def __init__(self, ftype, command, path, layer="", kind="vector", exists=None, note=""):
        self.ftype = ftype
        self.command = command
        self.path = path
        self.layer = layer
        self.kind = kind            # vector | raster | tin
        self.exists = exists        # True / False / None (not checkable: tokens)
        self.note = note

    @property
    def name(self):
        return self.layer or os.path.splitext(os.path.basename(self.path))[0]

    @property
    def uri(self):
        if self.layer and self.path.lower().endswith(".gpkg"):
            if self.kind == "raster":
                return "GPKG:{}:{}".format(self.path, self.layer)
            return "{}|layername={}".format(self.path, self.layer)
        return self.path

    @property
    def geom(self):
        """P / L / R from the TUFLOW layer-name suffix, '' if unknown."""
        m = re.search(r"_([PLR])$", self.name, re.IGNORECASE)
        return m.group(1).upper() if m else ""

    def __repr__(self):
        return "InputRef({}, {}, {}, exists={})".format(self.ftype, self.command, self.name, self.exists)


def _is_input_command(e):
    k = (e.spec.key if e.spec is not None else e.lhs).lower()
    if k.startswith("spatial database"):
        return False
    if e.spec is not None and e.spec.value_kind in ("gis", "grid"):
        return True
    return k.startswith(("read gis", "read grid", "read tin", "create tin"))


def model_inputs(project, scenarios=None, events=None):
    """[InputRef] for every GIS / grid input of the model, in control-file order."""
    if project is None:
        return []
    scenarios = scenarios if scenarios is not None else project.state.get("scenarios") or []
    events = events if events is not None else project.state.get("events") or []
    tcf = project.files.get("TCF")
    variables = {}
    if tcf is not None:
        for e in tcf.commands():
            if e.lhs.lower().startswith("set variable"):
                variables[e.lhs[12:].strip().lower()] = e.value

    def base_of(ftype, cf):
        return os.path.dirname(cf.path) if cf.path else project.dir_of(ftype)

    tcf_db = None
    if tcf is not None:
        v = tcf.value("Spatial Database")
        if v and v.strip().upper() not in ("OFF", "TCF"):
            tcf_db = resolve_path(substitute_tokens(v, scenarios, events, variables), base_of("TCF", tcf))
    out = []
    order = [ft for ft in FILE_ORDER if ft in project.files] + [ft for ft in project.files if ft not in FILE_ORDER]
    layer_cache = {}

    def layers_of(db):
        if db not in layer_cache:
            layer_cache[db] = gpkg_layers(db) if db and os.path.isfile(db) else None
        return layer_cache[db]

    for ftype in order:
        cf = project.files[ftype]
        base = base_of(ftype, cf)
        db = tcf_db
        for e in cf.commands():
            k = (e.spec.key if e.spec is not None else e.lhs).lower()
            if k.startswith("spatial database"):
                v = (e.value or "").strip()
                db = None if v.upper() == "OFF" else (tcf_db if v.upper() == "TCF" or not v else
                                                      resolve_path(substitute_tokens(v, scenarios, events, variables), base))
                continue
            if not e.value.strip() or not _is_input_command(e):
                continue
            grid = (e.spec is not None and e.spec.value_kind == "grid") or k.startswith("read grid")
            tin = k.startswith(("read tin", "create tin"))
            value = substitute_tokens(e.value, scenarios, events, variables)
            if TOKEN_RE.search(value):
                out.append(InputRef(ftype, e.lhs, value, kind="raster" if grid else "vector", exists=None,
                                    note="uses scenario / event tokens"))
                continue
            for path, layers in split_value_paths(value):
                if not path or re.fullmatch(r"-?\d+(\.\d+)?", path):
                    continue
                if not looks_like_path(path) and db:                  # layer name in the spatial database
                    lyr = layers_of(db)
                    ok = None if lyr is None else path.lower() in [x.lower() for x in lyr]
                    out.append(InputRef(ftype, e.lhs, db, path, "raster" if grid else "vector", ok))
                    continue
                full = resolve_path(path, base)
                found = next((v for v in _file_variants(full) if os.path.exists(v)), None)
                p = found or full
                ext = os.path.splitext(p)[1].lower()
                kind = "tin" if tin and ext not in RASTER_EXT and ext not in (".shp", ".gpkg", ".mif") else \
                    ("raster" if grid or ext in RASTER_EXT else "vector")
                if ext == ".gpkg":
                    names = layers or [os.path.splitext(os.path.basename(p))[0]]
                    lyr = layers_of(p) if found else None
                    for l in names:
                        ok = (found is not None) and (lyr is None or l.lower() in [x.lower() for x in lyr])
                        out.append(InputRef(ftype, e.lhs, p, l, kind, ok))
                else:
                    out.append(InputRef(ftype, e.lhs, p, "", kind, found is not None))
    return out


def inputs_for(inputs, *commands):
    cmds = [c.lower() for c in commands]
    return [i for i in inputs if any(" ".join(i.command.lower().split()).startswith(c) for c in cmds)]
