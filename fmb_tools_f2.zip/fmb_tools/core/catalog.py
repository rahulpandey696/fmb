# -*- coding: utf-8 -*-
"""
Parses the command syntax index (catalog_data) into structured CommandSpec
objects that the UI can turn into the right input widget, and that the
control-file reader can use to recognise commands in existing files.
"""
import re
from . import catalog_data as cd

CONTROL_FILE_TYPES = ["TCF", "TGC", "TBC", "ECF", "TEF", "QCF", "TRFC", "TOC", "TESF", "TSCF", "ADCF"]

FILE_TYPE_INFO = {
    # type: (extension, long name, TCF/ECF command that references it)
    "TCF": (".tcf", "TUFLOW Control File", None),
    "TGC": (".tgc", "Geometry Control File", "Geometry Control File"),
    "TBC": (".tbc", "Boundary Control File", "BC Control File"),
    "ECF": (".ecf", "ESTRY (1D) Control File", "ESTRY Control File"),
    "TEF": (".tef", "Event File", "Event File"),
    "QCF": (".qcf", "Quadtree Control File", "Quadtree Control File"),
    "TRFC": (".trfc", "Rainfall Control File", "Rainfall Control File"),
    "TOC": (".toc", "Operational Controls File", "Read Operating Controls File"),
    "TESF": (".tesf", "External Stress File", "External Stress File"),
    "TSCF": (".tscf", "SWMM Control File", "SWMM Control File"),
    "ADCF": (".adcf", "Advection Dispersion Control File", "AD Control File"),
}

# placeholder text fragment -> (value kind, Qt file filter)
_EXT_FILTERS = {
    ".tbc": "TUFLOW BC Control (*.tbc)",
    ".tgc": "TUFLOW Geometry Control (*.tgc)",
    ".ecf": "ESTRY Control (*.ecf)",
    ".tef": "TUFLOW Event File (*.tef)",
    ".qcf": "Quadtree Control (*.qcf)",
    ".trfc": "Rainfall Control (*.trfc)",
    ".tesf": "External Stress File (*.tesf)",
    ".tscf": "SWMM Control (*.tscf)",
    ".adcf": "AD Control (*.adcf)",
    ".toc": "Operational Controls (*.toc)",
    ".csv": "CSV (*.csv)",
    ".nc": "NetCDF (*.nc)",
    ".trf": "Restart file (*.trf)",
    ".tsoilf": "Soils file (*.tsoilf)",
    ".mid": "MapInfo MID (*.mid)",
    ".mif": "MapInfo MIF (*.mif)",
    ".prj": "Projection (*.prj *.shp)",
    ".inp": "SWMM input (*.inp)",
    ".nwk11": "MIKE 11 network (*.nwk11)",
    ".adcf_file": "AD Control (*.adcf)",
}
GIS_FILTER = "GIS layers (*.gpkg *.shp *.mif);;GeoPackage (*.gpkg);;Shapefile (*.shp);;MapInfo (*.mif)"
GRID_FILTER = "Grids (*.tif *.tiff *.asc *.flt *.nc *.gpkg *.vrt);;All files (*)"
TIN_FILTER = "TIN (*.12da *.2dm *.tin);;All files (*)"
MATERIALS_FILTER = "Materials (*.csv *.tmf);;All files (*)"

# Commands whose value points to another control file of a given type
CHILD_COMMANDS = {v[2]: k for k, v in FILE_TYPE_INFO.items() if v[2]}

# Commands whose value points to a database / table
DATABASE_COMMANDS = {
    "BC Database": "bc_dbase",
    "Read Materials File": "materials",
    "Read Soils File": "soils",
    "Pit Inlet Database": "pit_dbase",
    "Depth Discharge Database": "dd_dbase",
    "XS Database": "xs_dbase",
    "Read Hazard File": "hazard",
    "Blockage Matrix File": "blockage",
    "AD BC Database": "ad_bc",
    "AD Global Database": "ad_global",
}

OUTPUT_FORMAT_PREFIXES = ["XMDF", "TIF", "ASC", "FLT", "NC", "GPKG", "COG", "DAT", "WRR", "TGO", "SMS", "GIS"]
FORMAT_PREFIXABLE = {"Map Output Data Types", "Map Output Interval", "Start Map Output", "End Map Output"}

BLOCK_OPEN = ("if scenario", "if event", "define event", "define output zone", "start 2d domain",
              "start 1d domain", "define")
BLOCK_MID = ("else if scenario", "else if event", "else")
BLOCK_CLOSE = ("end if", "end define", "end 2d domain", "end 1d domain")


def manual_url(anchor, ftype=None):
    """Return the manual URL for an anchor like 'tcf-EndTime'."""
    if not anchor:
        page = cd.APPENDIX_PAGES.get(ftype or "TCF")
        return cd.MANUAL_ROOT + page
    prefix = anchor.split("-", 1)[0].upper()
    page = cd.APPENDIX_PAGES.get(prefix) or cd.APPENDIX_PAGES.get(ftype or "TCF")
    return "{}{}#{}".format(cd.MANUAL_ROOT, page, anchor)


def appendix_url(ftype):
    return cd.MANUAL_ROOT + cd.APPENDIX_PAGES.get(ftype, cd.APPENDIX_PAGES["TCF"])


class Part(object):
    """One piece of the left-hand side of a command."""
    __slots__ = ("kind", "text", "options", "default", "editable")

    def __init__(self, kind, text="", options=None, default="", editable=False):
        self.kind = kind          # 'lit' | 'mod' | 'free'
        self.text = text
        self.options = options or []
        self.default = default
        self.editable = editable

    def __repr__(self):
        return "Part({!r},{!r},{!r})".format(self.kind, self.text, self.options)


class CommandSpec(object):
    def __init__(self, ftype, syntax, anchor):
        self.ftype = ftype
        self.syntax = syntax.strip()
        if anchor and "-" not in anchor:
            anchor = "{}-{}".format(ftype.lower(), anchor)
        self.anchor = anchor
        lhs, sep, rhs = self.syntax.partition("==")
        self.has_value = bool(sep)
        self.parts = _parse_lhs(lhs.strip())
        self.name = " ".join(p.text if p.kind == "lit" else ("<{}>".format(p.text) if p.kind == "free" else "")
                             for p in self.parts).strip()
        self.name = re.sub(r"\s+", " ", self.name)
        # "key" is the base name without modifiers - used for lookup
        self.key = re.sub(r"\s+", " ", " ".join(p.text for p in self.parts if p.kind == "lit")).strip()
        self.options, self.default, self.placeholders = _parse_rhs(rhs.strip()) if sep else ([], "", [])
        self.value_kind, self.file_filter = _value_kind(self.key, self.placeholders, self.options)
        self._regex = _lhs_regex(self.parts)
        self.child_type = CHILD_COMMANDS.get(self.key)
        self.database = DATABASE_COMMANDS.get(self.key)

    # -- helpers ---------------------------------------------------------
    @property
    def url(self):
        return manual_url(self.anchor, self.ftype)

    @property
    def is_block_keyword(self):
        k = self.key.lower()
        return k.startswith(BLOCK_OPEN) or k in BLOCK_MID or k in BLOCK_CLOSE

    def match_lhs(self, lhs):
        """If `lhs` is a (possibly modified) form of this command, return the list
        of chosen modifier/free values, else None."""
        m = self._regex.match(" ".join(lhs.split()))
        if not m:
            return None
        return [(g or "").strip() for g in m.groups()]

    def build_lhs(self, choices):
        """Build the left-hand side from a list of modifier/free-text choices."""
        out, i = [], 0
        for p in self.parts:
            if p.kind == "lit":
                out.append(p.text)
            else:
                val = choices[i] if i < len(choices) else p.default
                i += 1
                if val:
                    out.append(val)
        return re.sub(r"\s+", " ", " ".join(out)).strip()

    def default_choices(self):
        return [p.default for p in self.parts if p.kind != "lit"]

    def variable_parts(self):
        return [p for p in self.parts if p.kind != "lit"]

    def __repr__(self):
        return "CommandSpec({}:{})".format(self.ftype, self.name)


# ---------------------------------------------------------------------------
def _split_top(text, sep="|"):
    """Split on `sep` ignoring separators inside <> or []."""
    out, buf, depth_a, depth_b = [], [], 0, 0
    for ch in text:
        if ch == "<":
            depth_a += 1
        elif ch == ">":
            depth_a = max(0, depth_a - 1)
        elif ch == "[":
            depth_b += 1
        elif ch == "]":
            depth_b = max(0, depth_b - 1)
        if ch == sep and depth_a == 0 and depth_b == 0:
            out.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    out.append("".join(buf))
    return [s.strip() for s in out]


def _parse_options(group):
    opts, default, editable = [], None, False
    for alt in [a.strip() for a in group.split("|")]:
        m = re.fullmatch(r"\{(.*)\}", alt)
        if m:
            alt = m.group(1).strip()
            default = alt
        if "<" in alt:
            editable = True
            continue
        if alt not in opts:
            opts.append(alt)
    if default is None:
        default = "" if "" in opts else (opts[0] if opts else "")
    return opts, default, editable


def _parse_lhs(lhs):
    parts, buf, i = [], [], 0

    def flush():
        t = "".join(buf).strip()
        if t:
            parts.append(Part("lit", re.sub(r"\s+", " ", t)))
        del buf[:]

    while i < len(lhs):
        ch = lhs[i]
        if ch == "[":
            flush()
            j = lhs.index("]", i)
            opts, default, editable = _parse_options(lhs[i + 1:j])
            parts.append(Part("mod", "|".join(o for o in opts if o), opts, default, editable))
            i = j + 1
            continue
        if ch == "<":
            flush()
            j = lhs.index(">", i)
            parts.append(Part("free", lhs[i + 1:j], [], "", True))
            i = j + 1
            continue
        buf.append(ch)
        i += 1
    flush()
    return parts


def _parse_rhs(rhs):
    rhs = rhs.replace("[", " ").replace("]", " ")
    options, default, placeholders = [], "", []
    for alt in _split_top(rhs):
        if not alt:
            continue
        m = re.fullmatch(r"\{(.*)\}", alt)
        if m:
            inner = m.group(1).strip()
            if inner and "<" not in inner:
                default = inner
                if inner not in options:
                    options.append(inner)
            continue
        if "<" in alt:
            placeholders.append(alt)
        elif alt != "...":
            if alt not in options:
                options.append(alt)
    return options, default, placeholders


_FILE_WORDS = ("_file", "file>", "_layer", "database", "_dbase", "folder", ".csv", "geotiff",
               "boundary_file", "tin_file", "grid_file")


def _value_kind(key, placeholders, options):
    ph = " ".join(placeholders).lower()
    if "gis_layer_out" in ph:
        return "gis_out", GIS_FILTER
    if "<gis_layer" in ph or "<mif_layer" in ph or "gpkg_layer" in ph:
        return "gis", GIS_FILTER
    if "gpkg_database" in ph:
        return "file", "GeoPackage (*.gpkg)"
    if "<grid_file" in ph or "geotiff" in ph:
        return "grid", GRID_FILTER
    if "<tin_file" in ph:
        return "file", TIN_FILTER
    if "<folder" in ph:
        return ("folder_or_choice" if options else "folder"), ""
    if key == "Read Materials File":
        return "file", MATERIALS_FILTER
    if key == "Read File":
        return "file", "TUFLOW read file (*.trd);;All files (*)"
    if any(w in ph for w in _FILE_WORDS):
        filt = "All files (*)"
        for ext, f in _EXT_FILTERS.items():
            if ext in ph:
                filt = f + ";;All files (*)"
                break
        return ("file_or_choice" if options else "file"), filt
    if options and placeholders:
        return "choice_edit", ""
    if options:
        return "choice", ""
    if placeholders:
        return "text", ""
    return "none", ""


def _lhs_regex(parts):
    pat = [r"^"]
    first = True
    for p in parts:
        sep = r"" if first else r"\s*"
        if p.kind == "lit":
            words = [re.escape(w) for w in p.text.split()]
            pat.append(sep + r"\s*".join(words))
            first = False
        elif p.kind == "mod":
            alts = sorted([o for o in p.options if o], key=len, reverse=True)
            alt_pat = "|".join(r"\s*".join(re.escape(w) for w in a.split()) for a in alts)
            if p.editable:
                alt_pat = (alt_pat + "|" if alt_pat else "") + r"[^=]+?"
            pat.append(r"(?:\s+({}))?".format(alt_pat) if alt_pat else r"()")
        else:  # free
            pat.append(r"\s+(.+?)")
            first = False
    pat.append(r"\s*$")
    return re.compile("".join(pat), re.IGNORECASE)


# ---------------------------------------------------------------------------
class Catalog(object):
    """All command specs, grouped by control file type."""

    def __init__(self):
        self.by_type = {}
        for ftype in CONTROL_FILE_TYPES:
            specs = []
            text = cd.RAW[ftype] + cd.EXTRA_BY_TYPE.get(ftype, "")
            seen = set()
            for line in text.strip().splitlines():
                line = line.strip()
                if not line or "@@" not in line:
                    continue
                syntax, anchor = [s.strip() for s in line.split("@@", 1)]
                spec = CommandSpec(ftype, syntax, anchor)
                if spec.name.lower() in seen:
                    continue
                seen.add(spec.name.lower())
                specs.append(spec)
            # longest names first so that 'Read GIS Z Shape Route' wins over 'Read GIS Z Shape'
            self.by_type[ftype] = specs
        self._sorted = {k: sorted(v, key=lambda s: len(s.key), reverse=True) for k, v in self.by_type.items()}

    def specs(self, ftype):
        return self.by_type.get(ftype, [])

    def get(self, ftype, key):
        k = key.lower()
        for s in self.by_type.get(ftype, []):
            if s.key.lower() == k or s.name.lower() == k:
                return s
        return None

    def match(self, ftype, lhs):
        """Find the spec matching a command's left-hand side.
        Returns (spec, choices) or (None, None)."""
        types = [ftype]
        if ftype == "TEF":          # the TEF may contain any TCF/ECF command
            types += ["TCF", "ECF"]
        for t in types:
            for s in self._sorted.get(t, []):
                ch = s.match_lhs(lhs)
                if ch is not None:
                    return s, ch
        # output-format specific variants, e.g. "XMDF Map Output Data Types", "TIF Start Map Output"
        m = re.match(r"^\s*({})\s+(.+)$".format("|".join(OUTPUT_FORMAT_PREFIXES)), lhs, re.IGNORECASE)
        if m and ftype in ("TCF", "TEF"):
            spec, ch = self.match("TCF", m.group(2))
            if spec is not None and spec.key in FORMAT_PREFIXABLE:
                return spec, ch
        return None, None


_CATALOG = None


def catalog():
    global _CATALOG
    if _CATALOG is None:
        _CATALOG = Catalog()
    return _CATALOG
