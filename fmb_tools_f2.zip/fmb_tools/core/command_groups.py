# -*- coding: utf-8 -*-
"""
Topic groups for the command browser. Each control file has an ordered list of
(topic, regex) rules matched against the command name; the first match wins and
anything unmatched goes to 'Other'.
"""
import re

LOGIC = ("If blocks, Read File & database",
         r"(Else )?If (Scenario|Event)|Else|End If|Read File|Pause|Spatial Database")

GROUP_RULES = {
    "TCF": [
        ("Scenarios, events & logic",
         r"(Else )?If (Scenario|Event)|Else|End If|Model (Scenarios|Events)|BC Event (Name|Source|Text)|"
         r"Set Variable.*|Pause|Read File"),
        ("Control files & databases",
         r"(AD|BC|ESTRY|Geometry|Quadtree|Rainfall|SWMM) Control File|External Stress File|Event File|BC Database|"
         r"Read (Materials|Soils|Hazard) File"),
        ("Domains", r"(Start|End) (1D|2D) Domain"),
        ("Restart files", r"Read Restart File|Write Restart.*|Restart File Ignore Fields|HPC Restart Geometry"),
        ("Solver, hardware & model set-up",
         r"Units|Solution Scheme|Hardware|CPU Threads|GPU .*|HPC Device Split|Model (Precision|Platform|TUFLOW Build|"
         r"TUFLOW Release)|Defaults|Demo Model|Tutorial Model|WIBU.*|RAM Optimisation|Meshparts|"
         r"Control Number Factor|Command Line Processing"),
        ("Time control & auto-terminate",
         r"(Start|End) Time|Timestep.*|End After Maximum.*|Auto Terminate.*|Set Auto Terminate|"
         r"Read GIS Auto Terminate|Simulation Pause.*|Maximum Courant Number"),
        ("Sub-grid sampling (SGS)", r"SGS.*"),
        ("HPC solver options", r"HPC .*|Quadtree BC Parallel Inertia Approach|Negative Depth Approach"),
        ("Boundaries, rainfall & wind",
         r"BC (Zero Flow|Wet/Dry Method)|HQ Boundary Approach|Rainfall .*|Read Grid RF|"
         r"Global Rainfall Use Material Loss|Zero Rainfall Check|Read GIS (Cyclone|Hurricane)|Wind/Wave .*|"
         r"FEWS Input File|SA (Minimum Depth|Proportion to Depth)"),
        ("Initial conditions", r"Set IWL|Read GIS IWL|Read RowCol IWL"),
        ("Infiltration, soils & groundwater", r"Soil .*|GA .*|Groundwater .*"),
        ("1D/2D & 2D/2D linking",
         r"Adjust Head at ESTRY Interface|Distribute HX Flows|HX .*|SX .*|Link 2D2D .*|Number 2D2D Link Iterations|"
         r"Index 1D2D Links|Unused HX and SX Connections|Pit No 1D Connection|Pit Surcharge .*|Reveal 1D Nodes|"
         r"Maximum 1D Channels|Read GIS (12D|ISIS|X1D|XP) .*"),
        ("Structures, losses & blockage",
         r"Blockage .*|BG FLC Default Approach|Blank BG FLC Approach|Layered FLC Default Approach|"
         r"Form Loss Rotational Adjustment|Read GIS FC|VG Z Adjustment|Global Weir Factor|Global FC Ch Factor"),
        ("2D solution: wet/dry, viscosity & physics",
         r"Cell (Side )?Wet/Dry Depth|Wetting and Drying|Viscosity .*|Boundary Viscosity Factor|Density of .*|"
         r"Latitude|Free Overfall.*|Froude .*|Supercritical|Shallow Depth Stability Factor|Number Iterations|"
         r"First Sweep Direction|Zero Negative Depths|Instability Water Level|Water Level Checks|"
         r"Recalculate Chezy Interval|Depth/Ripple Height Factor Limit|Bed Resistance .*|Mass Balance Corrector|"
         r"Inside Region|Line Cell Selection|Change Zero Material Values to One|Cell Size"),
        ("Hazard & route outputs", r"UK Hazard .*|ZP Hazard Cutoff Depth|Set Route Cut Off .*|BSS Cutoff Depth"),
        ("Map output",
         r"Map .*|(Start|End) Map Output|Grid (Format|Output .*)|HR .*|TIF Compression.*|GPKG Compression.*|"
         r"NetCDF .*|XMDF .*|TIN .*|Maximums.*|Time Output .*|Output (Approach|Files|Folder|Drive)|"
         r"Maximum Velocity Cutoff Depth|Blue Kenue Start Date|FEWS Geodatum|Define Output Zone|End Define|"
         r"Model Output Zones|Read GIS Output Zone|GDAL Raster Create Options|Process All Grids"),
        ("Time series & plot output",
         r"Time Series .*|Start Time Series Output|Read GIS (PO|LP|GLO|Reporting Location)|PO Approach|"
         r"Write PO Online|Plot Output Invalid Type|Record Gauge Data.*|CSV .*|Excel Start Date|HEC-DSS Start Date|"
         r"Calibration Points MI File|Display Water Level|Mass Balance Output.*"),
        ("Check files & logs",
         r"Write (X1D )?Check Files|Log Folder|Simulations Log Folder|Screen/Log Display Interval|Verbose|"
         r"Force File IO Display|TSF Update Interval|Null Cell Checks|Check Inside Grid"),
        ("GIS formats, projection & files",
         r"GIS .*|GPKG .*|SHP .*|MI Projection.*|TIF Projection|Spatial Database.*|SQLite .*|Check MI Save .*|"
         r"Snap Tolerance|Use GDAL|GDAL .*|Write Empty GIS Files|Use Forward Slash|Input Drive|File Retry .*|"
         r"Maximum (Points|Vertices)|XF Files.*|Zpt Range Check|Read GIS <option>"),
    ],
    "TGC": [
        LOGIC,
        ("Grid definition",
         r"Cell Size|Grid Size.*|Origin|Orientation.*|Read (GIS|Grid) Location|Grid Approach"),
        ("Active cells (codes)", r"Set Code.*|Read (GIS|Grid) Code|Read RowCol <option>"),
        ("Z lines & Z shapes",
         r"Read GIS Z (Line|HX Line|Shape|Shape Route)|Read GIS Variable Z Shape|Allow Dangling Z Lines|"
         r"Pause When Polyline Does Not Find Zpt|Thin Line as Thick|Set Route Cut Off .*"),
        ("Elevations (Zpts)",
         r"Set Zpt|Read (GIS|Grid|TIN|RowCol) Zpts.*|Create TIN Zpts|Default Land Z|Zero Z Point|Interpolate Z.*|"
         r"ZC|12DA Read Approach|TIN .*|Write GIS Zpts"),
        ("Materials & roughness", r"Set Mat|Read (GIS|Grid) Mat|(Set|Read GIS|Read Grid) (FRIC|SRF|CnM)"),
        ("Structures & losses",
         r"Read GIS (Layered )?FC Shape|Read GIS BG Shape|(Set|Read GIS|Read Grid) (FLC|FLC/L|CWF|WrF)|"
         r"Read RowCol WrF"),
        ("Initial water level", r"(Set|Read GIS|Read Grid) IWL"),
        ("Soils & groundwater", r".*Soil.*|(Set|Read GIS|Read Grid) (GWD|GWL)|.*IGW .*"),
        ("Receptors & objects", r"Read GIS (Objects|Receptors)"),
        ("Sub-grid sampling (SGS)", r"SGS .*"),
        ("Output & checks", r"Write GIS (Domain|Grid)|Stop"),
    ],
    "TBC": [
        LOGIC,
        ("BC database & events", r"BC (Database|Event .*)"),
        ("Boundary layers", r"Read GIS (BC|SA|Streams)|Blank (BC Type|HQ Slope)|Unused HX and SX Connections"),
        ("Rainfall", r"Global Rainfall .*|Read GIS RF|Read RowCol RF"),
    ],
    "ECF": [
        LOGIC,
        ("Network & nodes",
         r"Read GIS (Network|Node)|Create Nodes|M11 Network|1D Node Invert Approach|Apply All Inverts|"
         r"Interpolate Culvert Inverts|Minimum Channel .*|Minimum NA|Taper Closed NA Table"),
        ("Cross-sections & tables",
         r"Read GIS Table Links|XS Database|Interpolate Cross-Sections|Trim XZ Profiles|Conveyance Calculation|"
         r"Flow Area|Depth Discharge Database"),
        ("Pits & manholes", r"Pit .*|Read GIS (Pits|Manhole)|Manhole.*|Minimum NA Pit"),
        ("Structures: culverts, bridges & weirs",
         r"Culvert .*|Bridge .*|Arch Bridge .*|Weir .*|Structure .*|Storage Above Structure Obvert|"
         r"Read Operating Controls File|Maximum Operational Controls"),
        ("Boundaries & initial conditions", r"BC .*|Read GIS (BC|IWL)|Set IWL|Overlapping SX HX Boundary"),
        ("Time step & solver",
         r"Timestep|Head Rate .*|Vel Rate .*|Depth Limit Factor|Froude .*|Flow Calculation|[MS] Channel Approach|"
         r"Momentum Equation|AD Approach"),
        ("Output & checks", r"Output .*|Start Output|CSV .*|Order Output|Write Check Files"),
        ("Water level lines (1D map output)", r"WLL.*|Read GIS WLL.*"),
    ],
    "TEF": [("Event blocks", r"Define Event|End Define")],
    "QCF": [LOGIC, ("Quadtree mesh", r".*")],
    "TRFC": [
        LOGIC,
        ("Gauges & polygons", r"Read GIS RF .*|Maximum (RF Locations|Hyetograph Points)"),
        ("Interpolation", r"IDW .*|RF Interpolation Method"),
        ("Rainfall grid", r"RF Grid .*"),
    ],
    "TOC": [
        LOGIC,
        ("Control blocks", r"Define .*Control|End Define|Operation|Method"),
        ("Gates", r"Gate .*|Cd Gate.*"),
        ("Pumps", r"Pump .*|Discharge Curve Type"),
        ("Orifices", r"Orifice .*"),
        ("Weirs & spillways", r"Weir .*|Cd Spillway"),
        ("Breaches", r"Breach .*|Depth .*|Top Width .*|Side Slope.*"),
        ("Coefficients", r"(Cd|Cf|Ex|Sa|Sb|Ka|Kp)( .*)?|Number of Piers"),
        ("Timing", r"Period .*"),
    ],
    "TESF": [
        ("Wind inputs", r"Read GIS Wind .*|Global Wind BC|Read Gridded Tau"),
        ("Interpolation", r"IDW .*|Grid Interpolation Method"),
        ("Output grid", r"Output Grid .*"),
    ],
    "TSCF": [
        LOGIC,
        ("SWMM inputs", r"Read SWMM|Read BC .*|Read GIS SWMM Inlet Usage|Check INP Save Date"),
        ("Inlets", r"Inlet .*|Maximum Inlet Ponded Depth"),
        ("Solver & output", r"SWMM Iterations|Output Folder"),
    ],
    "ADCF": [("Databases", r"AD .*"), ("Output", r"Write .*")],
}

_COMPILED = {ft: [(g, re.compile(r"^(?:{})$".format(rx), re.IGNORECASE)) for g, rx in rules]
             for ft, rules in GROUP_RULES.items()}


def group_of(ftype, spec):
    name = spec.name
    for g, rx in _COMPILED.get(ftype, []):
        if rx.match(spec.key) or rx.match(name):
            return g
    return "Other"


def grouped(ftype, specs):
    """[(group, [specs sorted by name])] in rule order, 'Other' last, empty groups dropped."""
    order = [g for g, _r in GROUP_RULES.get(ftype, [])]
    buckets = {}
    for s in specs:
        buckets.setdefault(group_of(ftype, s), []).append(s)
    out = []
    for g in order + ["Other"]:
        if g in buckets:
            out.append((g, sorted(buckets.pop(g), key=lambda s: s.name.lower())))
    return out
