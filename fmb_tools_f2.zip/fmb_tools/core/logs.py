# -*- coding: utf-8 -*-
"""
Readers for TUFLOW run outputs used for post-run QC and stability flags:
  .tlf / .hpc.tlf       log files
  _messages.csv/.gpkg   message layer (errors/warnings/checks with locations)
  _MB.csv / _MB2D.csv   mass balance
  hpc.dt.csv            HPC timestep and control numbers
  .tsf                  summary file
  _TUFLOW Simulations.log   run register
All readers are tolerant: column names are matched loosely so they keep
working across TUFLOW releases.
"""
import csv
import glob
import io
import os
import re
import sqlite3

MESSAGE_RE = re.compile(r"\b(ERROR|WARNING|CHECK)\s+(\d{4})\b", re.IGNORECASE)
WIKI_MESSAGE_URL = "https://wiki.tuflow.com/TUFLOW_Message_{:04d}"


def message_url(number):
    try:
        return WIKI_MESSAGE_URL.format(int(number))
    except (TypeError, ValueError):
        return "https://wiki.tuflow.com/TUFLOW_Messages"


def read_text(path, max_bytes=None):
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            with io.open(path, "r", encoding=enc, errors="strict") as fh:
                if max_bytes:
                    size = os.path.getsize(path)
                    if size > max_bytes:
                        fh.seek(0)
                        head = fh.read(max_bytes // 2)
                        fh.seek(max(0, size - max_bytes // 2))
                        fh.readline()
                        return head + "\n...\n[file truncated for display]\n...\n" + fh.read()
                return fh.read()
        except UnicodeDecodeError:
            continue
        except (IOError, OSError):
            return ""
    return ""


# ---------------------------------------------------------------------------
class LogSummary(object):
    def __init__(self):
        self.path = ""
        self.status = "UNKNOWN"      # FINISHED | UNSTABLE | INTERRUPTED | ERROR | RUNNING | UNKNOWN
        self.errors = []             # (number, text)
        self.warnings = []
        self.checks = []
        self.nan_lines = []
        self.negative_depth_lines = 0
        self.peak_cme = None
        self.final_cme = None
        self.clock_time = ""
        self.lines = 0

    @property
    def counts(self):
        return len(self.errors), len(self.warnings), len(self.checks)


_STATUS_PATTERNS = [
    ("UNSTABLE", re.compile(r"unstable|instabilit", re.I)),
    ("INTERRUPTED", re.compile(r"interrupted|user abort|simulation stopped by", re.I)),
    ("FINISHED", re.compile(r"simulation\s+(finished|complete)|run\s+finished|finished\s+simulation", re.I)),
]


# -- line classification for the colour-coded log views ----------------------
_ZERO_COUNT = re.compile(r"\b0\s+(ERROR|WARNING|CHECK)S?\b|\b(ERROR|WARNING|CHECK)S?\b[^\d\n]{0,25}[:=]\s*0\b",
                         re.IGNORECASE)
_LINE_RULES = [
    ("ERROR", re.compile(r"\bERRORS?\b|\bFATAL\b|^\s*(error|fatal)\b|\b(error|exception)\s*:|Traceback \(most"
                         r"|\bsimulation\s+(is\s+)?(unstable|interrupted|stopped|aborted|failed)\b"
                         r"|\b(went|is|became|run)\s+unstable\b|\bUNSTABLE\b|\bNaNs?\b|\bfailed\b|"
                         r"\bcannot\s+(open|find|read)\b", re.IGNORECASE)),
    ("WARNING", re.compile(r"\bWARNINGS?\b|^\s*warning\b|\bwarning\s*:", re.IGNORECASE)),
    ("CHECK", re.compile(r"\bCHECK\s+\d{4}\b|\bCHECKS?\b(?!\s+Files)")),
    ("OK", re.compile(r"simulation\s+(finished|completed?)|run\s+(finished|complete)|finished\s+simulation|"
                      r"normal\s+termination|finished\s+successfully|successfully\s+completed", re.IGNORECASE)),
]
# commands echoed into the .tlf ('Write Check Files == ..', 'Instability Water Level == ..') are not messages
_ECHO = re.compile(r"^\s*\.*\s*[A-Za-z][A-Za-z0-9 ()/%\-]*==")
_MASS_ERROR = re.compile(r"mass\s+error|\bcum(ulative)?\s+(mass\s+)?(error|ME)\b|\berror\s*\(%\)", re.IGNORECASE)
LINE_KINDS = ("ERROR", "WARNING", "CHECK", "OK")


def classify_line(line):
    """'ERROR' | 'WARNING' | 'CHECK' | 'OK' (simulation finished) | None for a log / console line."""
    if not line or not line.strip():
        return None
    if _ECHO.match(line) and not MESSAGE_RE.search(line):
        return None
    text = line if MESSAGE_RE.search(line) else _ZERO_COUNT.sub(" ", line)     # '0 ERRORs' is good news
    for kind, rx in _LINE_RULES:
        if not rx.search(text):
            continue
        if kind == "ERROR" and _MASS_ERROR.search(text) and not re.search(r"\bERROR\s+\d{4}\b", text):
            continue
        return kind
    return None


def classify_counts(lines):
    counts = dict.fromkeys(LINE_KINDS, 0)
    for ln in lines:
        k = classify_line(ln)
        if k:
            counts[k] += 1
    return counts


def parse_tlf(path):
    """Summarise a .tlf or .hpc.tlf log."""
    s = LogSummary()
    s.path = path
    text = read_text(path)
    lines = text.splitlines()
    s.lines = len(lines)
    seen = set()
    for ln in lines:
        for m in MESSAGE_RE.finditer(ln):
            kind, num = m.group(1).upper(), m.group(2)
            item = (num, ln.strip()[:300])
            if item in seen:
                continue
            seen.add(item)
            {"ERROR": s.errors, "WARNING": s.warnings, "CHECK": s.checks}[kind].append(item)
        low = ln.lower()
        if "nan" in low.split() or " nan " in low or "nans" in low:
            s.nan_lines.append(ln.strip()[:300])
        if re.search(r"(^|\s)-d\s+\d", ln):
            s.negative_depth_lines += 1
        m = re.search(r"peak\s+cumulative\s+(?:mass\s+)?(?:error|me)[^-\d]*(-?\d+(?:\.\d+)?)\s*%", ln, re.I)
        if m:
            s.peak_cme = float(m.group(1))
        m = re.search(r"final\s+cumulative\s+(?:mass\s+)?(?:error|me)[^-\d]*(-?\d+(?:\.\d+)?)\s*%", ln, re.I)
        if m:
            s.final_cme = float(m.group(1))
        m = re.search(r"clock\s*time[^:=]*[:=]\s*(.+)$", ln, re.I)
        if m:
            s.clock_time = m.group(1).strip()
    tail = "\n".join(lines[-80:])
    for status, pat in _STATUS_PATTERNS:
        if pat.search(tail):
            s.status = status
            break
    if s.status == "UNKNOWN":
        if s.errors:
            s.status = "ERROR"
        elif lines:
            s.status = "RUNNING / INCOMPLETE"
    return s


# ---------------------------------------------------------------------------
def read_csv_table(path):
    """Return (header, rows) with numbers converted where possible."""
    header, rows = [], []
    try:
        with io.open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
            rdr = csv.reader(fh)
            for r in rdr:
                if not header:
                    if any(c.strip() for c in r):
                        header = [c.strip() for c in r]
                    continue
                rows.append([_to_num(c) for c in r])
    except (IOError, OSError):
        pass
    return header, rows


def _to_num(c):
    c = c.strip()
    try:
        return float(c)
    except ValueError:
        return c


def column(header, rows, *names):
    """Find the first column whose header contains any of `names` (case-insensitive)."""
    lower = [h.lower() for h in header]
    for n in names:
        n = n.lower()
        for i, h in enumerate(lower):
            if h == n:
                return i, [r[i] for r in rows if i < len(r) and isinstance(r[i], float)]
    for n in names:
        n = n.lower()
        for i, h in enumerate(lower):
            if n in h:
                return i, [r[i] for r in rows if i < len(r) and isinstance(r[i], float)]
    return None, []


class MassBalance(object):
    def __init__(self, path):
        self.path = path
        self.header, self.rows = read_csv_table(path)
        ti, self.time = column(self.header, self.rows, "time (h)", "time")
        ci, self.cum_me = column(self.header, self.rows, "cum me (%)", "cme (%)", "cum me", "cme")
        ei, self.me = column(self.header, self.rows, "me (%)", "mass error (%)")
        _, self.q_in = column(self.header, self.rows, "q in", "qin", "total inflow")
        _, self.vol = column(self.header, self.rows, "vol i", "volume", "vol")

    @property
    def ok(self):
        return bool(self.cum_me)

    def peak_abs_cme(self, ignore_first_fraction=0.0):
        vals = self.cum_me
        if not vals:
            return None
        start = int(len(vals) * ignore_first_fraction)
        vals = vals[start:] or vals
        return max(vals, key=abs)

    def final_cme(self):
        return self.cum_me[-1] if self.cum_me else None


class HpcTimestep(object):
    def __init__(self, path):
        self.path = path
        self.header, self.rows = read_csv_table(path)
        _, self.time = column(self.header, self.rows, "time (h)", "time")
        _, self.dt = column(self.header, self.rows, "dt (s)", "timestep", "dt")
        _, self.nu = column(self.header, self.rows, "nu")
        _, self.nc = column(self.header, self.rows, "nc")
        _, self.nd = column(self.header, self.rows, "nd")
        ri, self.repeats = column(self.header, self.rows, "repeat")

    @property
    def ok(self):
        return bool(self.dt)

    def stats(self):
        if not self.dt:
            return {}
        srt = sorted(self.dt)
        med = srt[len(srt) // 2]
        return {
            "min_dt": srt[0], "max_dt": srt[-1], "median_dt": med,
            "repeats": sum(1 for r in self.repeats if r and r > 0) if self.repeats else 0,
            "max_nu": max(self.nu) if self.nu else None,
            "max_nc": max(self.nc) if self.nc else None,
            "max_nd": max(self.nd) if self.nd else None,
            "dt_drops": sum(1 for d in self.dt if med and d < 0.1 * med),
        }


# ---------------------------------------------------------------------------
def read_messages(path):
    """Messages layer as list of dicts: number, type, text, x, y."""
    out = []
    if not path or not os.path.exists(path):
        return out
    if path.lower().endswith(".csv"):
        header, rows = read_csv_table(path)
        low = [h.lower() for h in header]

        def idx(*names):
            for n in names:
                for i, h in enumerate(low):
                    if n in h:
                        return i
            return None
        i_num, i_type, i_txt = idx("number", "id"), idx("type", "category"), idx("text", "message", "description")
        i_x, i_y = idx("x"), idx("y")
        for r in rows:
            g = lambda i: (r[i] if i is not None and i < len(r) else "")
            out.append({"number": g(i_num), "type": str(g(i_type)), "text": str(g(i_txt)), "x": g(i_x), "y": g(i_y)})
        return out
    if path.lower().endswith(".gpkg"):
        try:
            con = sqlite3.connect("file:{}?mode=ro".format(path.replace("\\", "/")), uri=True)
            try:
                tables = [r[0] for r in con.execute("SELECT table_name FROM gpkg_contents")]
                for t in tables:
                    cols = [c[1] for c in con.execute('PRAGMA table_info("{}")'.format(t))]
                    low = [c.lower() for c in cols]
                    pick = lambda *ns: next((cols[i] for n in ns for i, c in enumerate(low) if n in c), None)
                    cn, ct, cx = pick("number", "id"), pick("type"), pick("text", "message")
                    if not cx:
                        continue
                    sel = ", ".join('"{}"'.format(c) if c else "NULL" for c in (cn, ct, cx))
                    for n, ty, tx in con.execute('SELECT {} FROM "{}"'.format(sel, t)):
                        out.append({"number": n, "type": ty or "", "text": tx or "", "x": "", "y": "", "layer": t})
            finally:
                con.close()
        except Exception:
            pass
    return out


def read_sim_register(path):
    """Parse '_ TUFLOW Simulations.log' into a list of rows (raw text split on tabs/commas)."""
    rows = []
    for ln in read_text(path).splitlines():
        ln = ln.strip()
        if not ln:
            continue
        parts = [p.strip() for p in re.split(r"\t|\s{2,}", ln) if p.strip()]
        rows.append(parts)
    return rows


def read_tsf(path):
    """TUFLOW summary file: 'key == value' lines -> dict."""
    out = {}
    for ln in read_text(path).splitlines():
        if "==" in ln:
            k, v = ln.split("==", 1)
            out[k.strip()] = v.strip()
        elif ":" in ln:
            k, v = ln.split(":", 1)
            out.setdefault(k.strip(), v.strip())
    return out


# ---------------------------------------------------------------------------
class RunFiles(object):
    """Find the output files of a simulation by name."""

    def __init__(self, sim_name, log_dir, results_dir, check_dir):
        self.sim = sim_name
        self.log_dir, self.results_dir, self.check_dir = log_dir, results_dir, check_dir

    def _g(self, folder, pattern):
        if not folder or not os.path.isdir(folder):
            return []
        return sorted(glob.glob(os.path.join(folder, pattern)), key=os.path.getmtime, reverse=True)

    def _first(self, folder, *patterns):
        for p in patterns:
            hits = self._g(folder, p)
            if hits:
                return hits[0]
        return None

    @property
    def tlf(self):
        return self._first(self.log_dir, self.sim + ".tlf", self.sim + "*.tlf")

    @property
    def hpc_tlf(self):
        return self._first(self.log_dir, self.sim + ".hpc.tlf", self.sim + "*.hpc.tlf")

    @property
    def hpc_dt(self):
        return self._first(self.log_dir, self.sim + "*hpc.dt.csv", self.sim + "*dt.csv")

    @property
    def tsf(self):
        return self._first(self.log_dir, self.sim + "*.tsf")

    @property
    def messages(self):
        return self._first(self.log_dir, self.sim + "_messages.csv", self.sim + "_messages.gpkg",
                           self.sim + "*messages*.gpkg", self.sim + "_messages.shp", self.sim + "_messages.mif")

    @property
    def mass_balance(self):
        return self._first(self.results_dir, self.sim + "_MB.csv", self.sim + "*_MB.csv", os.path.join("**", self.sim + "_MB.csv"))

    @property
    def mass_balance_2d(self):
        return self._first(self.results_dir, self.sim + "_MB2D.csv", self.sim + "*_MB2D.csv")

    def result_grids(self):
        pats = ["{}*.tif".format(self.sim), "{}*.asc".format(self.sim), "{}*.flt".format(self.sim),
                os.path.join("grids", "{}*.tif".format(self.sim))]
        out = []
        for p in pats:
            out += self._g(self.results_dir, p)
        return out

    def xmdf(self):
        return self._g(self.results_dir, self.sim + "*.xmdf")

    def po_csv(self):
        return self._g(self.results_dir, os.path.join("plot", "csv", self.sim + "*_PO.csv")) + \
            self._g(self.results_dir, self.sim + "*_PO.csv")

    def check_layers(self):
        out = []
        for ext in ("gpkg", "shp", "mif", "tif", "asc", "flt", "csv"):
            out += self._g(self.check_dir, "{}_*.{}".format(self.sim, ext))
            out += self._g(self.check_dir, "{}*.{}".format(self.sim, ext)) if ext == "gpkg" else []
        seen, uniq = set(), []
        for p in out:
            if p not in seen:
                seen.add(p)
                uniq.append(p)
        return uniq


def list_simulations(log_dir):
    """Simulation names that have a .tlf in the log folder (newest first)."""
    if not log_dir or not os.path.isdir(log_dir):
        return []
    files = sorted(glob.glob(os.path.join(log_dir, "*.tlf")), key=os.path.getmtime, reverse=True)
    names = []
    for f in files:
        b = os.path.basename(f)
        if b.lower().endswith(".hpc.tlf"):
            continue
        n = b[:-4]
        if n not in names:
            names.append(n)
    return names


# ---------------------------------------------------------------------------
CHECK_FILE_INFO = {
    "_input_layers": "All GIS layers read by the model",
    "_grd_check": "2D cell properties (code, elevations, materials)",
    "_zpt_check": "Final 2D Zpt elevations",
    "_uvpt_check": "Velocity point properties",
    "_DEM_Z": "DEM of final 2D elevations",
    "_DEM_M": "Material IDs as a grid",
    "_bcc_check": "Cells with 2D boundary conditions",
    "_sac_check": "Source-area cells and inflow distribution",
    "_fc_check": "Flow constriction attributes",
    "_1d_to_2d_check": "1D/2D link cells (HX/SX)",
    "_2d_to_2d_check": "2D/2D domain links",
    "_nwk_C_check": "1D channel properties",
    "_nwk_N_check": "1D node properties",
    "_hydprop_check": "1D hydraulic property tables",
    "_inverts_check": "1D inverts",
    "_iwl_check": "Initial water levels",
    "_po_check": "Plot output locations",
    "_messages": "Errors / warnings / checks with locations",
}


def describe_check_file(path):
    b = os.path.basename(path)
    for k, v in CHECK_FILE_INFO.items():
        if k.lower() in b.lower():
            return v
    return ""


# ---------------------------------------------------------------------------
class StabilityReport(object):
    """Combine log, MB and dt info into flags."""

    def __init__(self, cme_warn=1.0, cme_error=3.0):
        self.cme_warn = cme_warn
        self.cme_error = cme_error
        self.flags = []      # (severity, text, url)

    def evaluate(self, tlf=None, hpc=None, mb=None, dt=None):
        f = self.flags = []
        if tlf is not None:
            e, w, c = tlf.counts
            if tlf.status == "FINISHED":
                f.append(("PASS", "Simulation finished.", ""))
            elif tlf.status == "UNSTABLE":
                f.append(("ERROR", "Log reports the simulation went UNSTABLE.",
                          "https://wiki.tuflow.com/TUFLOW_Modelling_Guidance"))
            elif tlf.status == "INTERRUPTED":
                f.append(("WARNING", "Simulation was interrupted.", ""))
            elif tlf.status == "ERROR":
                f.append(("ERROR", "Simulation stopped with errors ({}).".format(e), "https://wiki.tuflow.com/TUFLOW_Messages"))
            else:
                f.append(("INFO", "Status: {}".format(tlf.status), ""))
            if e:
                f.append(("ERROR", "{} ERROR message(s) in the log.".format(e), "https://wiki.tuflow.com/TUFLOW_Messages"))
            if w:
                f.append(("WARNING", "{} WARNING message(s) - review each one.".format(w), "https://wiki.tuflow.com/TUFLOW_Messages"))
            if c:
                f.append(("INFO", "{} CHECK message(s).".format(c), "https://wiki.tuflow.com/TUFLOW_Messages"))
            if tlf.nan_lines:
                f.append(("ERROR", "NaN values reported ({} lines) - numerical instability.".format(len(tlf.nan_lines)),
                          message_url(2550)))
            if tlf.negative_depth_lines:
                f.append(("WARNING", "Negative depths reported on {} log lines (Classic '-d').".format(tlf.negative_depth_lines),
                          "https://wiki.tuflow.com/TUFLOW_Modelling_Guidance"))
        if hpc is not None and hpc.nan_lines:
            f.append(("ERROR", "HPC log reports NaNs ({} lines).".format(len(hpc.nan_lines)), message_url(2550)))
        cme = None
        if mb is not None and mb.ok:
            cme = mb.peak_abs_cme(ignore_first_fraction=0.05)
        elif tlf is not None and tlf.peak_cme is not None:
            cme = tlf.peak_cme
        if cme is not None:
            a = abs(cme)
            if a > self.cme_error:
                f.append(("ERROR", "Peak cumulative mass error {:.2f}% (> {:g}%).".format(cme, self.cme_error),
                          "https://wiki.tuflow.com/TUFLOW_Modelling_Guidance"))
            elif a > self.cme_warn:
                f.append(("WARNING", "Peak cumulative mass error {:.2f}% (target within +/-{:g}%).".format(cme, self.cme_warn),
                          "https://wiki.tuflow.com/TUFLOW_Modelling_Guidance"))
            else:
                f.append(("PASS", "Peak cumulative mass error {:.2f}% is within +/-{:g}%.".format(cme, self.cme_warn), ""))
        if dt is not None and dt.ok:
            st = dt.stats()
            n_before = len(f)
            if st.get("repeats"):
                f.append(("WARNING", "{} repeated timesteps - check where control numbers were exceeded.".format(st["repeats"]),
                          manual_url_hpc()))
            if st.get("dt_drops"):
                f.append(("WARNING", "Timestep fell below 10% of its median {} times (min {:.4g} s, median {:.4g} s) - "
                          "look for a local hot-spot.".format(st["dt_drops"], st["min_dt"], st["median_dt"]), manual_url_hpc()))
            for k, lim in (("max_nu", 1.0), ("max_nc", 1.0), ("max_nd", 0.3)):
                v = st.get(k)
                if v is not None and v > lim * 1.001:
                    f.append(("WARNING", "{} reached {:.3g} (limit {:g}).".format(k.replace("max_", "").upper(), v, lim),
                              manual_url_hpc()))
            if len(f) == n_before:
                f.append(("PASS", "HPC timestep: min {:.4g} s, median {:.4g} s, max {:.4g} s.".format(
                    st["min_dt"], st["median_dt"], st["max_dt"]), ""))
        return f


def manual_url_hpc():
    from . import catalog_data as cd
    return cd.MANUAL_ROOT + "03-Hydraulic-Modelling-Fundamentals.html"
