# -*- coding: utf-8 -*-
"""
Flood Modeller (Jacobs) -> TUFLOW model conversion.

    net = Network(fm_project.dat, report).build()
    result = convert(fm_project, options)

What is converted
-----------------
1D (choose one):
  * "estry"  - the Flood Modeller network becomes an ESTRY 1D model: river sections -> 'S' channels
               with XZ cross-section tables (Manning's n per point), conduits -> 'C' / 'R' culverts,
               spills / weirs / sluices -> 'W' weirs, bridges -> 'S' channels through the bridge opening,
               junctions / loss units -> shared nodes, QT / HT / QH boundaries -> 1d_bc + bc_dbase.
  * "linked" - Flood Modeller keeps the 1D and TUFLOW runs the 2D: 1d_x1d node layer, HX / CN links and a
               copy of the event file (.ief) pointing at the new TCF.
2D (from the Flood Modeller 2D .xml when there is one, otherwise a domain around the river):
  grid origin / size / rotation / cell size, active area (2d_code), DTMs (Read Grid Zpts), roughness
  (materials + 2d_mat), initial water level, boundaries (2d_bc / 2d_sa + bc_dbase), times and output.
1D / 2D link: HX lines from the Flood Modeller link shapefile or generated along both banks from the
  section ends, with CN lines to the nodes.

Everything that could not be converted exactly is listed in the import report.
"""
import csv
import io
import math
import os
import re
import shutil

from . import floodmodeller as fm
from . import empty_layers as EL
from .catalog import catalog
from .control_file import ControlFile, Entry, to_tuflow_path
from .domain import Domain, from_box, fmt
from .project import TuflowProject, BC_DBASE_HEADER, MATERIALS_HEADER

REACH_UNITS = {"RIVER", "INTERPOLATE", "REPLICATE", "CONDUIT"}
LOSS_UNITS = {"BERNOULLI", "LOSS", "CULVERT", "BLOCKAGE", "GAUGE"}
WEIR_UNITS = set(fm.WEIR_FIELDS) | {"SPILL", "FLOODPLAIN", "LABYRINTH WEIR"}
LATERAL_UNITS = {"LATERAL", "ABSTRACTION", "RESERVOIR", "POND"}
BOUNDARY_TYPES = {"QTBDY": "QT", "HTBDY": "HT", "QHBDY": "HQ"}
SUGGEST = {
    "SLUICE": "an 'SG' sluice-gate channel with the gate operation",
    "ORIFICE": "a culvert with the right losses",
    "OCPUMP": "a 'P' pump channel",
    "QH CONTROL": "an 'M' or 'Q' channel with the rating",
    "QRATING": "an HQ boundary or 'Q' channel",
    "SYPHON": "a culvert ('C' / 'R') channel",
    "INVERTED SYPHON": "a culvert ('C' / 'R') channel",
    "OUTFALL": "a culvert with a flap gate (Flags 'U')",
    "FLOOD RELIEF": "a culvert with a flap gate (Flags 'U')",
    "BREACH": "a 2D variable Z shape (2d_vzsh) breach",
    "MANHOLE": "a 1d_nwk manhole node",
}
FM_MAP_TYPES = {"depth": "d", "velocity": "V", "speed": "V", "elevation": "h", "stage": "h",
                "waterlevel": "h", "flow": "q", "unitflow": "q", "hazard": "ZUK0", "hazardrating": "ZUK0"}
FM_BC_TYPES = {"waterelevation": "HT", "waterlevel": "HT", "elevation": "HT", "totalflow": "QT", "flow": "QT",
               "verticalflow": "SA", "freeflow": "HQ", "normaldepth": "HQ", "headdischarge": "HQ"}
GAP = 2.0          # m - nodes of a structure that share one location are pulled apart by this much


# ---------------------------------------------------------------------------
class Report(object):
    """What the import did. level: done | info | review | todo"""
    TITLES = {"done": "Converted", "info": "Notes", "review": "Check these", "todo": "You need to finish these"}

    def __init__(self):
        self.items = []

    def add(self, level, area, text):
        self.items.append((level, area, text))

    def done(self, area, text):
        self.add("done", area, text)

    def info(self, area, text):
        self.add("info", area, text)

    def review(self, area, text):
        self.add("review", area, text)

    def todo(self, area, text):
        self.add("todo", area, text)

    def count(self, level):
        return sum(1 for i in self.items if i[0] == level)

    def of(self, level):
        return [i for i in self.items if i[0] == level]

    def text(self, title="Flood Modeller import"):
        out = [title, "=" * len(title), ""]
        for lv in ("todo", "review", "done", "info"):
            rows = self.of(lv)
            if not rows:
                continue
            out.append("{} ({})".format(self.TITLES[lv], len(rows)))
            out.append("-" * len(out[-1]))
            for _l, area, text in rows:
                out.append("  [{}] {}".format(area, text))
            out.append("")
        return "\n".join(out)


def _say(n, word, plural=None):
    return "{} {}".format(n, word if n == 1 else (plural or word + "s"))


def _names(items, n=6):
    items = list(items)
    s = ", ".join(items[:n])
    return s + (" and {} more".format(len(items) - n) if len(items) > n else "")


def tuflow_id(label):
    """TUFLOW IDs: no spaces or quotes."""
    s = re.sub(r"[\s,'\"|]+", "_", (label or "").strip())
    return s or "node"


def file_stem(label):
    return re.sub(r"[^\w.\-]+", "_", label or "x").strip("._") or "x"


# ---------------------------------------------------------------------------
# geometry
def _dist(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _unit(a, b):
    d = _dist(a, b)
    return ((b[0] - a[0]) / d, (b[1] - a[1]) / d) if d > 1e-9 else (1.0, 0.0)


def _nearest_on_line(pts, p):
    """(distance, segment index, point) of the point of polyline `pts` nearest to p."""
    best = None
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L2 = dx * dx + dy * dy
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
        q = (a[0] + t * dx, a[1] + t * dy)
        d = _dist(p, q)
        if best is None or d < best[0]:
            best = (d, i, q)
    return best


def _wkt_line(pts):
    return "LINESTRING({})".format(", ".join("{!r} {!r}".format(float(x), float(y)) for x, y in pts))


def _wkt_point(p):
    return "POINT({!r} {!r})".format(float(p[0]), float(p[1]))


def _wkt_poly(pts):
    ring = list(pts) + [pts[0]]
    return "POLYGON(({}))".format(", ".join("{!r} {!r}".format(float(x), float(y)) for x, y in ring))


# ---------------------------------------------------------------------------
class Node(object):
    def __init__(self, nid, label):
        self.id = nid                 # TUFLOW ID
        self.label = label            # Flood Modeller label (canonical)
        self.labels = [label]
        self.xy = None
        self.placed = ""              # '' = real coordinates, 'interpolated', 'schematic'
        self.section = None           # fm.Section (or a derived copy)
        self.derived = ""             # how a derived section was made
        self.bed = None

    def __repr__(self):
        return "Node({} {})".format(self.id, self.xy)


class Link(object):
    def __init__(self, lid, us, ds, ltype, length, unit, reach=False):
        self.id = lid
        self.us = us                  # Node
        self.ds = ds
        self.type = ltype             # S, C, R, W
        self.length = length
        self.unit = unit
        self.reach = reach
        self.attrs = {}
        self.section = None           # own XZ table (bridge opening)

    def __repr__(self):
        return "Link({} {} {}->{})".format(self.id, self.type, self.us.id, self.ds.id)


class Network(object):
    """The Flood Modeller 1D network as nodes and links."""

    def __init__(self, dat, report=None, keep_labels=False):
        self.dat = dat
        self.report = report or Report()
        self.keep_labels = keep_labels        # linked mode: IDs must equal the Flood Modeller labels
        self.parent = {}
        self.nodes = {}                        # canonical label -> Node
        self.links = []
        self.boundaries = []                   # (Node, type, unit)
        self.chains = []                       # [[Link, ...]] runs of reach channels
        self.joined = {}                       # unit kind -> [labels]
        self.skipped = {}                      # unit kind -> [labels]

    # -- union-find on labels ------------------------------------------------
    def find(self, a):
        self.parent.setdefault(a, a)
        while self.parent[a] != a:
            self.parent[a] = self.parent[self.parent[a]]
            a = self.parent[a]
        return a

    def union(self, a, b):
        if not a or not b:
            return
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra

    def node(self, label):
        c = self.find(label)
        n = self.nodes.get(c)
        if n is None:
            n = self.nodes[c] = Node(c if self.keep_labels else tuflow_id(c), c)
        if label not in n.labels:
            n.labels.append(label)
        return n

    # -- build -----------------------------------------------------------------
    def build(self):
        units = [u for u in self.dat.units if u.labels]
        # 1. labels that are one water level
        for u in units:
            if u.kind == "RIVER" and u.subtype == "SECTION":
                for l in u.labels[1:]:                 # spill / lateral labels are aliases of the node
                    self.union(u.labels[0], l)
            elif u.kind == "JUNCTION":
                for l in u.labels[1:]:
                    self.union(u.labels[0], l)
            elif u.kind in LOSS_UNITS and len(u.labels) >= 2:
                self.union(u.labels[0], u.labels[1])
                self.joined.setdefault(u.kind, []).append(u.label)
        # 2. links
        used_ids = set()

        def lid(label, suffix=""):
            base = (label if self.keep_labels else tuflow_id(label)) + suffix
            i, out = 1, base
            while out in used_ids:
                i += 1
                out = "{}_{}".format(base, i)
            used_ids.add(out)
            return out

        convertible = WEIR_UNITS | {"BRIDGE", "ORIFICE"}
        for i, u in enumerate(units):
            if u.kind in REACH_UNITS and u.dist > 0 and i + 1 < len(units):
                nxt = units[i + 1]
                us, ds = self.node(u.labels[0]), self.node(nxt.labels[0])
                if us is ds:
                    continue
                ltype = "S"
                if u.kind == "CONDUIT":
                    ltype = {"CIRCULAR": "C"}.get(u.subtype, "R")
                link = Link(lid(u.labels[0]), us, ds, ltype, u.dist, u, reach=(u.kind != "CONDUIT"))
                if u.kind == "CONDUIT":
                    self._conduit(link, u, nxt)
                self.links.append(link)
            elif u.kind in convertible and len(u.labels) >= 2:
                us, ds = self.node(u.labels[0]), self.node(u.labels[1])
                if us is ds:
                    continue
                link = Link(lid(u.labels[0]), us, ds, "W", 0.0, u)
                self._structure(link, u)
                self.links.append(link)
            elif u.kind in fm.STRUCTURE_UNITS and u.kind not in LOSS_UNITS and len(u.labels) >= 2:
                # no ESTRY equivalent written - keep the network connected
                self.union(u.labels[0], u.labels[1])
                self.skipped.setdefault(u.kind, []).append(u.label)
            else:
                for l in u.labels[:1]:
                    self.node(l)
        # re-point links at merged nodes (unions made after the link was created)
        for link in self.links:
            link.us = self.node(link.us.label)
            link.ds = self.node(link.ds.label)
        self.links = [l for l in self.links if l.us is not l.ds]
        for c in list(self.nodes):
            if self.find(c) != c:
                keep = self.nodes[self.find(c)]
                for l in self.nodes[c].labels:
                    if l not in keep.labels:
                        keep.labels.append(l)
                del self.nodes[c]
        self._sections(units)
        self._locate()
        self._separate()
        self._chains()
        self._boundaries()
        return self

    def _conduit(self, link, u, nxt):
        p = u.params
        inv = p.get("invert")
        ds_inv = nxt.params.get("invert") if nxt.kind == "CONDUIT" and nxt.params.get("invert") is not None else inv
        a = link.attrs
        a.update({"Len_or_ANA": u.dist, "n_nF_Cd": p.get("n") or 0.015, "US_Invert": inv if inv is not None else -99999,
                  "DS_Invert": ds_inv if ds_inv is not None else -99999, "Number_of": 1, "HConF_or_WC": 0.6,
                  "WConF_or_WEx": 0.9, "EntryC_or_WSa": 0.5, "ExitC_or_WSb": 1.0})
        if u.subtype == "CIRCULAR":
            a["Width_or_Dia"] = p.get("diameter") or 0.0
        else:
            a["Width_or_Dia"] = p.get("width") or 0.0
            a["Height_or_WF"] = p.get("height") or 0.0
        if u.subtype not in ("CIRCULAR", "RECTANGULAR"):
            what = "approximated as a box culvert" if p.get("width") else "written as a 1 m box placeholder"
            if not p.get("width"):
                a["Width_or_Dia"], a["Height_or_WF"] = 1.0, 1.0
            self.report.review("1D culverts", "Conduit {} ({}) {} - set the real size, or use an 'I' "
                                              "(irregular) culvert with a CS table.".format(u.label, u.subtype.lower(), what))
        if not p.get("n"):
            self.report.review("1D culverts", "Conduit {}: friction not in Manning's n - 0.015 used.".format(u.label))

    def _structure(self, link, u):
        a = link.attrs
        if u.kind in ("SPILL", "FLOODPLAIN"):
            prof = u.params.get("profile") or []
            if prof:
                xs = [p[0] for p in prof]
                width = max(xs) - min(xs) if len(prof) > 1 else 0.0
                if width <= 0 and all(p[2] is not None and p[3] is not None for p in prof):
                    width = sum(_dist((prof[k][2], prof[k][3]), (prof[k + 1][2], prof[k + 1][3]))
                                for k in range(len(prof) - 1))
                crest = min(p[1] for p in prof)
            else:
                width, crest = 0.0, None
            link.type = "W"
            a.update({"Width_or_Dia": width or 1.0, "US_Invert": crest if crest is not None else -99999,
                      "DS_Invert": crest if crest is not None else -99999, "n_nF_Cd": 1.0})
            link.profile = prof
            if prof and max(p[1] for p in prof) - crest > 0.05:
                self.report.review("1D weirs", "{} {} -> weir at the lowest crest {} m over {} m; the crest varies "
                                               "by {} m - consider a 'VW' weir or modelling the overflow in 2D."
                                   .format(u.kind.title(), u.label, fmt(crest), fmt(width or 1.0),
                                           fmt(max(p[1] for p in prof) - crest)))
        elif u.kind in fm.WEIR_FIELDS or u.kind == "LABYRINTH WEIR":
            b, z = u.params.get("breadth"), u.params.get("crest")
            link.type = "W"
            a.update({"Width_or_Dia": b or 1.0, "US_Invert": z if z is not None else -99999,
                      "DS_Invert": z if z is not None else -99999, "n_nF_Cd": 1.0})
            if b is None or z is None:
                self.report.todo("1D weirs", "{} {}: breadth / crest not read - set Width_or_Dia and the "
                                             "inverts of weir {}.".format(u.kind.title(), u.label, link.id))
            if u.kind == "SLUICE":
                self.report.review("1D structures", "Sluice {} -> weir at the sill (gate open). Use {} if the gate "
                                                    "operates.".format(u.label, SUGGEST["SLUICE"]))
            elif u.kind not in ("WEIR", "RNWEIR", "SPILL"):
                self.report.review("1D weirs", "{} {} -> standard weir; check the coefficient.".format(u.kind.title(),
                                                                                                         u.label))
        elif u.kind == "ORIFICE":
            inv, sof, area = u.params.get("invert"), u.params.get("soffit"), u.params.get("area")
            circ = (u.params.get("shape") or "").upper().startswith("CIRC")
            link.type = "C" if circ else "R"
            h = (sof - inv) if inv is not None and sof is not None and sof > inv else None
            if circ:
                dia = math.sqrt(4 * area / math.pi) if area else (h or 1.0)
                a["Width_or_Dia"] = dia
            else:
                a["Height_or_WF"] = h or 1.0
                a["Width_or_Dia"] = (area / h) if area and h else 1.0
            a.update({"Len_or_ANA": 5.0, "n_nF_Cd": 0.015, "US_Invert": inv if inv is not None else -99999,
                      "DS_Invert": inv if inv is not None else -99999, "Number_of": 1, "EntryC_or_WSa": 0.5,
                      "ExitC_or_WSb": 1.0, "HConF_or_WC": 0.6, "WConF_or_WEx": 0.9})
            if u.subtype == "FLAPPED":
                a["Flags"] = "U"
            self.report.review("1D structures", "Orifice {} -> 5 m {} culvert; check the length and losses."
                               .format(u.label, "circular" if circ else "box"))
        elif u.kind == "BRIDGE":
            link.type = "S"
            link.section = u.params.get("section") or None
            a.update({"Len_or_ANA": 10.0, "n_nF_Cd": 1.0, "US_Invert": -99999, "DS_Invert": -99999})
            self.report.review("1D bridges", "Bridge {} ({}) -> 10 m open channel through the bridge opening{}. "
                                             "Add the deck as a 'BB' channel or a 2d_lfcsh layer if it can surcharge."
                               .format(u.label, u.subtype.lower(), "" if link.section else
                                       " (opening not read - uses the upstream section)"))

    # -- cross-sections ----------------------------------------------------------
    def _sections(self, units):
        last, last_i = None, -1        # previous section of the reach and its unit index
        for i, u in enumerate(units):
            if u.kind == "RIVER" and u.subtype == "SECTION" and u.data:
                n = self.node(u.labels[0])
                if n.section is None:
                    n.section = u
                    n.bed = u.bed_level()
                last, last_i = u, i
            elif u.kind == "REPLICATE" and last is not None:
                drop = u.params.get("bed_drop") or 0.0
                n = self.node(u.labels[0])
                n.section = _shifted(last, -drop, u.labels[0])
                n.derived = "copy of {} lowered {} m".format(last.label, fmt(drop))
                n.bed = n.section.bed_level()
                last, last_i = n.section, i
            elif u.kind == "INTERPOLATE" and last is not None:
                run = sum(units[m].dist for m in range(last_i, i))
                tot, nxt, j = run, None, i
                while j < len(units) and units[j].kind in REACH_UNITS:
                    if units[j].kind == "RIVER" and units[j].subtype == "SECTION":
                        nxt = units[j]
                        break
                    tot += units[j].dist
                    j += 1
                n = self.node(u.labels[0])
                b0 = last.bed_level()
                b1 = nxt.bed_level() if nxt is not None else None
                if nxt is not None and tot > 0 and b0 is not None and b1 is not None:
                    n.section = _shifted(last, (b1 - b0) * run / tot, u.labels[0])
                    n.derived = "interpolated between {} and {}".format(last.label, nxt.label)
                else:
                    n.section = _shifted(last, 0.0, u.labels[0])
                    n.derived = "copy of {}".format(last.label)
                n.bed = n.section.bed_level()
            if u.kind not in REACH_UNITS or u.dist <= 0:
                if u.kind not in BOUNDARY_TYPES:
                    last, last_i = None, -1

    # -- coordinates ----------------------------------------------------------
    def _locate(self):
        dat = self.dat
        for n in self.nodes.values():
            for l in n.labels:
                xy = dat.node_xy(l)
                if xy:
                    n.xy = xy
                    break
        adj = {}
        for l in self.links:
            adj.setdefault(l.us.label, []).append((l.ds, l.length or 10.0))
            adj.setdefault(l.ds.label, []).append((l.us, l.length or 10.0))
        missing = [n for n in self.nodes.values() if n.xy is None and n.label in adj]
        if not missing:
            return
        if len(missing) < len([n for n in self.nodes.values() if n.label in adj]):
            downs, ups = {}, {}
            for l in self.links:
                downs.setdefault(l.us.label, []).append((l, l.ds))
                ups.setdefault(l.ds.label, []).append((l, l.us))

            def walk(n, table):
                cur, d, seen = n, 0.0, {n.label}
                while True:
                    nxt = table.get(cur.label, [])
                    if len(nxt) != 1:
                        return None
                    l, m = nxt[0]
                    d += l.length or 10.0
                    if m.xy is not None and not m.placed:
                        return m, d
                    if m.label in seen:
                        return None
                    seen.add(m.label)
                    cur = m

            for n in missing:                  # runs of nodes between two located nodes
                up, dn = walk(n, ups), walk(n, downs)
                if up and dn:
                    (a, la), (b, lb) = up, dn
                    f = la / (la + lb) if la + lb > 0 else 0.5
                    n.xy = (a.xy[0] + (b.xy[0] - a.xy[0]) * f, a.xy[1] + (b.xy[1] - a.xy[1]) * f)
                    n.placed = "interpolated"
            changed = True
            while changed:
                changed = False
                # continue a branch past its last located node, along the reach direction
                for n in missing:
                    if n.xy is None:
                        known = [(m, L) for m, L in adj.get(n.label, []) if m.xy is not None]
                        if known:
                            a, la = known[0]
                            d = (1.0, 0.0)
                            for m, _L in adj.get(a.label, []):
                                if m.xy is not None and m is not n:
                                    d = _unit(m.xy, a.xy)
                                    break
                            n.xy = (a.xy[0] + d[0] * la, a.xy[1] + d[1] * la)
                            n.placed = "schematic"
                            changed = True
            placed = [n.label for n in missing if n.placed == "interpolated"]
            if placed:
                self.report.review("1D locations", "{} placed between their neighbours (no coordinates in the "
                                                   "model): {}.".format(_say(len(placed), "node"), _names(placed)))
        rest = [n for n in missing if n.xy is None or n.placed == "schematic"]
        if rest:
            self._schematic([n for n in rest if n.xy is None], adj)
            self.report.todo("1D locations", "{} had no coordinates (no section easting/northing, .gxy or GISINFO) "
                                             "and were laid out schematically - move them onto the river in QGIS: {}."
                             .format(_say(len(rest), "node"), _names([n.label for n in rest])))

    def _schematic(self, rest, adj):
        """Lay out nodes without any coordinates: chainage along X, one row per branch."""
        if not rest:
            return
        known = [n.xy for n in self.nodes.values() if n.xy is not None]
        x0 = max((p[0] for p in known), default=0.0) + (500.0 if known else 0.0)
        y0 = min((p[1] for p in known), default=0.0)
        downs = {}
        ups = {}
        for l in self.links:
            downs.setdefault(l.us.label, []).append(l)
            ups.setdefault(l.ds.label, []).append(l)
        todo = set(n.label for n in rest)
        row = 0
        order = [n for n in rest if not any(l.us.label in todo for l in ups.get(n.label, []))] or rest[:1]
        while todo:
            start = next((n for n in order if n.label in todo), None)
            if start is None:
                start = self.nodes[self.find(sorted(todo)[0])]
            x = x0
            n = start
            while n is not None and n.label in todo:
                n.xy = (x, y0 - row * 200.0)
                n.placed = "schematic"
                todo.discard(n.label)
                nxt = None
                for l in downs.get(n.label, []):
                    if l.ds.label in todo:
                        x += max(l.length or 0.0, 20.0)
                        nxt = l.ds
                        break
                n = nxt
            row += 1

    def _separate(self):
        """Nodes on top of each other (structures) are pulled apart along the flow direction."""
        seen = {}
        for l in self.links:
            for n in (l.us, l.ds):
                if n.xy is None:
                    continue
                key = (round(n.xy[0], 2), round(n.xy[1], 2))
                other = seen.get(key)
                if other is None:
                    seen[key] = n
                elif other is not n:
                    d = self._direction(n)
                    k = 1
                    while True:
                        xy = (n.xy[0] + d[0] * GAP * k, n.xy[1] + d[1] * GAP * k)
                        key2 = (round(xy[0], 2), round(xy[1], 2))
                        if key2 not in seen:
                            break
                        k += 1
                    n.xy = xy
                    seen[key2] = n

    def _direction(self, n):
        for l in self.links:
            if l.us is n and l.ds.xy and _dist(l.ds.xy, n.xy) > GAP:
                return _unit(n.xy, l.ds.xy)
            if l.ds is n and l.us.xy and _dist(l.us.xy, n.xy) > GAP:
                return _unit(l.us.xy, n.xy)
        return (1.0, 0.0)

    def _chains(self):
        cur = []
        for l in self.links:
            if l.reach and l.type == "S" and l.us.section is not None:
                if cur and cur[-1].ds is l.us:
                    cur.append(l)
                    continue
                if cur:
                    self.chains.append(cur)
                cur = [l]
            else:
                if cur:
                    self.chains.append(cur)
                cur = []
        if cur:
            self.chains.append(cur)

    def _boundaries(self):
        pass                                  # filled by convert() (needs the event data too)

    # -- helpers for writers ----------------------------------------------------
    def used_nodes(self):
        out, seen = [], set()
        for l in self.links:
            for n in (l.us, l.ds):
                if id(n) not in seen:
                    seen.add(id(n))
                    out.append(n)
        return out

    def link_geom(self, l):
        a, b = l.us.xy, l.ds.xy
        if a is None or b is None:
            return None
        if _dist(a, b) < 1e-6:
            b = (a[0] + GAP, a[1])
        return [a, b]

    def flow_dir(self, n):
        """Unit vector of the flow direction at a node (average of the connected reach links)."""
        vx = vy = 0.0
        reach = [l for l in self.links if l.reach and (l.us is n or l.ds is n)]
        for l in reach or self.links:
            if l.us is n and l.ds.xy:
                u = _unit(n.xy, l.ds.xy)
                vx, vy = vx + u[0], vy + u[1]
            elif l.ds is n and l.us.xy:
                u = _unit(l.us.xy, n.xy)
                vx, vy = vx + u[0], vy + u[1]
        d = math.hypot(vx, vy)
        return (vx / d, vy / d) if d > 1e-9 else (1.0, 0.0)

    def xs_line(self, n, section=None):
        """Cross-section line: the surveyed points when they have coordinates, else a line across the
        flow direction through the node, as wide as the section."""
        s = section or n.section
        if s is None or n.xy is None:
            return None, False
        pts = s.points() if hasattr(s, "points") else []
        if len(pts) >= 2 and _dist(pts[0], pts[-1]) > 0.5:
            # make sure the line reaches the node (sections can be offset from the thalweg)
            d, _i, _q = _nearest_on_line(pts, n.xy)
            if d < 3 * GAP:
                line = [pts[0], pts[-1]] if _straight(pts) else list(pts)
                fx, fy = self.flow_dir(n)
                # first point on the left bank looking downstream
                if fx * (line[0][1] - n.xy[1]) - fy * (line[0][0] - n.xy[0]) < 0:
                    line.reverse()
                return line, True
        rows = s.data if hasattr(s, "data") else []
        xs = [r[0] for r in rows] or [0.0, 10.0]
        width = max(10.0, max(xs) - min(xs))
        thal = min(rows, key=lambda r: r[1])[0] if rows else (min(xs) + max(xs)) / 2.0
        left, right = thal - min(xs), max(xs) - thal
        fx, fy = self.flow_dir(n)
        px, py = -fy, fx                    # left of the flow direction
        if left + right <= 0:
            left = right = width / 2.0
        return [(n.xy[0] + px * left, n.xy[1] + py * left), (n.xy[0] - px * right, n.xy[1] - py * right)], False


def _marker_xy(section, word):
    for r in section.data:
        if r[5].strip().upper().startswith(word) and r[6] is not None and r[7] is not None:
            return (r[6], r[7])
    return None


def _straight(pts, tol=0.5):
    a, b = pts[0], pts[-1]
    L = _dist(a, b)
    if L == 0:
        return True
    for p in pts[1:-1]:
        if abs((b[0] - a[0]) * (a[1] - p[1]) - (a[0] - p[0]) * (b[1] - a[1])) / L > tol:
            return False
    return True


def _shifted(section, dz, label):
    s = fm.Section("RIVER", "SECTION", [label])
    s.data = [(r[0], r[1] + dz, r[2], r[3], r[4], r[5], None, None) for r in section.data]
    return s


# ---------------------------------------------------------------------------
# writing helpers
def _write_csv(path, header, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for r in rows:
            w.writerow([("{:.6g}".format(v) if isinstance(v, float) else v) for v in r])
    return path


class _CF(object):
    """Small helper to write control-file entries the same way the Project page does."""

    def __init__(self, cf):
        self.cf = cf

    def add(self, key, value="", comment="", enabled=True):
        spec, ch = catalog().match(self.cf.ftype, key)
        self.cf.entries.append(Entry("command", lhs=spec.build_lhs(ch) if spec else key, value=str(value),
                                     comment=comment, enabled=enabled, spec=spec, choices=ch or []))

    def note(self, text):
        self.cf.entries.append(Entry("comment", comment=" " + text))

    def blank(self):
        self.cf.entries.append(Entry("blank"))


class _Layers(object):
    """Collects features per TUFLOW layer and writes them with empty_layers."""

    def __init__(self, fmt, gis_dir, stem, crs_wkt=None):
        self.fmt = fmt                 # 'gpkg' | 'shp'
        self.gis_dir = gis_dir
        self.stem = stem
        self.db = os.path.join(gis_dir, stem + ".gpkg")
        self.crs_wkt = crs_wkt
        self.layers = {}               # name -> (code, geom, fields, [(wkt, attrs)])
        self.jobs = {}

    def name(self, code, geom, extra=""):
        return EL.layer_name(code, self.stem + ("_" + extra if extra else ""), geom)

    def add(self, code, geom, wkt, attrs, extra="", fields=None):
        name = self.name(code, geom, extra)
        if name not in self.layers:
            self.layers[name] = (code, geom, fields or EL.BY_CODE[code].fields, [])
        self.layers[name][3].append((wkt, attrs))
        return name

    def count(self, name):
        return len(self.layers.get(name, (0, 0, 0, []))[3])

    def write(self):
        jobs = []
        for name, (code, geom, fields, feats) in self.layers.items():
            jobs.append(EL.LayerJob(EL.BY_CODE.get(code) or EL.BY_CODE["1d_nwk"], geom, name, fields))
        target = self.db if self.fmt == "gpkg" else self.gis_dir
        written, skipped = EL.write_layers(jobs, self.fmt, target, crs_wkt=self.crs_wkt, overwrite=True)
        for j in written:
            EL.add_features(j, self.fmt, self.layers[j.name][3])
            self.jobs[j.name] = j
        return written, skipped

    def ref(self, names, control_dir):
        """Value for a Read GIS command reading `names` (only those written)."""
        names = [n for n in names if n in self.jobs]
        if not names:
            return ""
        if self.fmt == "gpkg":
            return " | ".join(names)
        return " | ".join(to_tuflow_path(self.jobs[n].path, control_dir) for n in names)


def _read_features(path):
    """[(geom letter, [[(x, y), ...] parts], {attrs})] of a vector file (OGR)."""
    from osgeo import ogr
    out = []
    ds = ogr.Open(path)
    if ds is None:
        return out
    lyr = ds.GetLayer(0)
    defn = lyr.GetLayerDefn()
    names = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None:
            continue
        attrs = {n: f.GetField(n) for n in names}
        gt = ogr.GT_Flatten(g.GetGeometryType())
        parts = []
        if gt in (ogr.wkbPoint, ogr.wkbMultiPoint):
            geoms = [g] if gt == ogr.wkbPoint else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]
            for p in geoms:
                parts.append([(p.GetX(), p.GetY())])
            letter = "P"
        elif gt in (ogr.wkbLineString, ogr.wkbMultiLineString):
            geoms = [g] if gt == ogr.wkbLineString else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]
            for ln in geoms:
                parts.append([(ln.GetX(i), ln.GetY(i)) for i in range(ln.GetPointCount())])
            letter = "L"
        elif gt in (ogr.wkbPolygon, ogr.wkbMultiPolygon):
            polys = [g] if gt == ogr.wkbPolygon else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]
            for pg in polys:
                ring = pg.GetGeometryRef(0)
                parts.append([(ring.GetX(i), ring.GetY(i)) for i in range(ring.GetPointCount())])
            letter = "R"
        else:
            continue
        out.append((letter, parts, attrs))
    ds = None
    return out


def _prj_wkt(path):
    prj = os.path.splitext(path)[0] + ".prj"
    if os.path.isfile(prj):
        try:
            with io.open(prj, "r", encoding="utf-8", errors="ignore") as fh:
                return fh.read().strip()
        except OSError:
            return ""
    return ""


# ---------------------------------------------------------------------------
class ImportResult(object):
    def __init__(self):
        self.tcf = ""
        self.report = Report()
        self.files = []
        self.layers = []
        self.ief = ""
        self.report_path = ""


DEFAULTS = {"mode": "estry", "make_2d": True, "solver": "HPC", "hardware": "GPU", "sgs": False, "copy_grids": True,
            "gis_format": "GPKG", "cell_size": None, "dem": "", "margin": 200.0, "banks": True,
            "crs_wkt": None, "map_types": None}


def plan(fmp, opts=None):
    """Quick look at what convert() would do - for the wizard preview."""
    o = dict(DEFAULTS)
    o.update(opts or {})
    r = Report()
    net = Network(fmp.dat, Report(), keep_labels=(o["mode"] == "linked")).build() if fmp.dat else None
    rows = []
    if net is not None:
        kinds = {}
        for l in net.links:
            kinds[l.type] = kinds.get(l.type, 0) + 1
        rows.append(("1D", "{} nodes, {} ({})".format(len(net.used_nodes()), _say(len(net.links), "channel"),
                                                        ", ".join("{} {}".format(v, k) for k, v in sorted(kinds.items())))))
        rows.append(("Cross-sections", str(sum(1 for n in net.used_nodes() if n.section is not None))))
        placed = sum(1 for n in net.nodes.values() if n.placed == "schematic")
        if placed:
            rows.append(("Locations", "{} without coordinates (laid out schematically)".format(_say(placed, "node"))))
        rows.append(("Boundaries", ", ".join("{} {}".format(b.kind, b.label) for b in fmp.boundary_units().values())
                     or "none"))
    if fmp.xml is not None and fmp.xml.domains:
        d = fmp.xml.domains[0]
        rows.append(("2D", "{} x {} cells of {} m".format(d.ncols, d.nrows, fmt(d.dx or 0))))
    return rows


def convert(fmp, opts, progress=None):
    """Write a TUFLOW model for Flood Modeller project `fmp` (an fm.FmProject).

    opts: root, name, mode ('estry' | 'linked'), make_2d, solver, hardware, sgs, gis_format ('GPKG' | 'SHP'),
          cell_size, dem, margin, banks, crs_wkt, map_types"""
    o = dict(DEFAULTS)
    o.update({k: v for k, v in (opts or {}).items() if v is not None})
    res = ImportResult()
    rep = res.report
    step = progress or (lambda text: None)
    name = re.sub(r"[^\w\-~]+", "_", o.get("name") or fmp.name).strip("_") or "FM_import"
    prj = TuflowProject(o["root"], name)
    prj.create_folders()
    linked = o["mode"] == "linked"
    for n in fmp.notes:
        rep.review("Source files", n)
    dom2d = fmp.xml.domains[0] if fmp.xml is not None and fmp.xml.domains else None
    if fmp.xml is not None and len(fmp.xml.domains) > 1:
        rep.todo("2D", "The Flood Modeller model has {} 2D domains; only '{}' was converted. Add the others as "
                       "Quadtree nests or extra domains.".format(len(fmp.xml.domains), dom2d.name))
    gis_fmt = "gpkg" if (o["gis_format"] or "GPKG").upper().startswith("GPKG") else "shp"
    gis_dir = os.path.join(prj.model_dir, "gis")
    crs = o.get("crs_wkt") or ""
    if not crs and dom2d is not None:
        for p in [dom2d.active_area] + list(fmp.xml.link_files):
            crs = _prj_wkt(p) if p else ""
            if crs:
                break
    if not crs and fmp.xml is None:
        rep.info("GIS", "No projection found - layers use the project CRS chosen in the wizard (or none).")
    lay = _Layers(gis_fmt, gis_dir, prj.base_name, crs or None)
    bc_rows = []
    bc_dir = os.path.join(prj.root, "bc_dbase")
    csv_dir = os.path.join(prj.model_dir, "csv")
    xs_dir = os.path.join(csv_dir, "xs")

    # ------------------------------------------------------------------ 1D
    net = None
    ief = fmp.ief
    if fmp.dat is not None:
        step("Reading the 1D network")
        net_rep = Report() if linked else rep
        net = Network(fmp.dat, net_rep, keep_labels=linked).build()
        if linked:
            for item in net_rep.items:
                if item[1] == "1D locations":
                    rep.items.append(item)
        if not net.links and not linked:
            rep.todo("1D", "No river sections or structures could be connected - the 1D network is empty.")
        if not linked:
            _write_estry(net, fmp, lay, rep, xs_dir, bc_dir, bc_rows)
        else:
            _write_linked(net, fmp, lay, rep)
    elif ief is not None:
        rep.todo("1D", "The 1D data file was not found, so no 1D network was converted.")

    # ------------------------------------------------------------------ 2D
    make_2d = bool(o["make_2d"] or dom2d is not None or linked)
    domain = None
    cell = o.get("cell_size") or (dom2d.dx if dom2d is not None and dom2d.dx else None)
    if make_2d:
        step("Building the 2D domain")
        if dom2d is not None and dom2d.dx and dom2d.ncols and dom2d.nrows:
            domain = Domain(dom2d.xll, dom2d.yll, dom2d.rotation or 0.0, dom2d.ncols * dom2d.dx,
                            dom2d.nrows * dom2d.dx)
            rep.done("2D domain", "Grid from '{}': origin {}, {} x {} cells of {} m{}.".format(
                dom2d.name, "{}, {}".format(fmt(dom2d.xll), fmt(dom2d.yll)), dom2d.ncols, dom2d.nrows, fmt(dom2d.dx),
                ", rotated {} deg".format(fmt(dom2d.rotation)) if dom2d.rotation else ""))
            if dom2d.rotation:
                rep.review("2D domain", "Check the grid rotation: Flood Modeller's rotation was used as degrees "
                                        "anticlockwise about the origin.")
        elif net is not None and net.used_nodes():
            pts = [n.xy for n in net.used_nodes() if n.xy]
            for n in net.used_nodes():
                line, _ = net.xs_line(n)
                if line:
                    pts += line
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            m = float(o.get("margin") or 0)
            cell = cell or 5.0
            domain = from_box(min(xs) - m, min(ys) - m, max(xs) + m, max(ys) + m).snapped(cell, snap_origin=True)
            rep.done("2D domain", "Grid around the 1D network with a {} m margin: {} x {} cells of {} m.".format(
                fmt(m), *(list(domain.cells(cell)) + [fmt(cell)])))
            rep.review("2D domain", "The 2D domain is a box around the river - trim the active area (2d_code) to "
                                    "the floodplain.")
        else:
            rep.todo("2D domain", "No 2D model and no 1D coordinates - draw the 2D domain on the Project page.")
            make_2d = False
    if not make_2d and net is not None:
        rep.info("2D", "1D-only model (no 2D domain): TUFLOW runs the ESTRY network on its own. Add a 2D domain "
                       "on the Project page to model the floodplain.")
    if make_2d and domain is not None:
        cell = cell or 5.0
        _write_2d(fmp, dom2d, domain, cell, o, lay, rep, bc_dir, bc_rows, net, linked)

    # ------------------------------------------------------------------ files
    step("Writing GIS layers")
    written, skipped = lay.write()
    res.layers = [j.uri for j in written]
    for j, why in skipped:
        rep.todo("GIS", "Layer {} not written: {}".format(j.name, why))
    rep.done("GIS", "{} written to {}.".format(_say(len(written), "layer"),
                                              os.path.basename(lay.db) if gis_fmt == "gpkg" else "model/gis"))
    step("Writing control files")
    _write_databases(prj, bc_rows, o, dom2d, rep)
    _write_control_files(prj, fmp, o, lay, domain, cell, net, linked, make_2d, dom2d, rep)
    prj.save_all()
    res.tcf = prj.files["TCF"].path
    if linked and ief is not None:
        res.ief = _write_linked_ief(ief, res.tcf, prj, rep, o.get("_dt2"))
    res.report_path = os.path.join(prj.root, "FM_import_report.txt")
    rep.info("Source", "Imported from {}".format(fmp.source))
    with io.open(res.report_path, "w", encoding="utf-8") as fh:
        fh.write(rep.text("Flood Modeller import - {}".format(name)))
    res.files = [cf.path for cf in prj.files.values()] + [res.report_path]
    return res


# ---------------------------------------------------------------------------
def _write_estry(net, fmp, lay, rep, xs_dir, bc_dir, bc_rows):
    nwk_fields = EL.BY_CODE["1d_nwk"].fields
    nodes = net.used_nodes()
    for l in net.links:
        geom = net.link_geom(l)
        if geom is None:
            continue
        a = {"ID": l.id, "Type": l.type, "Len_or_ANA": l.length if l.type == "S" else l.attrs.get("Len_or_ANA", 0.0),
             "n_nF_Cd": 1.0, "US_Invert": -99999.0, "DS_Invert": -99999.0}
        a.update({k: v for k, v in l.attrs.items() if k != "Flags"})
        if l.attrs.get("Flags"):
            a["Type"] = l.type + l.attrs["Flags"]
        lay.add("1d_nwk", "L", _wkt_line(geom), a)
    for n in nodes:
        lay.add("1d_nwk", "P", _wkt_point(n.xy), {"ID": n.id, "Type": "", "Len_or_ANA": 0.0, "US_Invert": -99999.0,
                                                  "DS_Invert": -99999.0})
    kinds = {}
    for l in net.links:
        kinds[l.type] = kinds.get(l.type, 0) + 1
    words = {"S": "open channel", "C": "circular culvert", "R": "box culvert", "W": "weir"}
    rep.done("1D network", "{} and {}: {}.".format(
        _say(len(net.links), "channel"), _say(len(nodes), "node"),
        ", ".join("{} {}".format(v, words.get(k, k) + ("s" if v > 1 else "")) for k, v in sorted(kinds.items()))))
    for kind, labels in sorted(net.joined.items()):
        rep.review("1D losses", "{} {} joined into single nodes (the head loss is not modelled) - add a Form_Loss "
                                "to the channel if it matters: {}.".format(_say(len(labels), "unit"), kind.lower(),
                                                                           _names(labels)))
    for kind, labels in sorted(net.skipped.items()):
        rep.todo("1D structures", "{} {} not converted - the upstream and downstream nodes were joined. Model with "
                                  "{}: {}.".format(_say(len(labels), "unit"), kind.lower(),
                                                   SUGGEST.get(kind, "an equivalent ESTRY channel"), _names(labels)))
    # cross-sections
    n_xs = derived = surveyed = 0
    no_xs = []
    gis_dir = lay.gis_dir
    tables = []
    for n in nodes:
        if n.section is not None and n.section.data:
            tables.append((n, n.section, n.id))
        elif any(l.type == "S" and (l.us is n or l.ds is n) for l in net.links):
            no_xs.append(n.label)
    for l in net.links:
        if l.section:
            sec = fm.Section("BRIDGE", "", [l.id])
            sec.data = [(x, z, mann if mann is not None else 0.03, False, 0.0, "", None, None) for x, z, mann in l.section]
            tables.append((l, sec, l.id + "_bridge"))
    for owner, sec, stem in tables:
        path = os.path.join(xs_dir, file_stem(stem) + ".csv")
        rows = []
        for r in sec.data:
            n_val = r[2] if r[2] not in (None, 0) else 0.035
            rows.append((r[0], r[1], n_val))
        _write_csv(path, ["X", "Z", "N"], rows)
        if isinstance(owner, Link):
            geom = net.link_geom(owner)
            mid = ((geom[0][0] + geom[1][0]) / 2.0, (geom[0][1] + geom[1][1]) / 2.0)
            u = _unit(geom[0], geom[1])
            w = max(5.0, (max(r[0] for r in rows) - min(r[0] for r in rows)) / 2.0)
            line = [(mid[0] - u[1] * w, mid[1] + u[0] * w), (mid[0] + u[1] * w, mid[1] - u[0] * w)]
            real = False
        else:
            line, real = net.xs_line(owner)
            if owner.derived:
                derived += 1
            elif real:
                surveyed += 1
        if not line:
            continue
        src = to_tuflow_path(path, gis_dir)
        lay.add("1d_xs", "L", _wkt_line(line), {"Source": src, "Type": "XZ", "Flags": "N", "Column_1": "X",
                                               "Column_2": "Z", "Column_3": "N"})
        n_xs += 1
    if n_xs:
        rep.done("1D cross-sections", "{} XZ tables with Manning's n per point (model/csv/xs){}.".format(
            n_xs, "; {} drawn from the surveyed points".format(surveyed) if surveyed else ""))
    if derived:
        rep.review("1D cross-sections", "{} for interpolate / replicate units were derived from the neighbouring "
                                        "sections.".format(_say(derived, "section")))
    if n_xs - surveyed - derived > 0:
        rep.info("1D cross-sections", "Sections without surveyed coordinates are drawn across the flow at their "
                                      "node, as wide as the section.")
    if no_xs:
        rep.todo("1D cross-sections", "Open channels touching {} have no section at either end - add a 1d_xs line "
                                      "or the run stops.".format(_names(no_xs)))
    panels = sum(1 for n in nodes if n.section is not None and any(r[3] for r in n.section.data))
    if panels:
        rep.info("1D cross-sections", "{} use panel markers; ESTRY splits the conveyance at the n changes instead."
                 .format(_say(panels, "section")))
    # boundaries
    used = {n.label: n for n in nodes}
    _boundaries_1d(net, fmp, used, lay, rep, bc_dir, bc_rows)
    # timestep advice
    s_lengths = [l.length for l in net.links if l.type == "S" and l.length]
    if s_lengths:
        short = min(s_lengths)
        rep.info("1D timestep", "Shortest channel {} m - keep the 1D timestep below about {} s.".format(
            fmt(short), fmt(max(0.1, short / 10.0), 1)))


def _boundaries_1d(net, fmp, used, lay, rep, bc_dir, bc_rows):
    bunits = fmp.boundary_units()
    done = []
    for label, b in bunits.items():
        n = used.get(net.find(label))
        if n is None:
            rep.todo("1D boundaries", "{} {} is not on a converted channel - attach it by hand.".format(b.kind, label))
            continue
        btype = BOUNDARY_TYPES[b.kind]
        name = "FM_" + tuflow_id(label)
        csv_path = os.path.join(bc_dir, "1d", file_stem(label) + ".csv")
        if btype == "HQ":
            _write_csv(csv_path, ["Level", "Flow"], b.data)
            bc_rows.append([name, to_tuflow_path(csv_path, bc_dir), "Level", "Flow", "", "", "", "", ""])
        else:
            _write_csv(csv_path, ["Time", "Flow" if btype == "QT" else "Level"], b.data)
            bc_rows.append([name, to_tuflow_path(csv_path, bc_dir), "Time", "Flow" if btype == "QT" else "Level",
                            "", "", "", "", ""])
        lay.add("1d_bc", "P", _wkt_point(n.xy), {"Type": btype, "Name": name,
                                                  "Description": "Flood Modeller {} {}".format(b.kind, label)})
        done.append("{} {}".format(btype, label))
        if b.params.get("note"):
            rep.review("1D boundaries", "{} {}: {}.".format(b.kind, label, b.params["note"]))
        if not b.data:
            rep.todo("1D boundaries", "{} {} has no data rows - fill {}.".format(b.kind, label,
                                                                                 os.path.basename(csv_path)))
    if done:
        rep.done("1D boundaries", "{} (1d_bc + bc_dbase, times in hours): {}.".format(_say(len(done), "boundary",
                                                                                        "boundaries"), _names(done, 8)))
    hyd = [u for u in fmp.dat.units if u.kind in fm.HYDROLOGY_UNITS]
    for u in hyd:
        n = used.get(net.find(u.label))
        name = "FM_" + tuflow_id(u.label)
        csv_path = os.path.join(bc_dir, "1d", file_stem(u.label) + ".csv")
        _write_csv(csv_path, ["Time", "Flow"], [])
        bc_rows.append([name, to_tuflow_path(csv_path, bc_dir), "Time", "Flow", "", "", "", "", ""])
        if n is not None:
            lay.add("1d_bc", "P", _wkt_point(n.xy), {"Type": "QT", "Name": name,
                                                      "Description": "from {} {} - hydrograph needed".format(u.kind,
                                                                                                             u.label)})
    if hyd:
        rep.todo("1D boundaries", "{} ({}) generate their hydrograph inside Flood Modeller. Run it there, export "
                                  "the flows and paste them into bc_dbase/1d/<label>.csv: {}.".format(
                                      _say(len(hyd), "hydrology unit"), ", ".join(sorted({u.kind for u in hyd})),
                                      _names([u.label for u in hyd])))
    lat = [u for u in fmp.dat.units if u.kind in LATERAL_UNITS]
    if lat:
        rep.todo("1D", "{} not converted ({}): {}. Use nodal storage (NA tables) for reservoirs / ponds and QT "
                       "boundaries for laterals.".format(_say(len(lat), "unit"), ", ".join(sorted({u.kind for u in lat})),
                                                         _names([u.label for u in lat])))


def _write_linked(net, fmp, lay, rep):
    nodes = [n for n in net.nodes.values() if n.xy is not None]
    fields = [EL.Field("ID", EL.C, 12, "Flood Modeller node label")]
    for n in nodes:
        for l in n.labels:
            if fmp.dat.node_xy(l) or l == n.label:
                lay.add("1d_x1d", "P", _wkt_point(n.xy), {"ID": l}, extra="nodes", fields=fields)
                break
    rep.done("1D (Flood Modeller)", "{} written to a node layer read with Read GIS X1D Nodes; Flood Modeller "
                                    "keeps the 1D.".format(_say(len(nodes), "node")))
    if any(n.placed == "schematic" for n in nodes):
        rep.todo("1D (Flood Modeller)", "Some nodes have no coordinates - move them onto the river before linking "
                                        "the 2D.")


# ---------------------------------------------------------------------------
def _write_2d(fmp, d2, domain, cell, o, lay, rep, bc_dir, bc_rows, net, linked):
    lay.add("2d_loc", "L", domain.loc_line_wkt(), {"Comment": "grid origin and X axis (from Flood Modeller)"})
    # active area
    n_code = 0
    if d2 is not None and d2.active_area and os.path.isfile(d2.active_area):
        for letter, parts, _a in _read_features(d2.active_area):
            if letter == "R":
                for ring in parts:
                    lay.add("2d_code", "R", _wkt_poly(ring[:-1] if ring[0] == ring[-1] else ring), {"Code": 1})
                    n_code += 1
        if d2.deactive_area and os.path.isfile(d2.deactive_area):
            for letter, parts, _a in _read_features(d2.deactive_area):
                if letter == "R":
                    for ring in parts:
                        lay.add("2d_code", "R", _wkt_poly(ring[:-1] if ring[0] == ring[-1] else ring), {"Code": 0})
                        n_code += 1
        rep.done("2D domain", "Active area -> 2d_code ({}).".format(_say(n_code, "polygon")))
    elif d2 is not None and d2.active_area:
        rep.todo("2D domain", "Active area shapefile not found: {}".format(d2.active_area))
    if not n_code:
        lay.add("2d_code", "R", domain.wkt(), {"Code": 1})
    # roughness
    mats = []
    if d2 is not None:
        for law, rtype, val, default in d2.roughness:
            if rtype == "global" and fm._f(val) is not None:
                mats.append((1, fm._f(val), "Flood Modeller global roughness"))
            elif rtype == "file" and val and os.path.isfile(val):
                feats = _read_features(val)
                field = _roughness_field(feats)
                ids = {}
                for letter, parts, attrs in feats:
                    nval = fm._f(attrs.get(field)) if field else None
                    if letter != "R" or nval is None:
                        continue
                    if nval not in ids:
                        ids[nval] = len(ids) + 2
                        mats.append((ids[nval], nval, "from {}".format(os.path.basename(val))))
                    for ring in parts:
                        lay.add("2d_mat", "R", _wkt_poly(ring[:-1] if ring[0] == ring[-1] else ring),
                                {"Material": ids[nval]})
                if ids:
                    rep.done("Roughness", "{} -> 2d_mat with {}.".format(os.path.basename(val),
                                                                         _say(len(ids), "material")))
                else:
                    rep.todo("Roughness", "Could not find a Manning's n field in {}.".format(os.path.basename(val)))
            elif rtype != "global":
                rep.todo("Roughness", "Roughness '{}' ({}) not converted - set materials by hand.".format(rtype, val))
            if law and law.lower() != "manning":
                rep.review("Roughness", "Flood Modeller roughness law '{}' - TUFLOW uses Manning's n.".format(law))
    o["_materials"] = mats
    # boundaries
    if d2 is not None:
        _boundaries_2d(fmp, d2, o, lay, rep, bc_dir, bc_rows)
    else:
        rep.todo("2D boundaries", "The 2D model has no boundaries yet - add inflows / outflows in 2d_bc if water "
                                  "leaves the river onto the floodplain edge.")
    # 1D / 2D links
    if net is not None:
        _links_1d2d(fmp, d2, o, lay, rep, net, cell, linked)


def _copy_grid(path, folder):
    """Copy a grid (with its sidecar files) into the model so the model is self-contained."""
    if not path or not os.path.isfile(path):
        return path
    os.makedirs(folder, exist_ok=True)
    stem = os.path.splitext(os.path.basename(path))[0]
    src_dir = os.path.dirname(path)
    out = os.path.join(folder, os.path.basename(path))
    if os.path.normcase(os.path.abspath(out)) == os.path.normcase(os.path.abspath(path)):
        return path
    for n in os.listdir(src_dir):
        if os.path.splitext(n)[0].lower() == stem.lower() or n.lower().startswith(os.path.basename(path).lower() + "."):
            shutil.copy2(os.path.join(src_dir, n), os.path.join(folder, n))
    return out


def _roughness_field(feats):
    if not feats:
        return None
    names = list(feats[0][2].keys())
    pref = [n for n in names if n.lower() in ("n", "manning", "mannings", "rough", "roughness", "value", "n_value")]
    for n in pref + names:
        vals = [fm._f(f[2].get(n)) for f in feats]
        vals = [v for v in vals if v is not None]
        if vals and all(0.005 <= v <= 1.0 for v in vals):
            return n
    return None


def _bc_series(bc, fmp, end_h):
    """[(hours, value)] for a Flood Modeller 2D boundary, or (None, reason)."""
    vt = (bc.value_type or "").lower()
    if vt == "timevar":
        rows = []
        for line in bc.value.splitlines():
            parts = line.replace(",", " ").split()
            if len(parts) >= 2 and fm._f(parts[0]) is not None and fm._f(parts[1]) is not None:
                rows.append((fm._hours(parts[0], bc.time_units), fm._f(parts[1])))
        return rows, ""
    if vt == "fixedvalue":
        v = fm._f(bc.value)
        return ([(0.0, v), (max(end_h or 0.0, 1.0) + 1.0, v)], "") if v is not None else (None, "no value")
    if vt in ("csv", "hpcsv") and bc.value and os.path.isfile(bc.value):
        rows = []
        with io.open(bc.value, "r", encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                parts = line.replace(",", " ").split()
                if len(parts) >= 2 and fm._f(parts[0]) is not None and fm._f(parts[1]) is not None:
                    rows.append((fm._hours(parts[0], bc.time_units), fm._f(parts[1])))
        return rows, ""
    if vt == "ied":
        b = fmp.boundary_units().get(bc.header_label)
        if b is None:
            for ev in fmp.events:
                for u in ev.boundaries():
                    if u.label == bc.header_label:
                        b = u
        if b is not None and b.kind != "QHBDY":
            return list(b.data), ""
        return None, "event-data unit '{}' not found".format(bc.header_label)
    return None, "value type '{}'".format(bc.value_type or "?")


def _boundaries_2d(fmp, d2, o, lay, rep, bc_dir, bc_rows):
    end_h = (d2.start_h or 0.0) + (d2.total_h or 0.0)
    ok = []
    for k, bc in enumerate(d2.boundaries, 1):
        ttype = FM_BC_TYPES.get(bc.bc_type)
        label = "FM2D_{}_{}".format(k, bc.bc_type or "bc")
        if ttype is None:
            rep.todo("2D boundaries", "Boundary {} type '{}' has no TUFLOW match - add it by hand.".format(k, bc.bc_type))
            continue
        feats = _read_features(bc.file) if bc.file and os.path.isfile(bc.file) else []
        if not feats:
            rep.todo("2D boundaries", "Boundary {} ({}): shape file {} not found - draw it in 2d_bc.".format(
                k, bc.bc_type, bc.file or "(none)"))
            continue
        name = tuflow_id(label)
        if ttype == "HQ" and bc.bc_type in ("freeflow", "normaldepth"):
            for letter, parts, _a in feats:
                for p in parts:
                    if letter == "L":
                        lay.add("2d_bc", "L", _wkt_line(p), {"Type": "HQ", "Name": "", "b": 0.001})
            rep.review("2D boundaries", "Boundary {} ({}) -> HQ line with a water-surface slope of 0.001 - set 'b' "
                                        "to the local slope.".format(k, bc.bc_type))
            ok.append("HQ")
            continue
        rows, why = _bc_series(bc, fmp, end_h)
        if rows is None:
            rep.todo("2D boundaries", "Boundary {} ({}): {} - fill bc_dbase row {}.".format(k, bc.bc_type, why, name))
            rows = []
        csv_path = os.path.join(bc_dir, "2d", file_stem(name) + ".csv")
        col = "Level" if ttype == "HT" else "Flow"
        _write_csv(csv_path, ["Time", col], rows)
        bc_rows.append([name, to_tuflow_path(csv_path, bc_dir), "Time", col, "", "", "", "", ""])
        for letter, parts, _a in feats:
            for p in parts:
                if ttype == "SA" and letter == "R":
                    lay.add("2d_sa", "R", _wkt_poly(p[:-1] if p[0] == p[-1] else p), {"Name": name})
                elif ttype == "SA":
                    lay.add("2d_bc", letter, _wkt_point(p[0]) if letter == "P" else _wkt_line(p),
                            {"Type": "ST", "Name": name})
                elif letter == "L":
                    lay.add("2d_bc", "L", _wkt_line(p), {"Type": ttype, "Name": name})
                elif letter == "P":
                    lay.add("2d_bc", "P", _wkt_point(p[0]), {"Type": "ST" if ttype == "QT" else ttype, "Name": name})
                else:
                    lay.add("2d_bc", "R", _wkt_poly(p[:-1] if p[0] == p[-1] else p),
                            {"Type": "ST" if ttype == "QT" else ttype, "Name": name})
        ok.append(ttype)
    if ok:
        rep.done("2D boundaries", "{} -> {}.".format(_say(len(ok), "boundary", "boundaries"), ", ".join(ok)))
    for bc in d2.boundaries:
        if bc.bc_type == "verticalflow":
            rep.info("2D boundaries", "Flood Modeller 'vertical flow' inflows -> source areas (2d_sa) or ST points.")
            break


def _links_1d2d(fmp, d2, o, lay, rep, net, cell, linked):
    """HX lines (from the Flood Modeller link file or along the banks) with CN lines to the nodes."""
    hx = []                                   # list of polylines
    from_file = False
    if fmp.xml is not None and fmp.xml.link_files:
        for path in fmp.xml.link_files:
            if not os.path.isfile(path):
                rep.todo("1D/2D links", "Link shapefile not found: {}".format(path))
                continue
            for letter, parts, _a in _read_features(path):
                if letter == "L":
                    hx += [list(p) for p in parts if len(p) >= 2]
            from_file = True
    banks = []
    if not hx and o.get("banks", True):
        for chain in net.chains:
            nodes = [chain[0].us] + [l.ds for l in chain]
            left, right, conn = [], [], []
            for n in nodes:
                line, real = net.xs_line(n)
                if not line:
                    continue
                lb = _marker_xy(n.section, "LEFT") if real else None
                rb = _marker_xy(n.section, "RIGHT") if real else None
                a, b = lb or line[0], rb or line[-1]
                if left and _dist(left[-1], b) + _dist(right[-1], a) < _dist(left[-1], a) + _dist(right[-1], b):
                    a, b = b, a                 # keep each bank on its own side along the reach
                left.append(a)
                right.append(b)
                conn.append(n)
            if len(left) >= 2:
                banks.append((left, right, conn))
        for left, right, conn in banks:
            for side in (left, right):
                hx.append(side)
                lay.add("2d_bc", "L", _wkt_line(side), {"Type": "HX", "Flags": "", "f": 0.0})
            for n, a, b in zip(conn, left, right):
                lay.add("2d_bc", "L", _wkt_line([n.xy, a]), {"Type": "CN", "f": 1.0})
                lay.add("2d_bc", "L", _wkt_line([n.xy, b]), {"Type": "CN", "f": 1.0})
            lay.add("2d_code", "R", _wkt_poly(left + right[::-1]), {"Code": 0}, extra="channel")
        if banks:
            rep.done("1D/2D links", "HX lines along both banks of {} (from the section ends) with CN lines to each "
                                    "node.".format(_say(len(banks), "reach", "reaches")))
            rep.review("1D/2D links", "Bank lines join the section ends - check them against the DTM, and that the "
                                      "HX cells are at bank-top level (1d_to_2d check file).")
            rep.info("1D/2D links", "A 2d_code '..._channel_R' layer (Code 0, in-channel cells) is listed but "
                                    "switched off in the TGC; switch it on to stop the 2D double-counting channel "
                                    "storage.")
    if from_file:
        nodes = [n for n in (net.used_nodes() if not linked else net.nodes.values()) if n.xy is not None]
        reach = max(3.0 * (cell or 5.0), 100.0)
        n_cn = 0
        for line in hx:
            for n in nodes:
                hit = _nearest_on_line(line, n.xy)
                if hit is None or hit[0] > reach or hit[0] < 1e-6:
                    continue
                d, i, q = hit
                if _dist(q, line[i]) > 1e-6 and _dist(q, line[i + 1]) > 1e-6:
                    line.insert(i + 1, q)
                lay.add("2d_bc", "L", _wkt_line([n.xy, q]), {"Type": "CN", "f": 1.0})
                n_cn += 1
        for line in hx:
            lay.add("2d_bc", "L", _wkt_line(line), {"Type": "HX", "f": 0.0})
        rep.done("1D/2D links", "{} from the Flood Modeller link file with {} (nodes within {} m).".format(
            _say(len(hx), "HX line"), _say(n_cn, "CN line"), fmt(reach)))
        rep.review("1D/2D links", "Check every node that should spill is connected (CN lines) - see the "
                                  "1d_to_2d check file after a test run.")
    if not hx:
        rep.todo("1D/2D links", "No 1D/2D link - draw HX lines along the banks with CN lines to the nodes, or "
                                "water stays in the 1D channel.")


# ---------------------------------------------------------------------------
def _write_databases(prj, bc_rows, o, d2, rep):
    bc = os.path.join(prj.root, "bc_dbase", "bc_dbase.csv")
    _write_csv(bc, BC_DBASE_HEADER, bc_rows)
    mats = o.get("_materials") or []
    if not any(m[0] == 1 for m in mats):
        mats = [(1, 0.06, "default (not in the Flood Modeller model)")] + mats
    _write_csv(os.path.join(prj.model_dir, "materials.csv"), MATERIALS_HEADER,
               [[m[0], m[1], "", "", "", "", m[2]] for m in sorted(mats)])
    if bc_rows:
        rep.done("Databases", "bc_dbase.csv with {}; materials.csv with {}.".format(
            _say(len(bc_rows), "row"), _say(len(mats), "material")))


def _map_types(d2, o):
    if o.get("map_types"):
        return o["map_types"]
    types = []
    for v in (d2.output_vars if d2 is not None else []):
        t = FM_MAP_TYPES.get(v.lower().replace(" ", ""))
        if t and t not in types:
            types.append(t)
    if d2 is None or not d2.output_vars:
        return "h d V q"
    for t in ("h", "d", "V"):
        if t not in types:
            types.append(t)
    order = ["h", "d", "V", "q", "ZUK0"]
    return " ".join(sorted(types, key=lambda t: order.index(t) if t in order else 9))


def _write_control_files(prj, fmp, o, lay, domain, cell, net, linked, make_2d, d2, rep):
    name = prj.name
    tcf = prj.ensure("TCF")
    tdir = os.path.dirname(tcf.path)
    rel = lambda p: to_tuflow_path(p, tdir)
    T = _CF(tcf)
    ief = fmp.ief
    T.note("=" * 70)
    T.note("TUFLOW Control File - {}".format(name))
    T.note("Imported from Flood Modeller by FMB tools: {}".format(os.path.basename(fmp.source)))
    T.note("Read FM_import_report.txt (model root) for the items to check.")
    T.note("=" * 70)
    T.blank()
    T.note("--- Solver ---")
    T.add("Solution Scheme", o.get("solver") or "HPC")
    if (o.get("solver") or "HPC").upper().startswith("HPC"):
        T.add("Hardware", o.get("hardware") or "GPU")
        if o.get("sgs"):
            T.add("SGS", "ON")
    if d2 is not None and d2.scheme:
        T.note("Flood Modeller 2D scheme was {} - TUFLOW HPC solves the full 2D equations.".format(d2.scheme))
    T.blank()
    T.note("--- GIS ---")
    gis_fmt = "GPKG" if lay.fmt == "gpkg" else "SHP"
    T.add("GIS Format", gis_fmt)
    if lay.fmt == "gpkg":
        T.add("Spatial Database", rel(lay.db))
    proj_layer = lay.ref([lay.name("2d_loc", "L")], tdir) if make_2d else ""
    if not proj_layer:
        first = next((n for n in lay.jobs), "")
        proj_layer = lay.ref([first], tdir) if first else ""
    if proj_layer:
        T.add("GPKG Projection" if lay.fmt == "gpkg" else "SHP Projection", proj_layer)
    T.blank()
    T.note("--- Control files & databases ---")
    tgc = tbc = None
    if make_2d and domain is not None:
        tgc = prj.ensure("TGC")
        tbc = prj.ensure("TBC")
        T.add("Geometry Control File", rel(tgc.path))
        T.add("BC Control File", rel(tbc.path))
    T.add("BC Database", rel(os.path.join(prj.root, "bc_dbase", "bc_dbase.csv")))
    if make_2d:
        T.add("Read Materials File", rel(os.path.join(prj.model_dir, "materials.csv")))
    if net is not None and not linked:
        ecf = prj.ensure("ECF")
        T.add("ESTRY Control File", rel(ecf.path))
    if net is not None and linked:
        T.blank()
        T.note("--- Flood Modeller 1D (run from the Flood Modeller event file) ---")
        T.add("Read GIS X1D Nodes", lay.ref([lay.name("1d_x1d", "P", "nodes")], tdir))
    T.blank()
    T.note("--- Time (hours) ---")
    start = fm._f(ief.get("start")) if ief is not None else None
    finish = fm._f(ief.get("finish")) if ief is not None else None
    if start is None:
        start = d2.start_h if d2 is not None else 0.0
    if finish is None:
        finish = (start + d2.total_h) if d2 is not None and d2.total_h else start + 3.0
    dt2 = d2.timestep if d2 is not None and d2.timestep else round(max(0.5, (cell or 5.0) / 4.0), 2)
    o["_dt2"] = dt2
    if linked:
        T.note("Flood Modeller sets the run times when it runs this model - these are for stand-alone tests.")
    T.add("Start Time", fmt(start), enabled=not linked)
    T.add("End Time", fmt(finish), enabled=not linked)
    T.add("Timestep", fmt(dt2), "seconds", enabled=not linked)
    if make_2d and d2 is not None:
        extra = []
        iwl = fm._f(d2.ic_value)
        if d2.ic_type == "globalwaterlevel" and iwl:
            extra.append(("Set IWL", fmt(iwl), "Flood Modeller global water level"))
        elif d2.ic_type and d2.ic_type not in ("globaldepth", "globalwaterlevel"):
            rep.todo("Initial conditions", "Flood Modeller initial condition '{}' not converted - use Read GIS IWL "
                                           "or Read Grid IWL.".format(d2.ic_type))
        elif d2.ic_type == "globaldepth" and iwl:
            rep.todo("Initial conditions", "Flood Modeller starts with {} m depth everywhere - TUFLOW needs a water "
                                           "level (Set IWL / Read Grid IWL).".format(fmt(iwl)))
        if d2.drydepth:
            extra.append(("Cell Wet/Dry Depth", fmt(d2.drydepth), "Flood Modeller dry depth"))
        if extra:
            T.blank()
            T.note("--- 2D settings ---")
            for k, v, c in extra:
                T.add(k, v, c)
    T.blank()
    T.note("--- Output ---")
    T.add("Log Folder", "log")
    T.add("Output Folder", rel(os.path.join(prj.root, "results")) + "\\")
    T.add("Write Check Files", rel(os.path.join(prj.root, "check")) + "\\")
    if make_2d:
        T.add("Map Output Format", "XMDF TIF")
        T.add("Map Output Data Types", _map_types(d2, o))
        mint = d2.output_freq if d2 is not None and d2.output_freq else (fm._f(ief.get("saveinterval")) if ief else None)
        T.add("Map Output Interval", fmt(mint or 300))
    T.add("Time Series Output Interval", fmt(fm._f(ief.get("saveinterval")) if ief is not None and
                                             fm._f(ief.get("saveinterval")) else 60))
    rep.done("Run times", "Start {} h, end {} h, 2D timestep {} s{}.".format(
        fmt(start), fmt(finish), fmt(dt2), " (taken from Flood Modeller)" if ief is not None or d2 is not None else ""))

    # -- TGC
    if tgc is not None:
        G = _CF(tgc)
        gdir = os.path.dirname(tgc.path)
        G.note("TUFLOW Geometry Control File - {} (from Flood Modeller)".format(name))
        G.blank()
        if domain.rotated:
            G.note("grid X axis {} deg anticlockwise from east".format(fmt(domain.angle, 4)))
        G.add("Read GIS Location", lay.ref([lay.name("2d_loc", "L")], gdir),
              "origin = first vertex, X axis along the line")
        G.add("Grid Size (X,Y)", "{}, {}".format(fmt(domain.width), fmt(domain.height)))
        G.add("Cell Size", fmt(cell))
        G.blank()
        G.add("Set Code", "0")
        G.add("Read GIS Code", lay.ref([lay.name("2d_code", "R")], gdir))
        chan = lay.ref([lay.name("2d_code", "R", "channel")], gdir)
        if chan:
            G.add("Read GIS Code", chan, "in-channel cells inactive (switch on after checking)", enabled=False)
        G.blank()
        G.add("Set Zpt", "100")
        dems = []
        if o.get("dem"):
            dems = [o["dem"]]
        elif d2 is not None:
            dems = list(d2.topography)
        if o.get("copy_grids", True):
            dems = [_copy_grid(p, os.path.join(prj.model_dir, "grid")) for p in dems]
        for p in dems:
            G.add("Read Grid Zpts", to_tuflow_path(p, gdir))
            if not os.path.isfile(p):
                rep.todo("Topography", "DTM not found: {} - fix the path in the TGC.".format(p))
        if dems:
            rep.done("Topography", "{} read with Read Grid Zpts (later grids overwrite earlier ones){}.".format(
                _say(len(dems), "grid"), ", copied to model/grid" if o.get("copy_grids", True) else ""))
        else:
            G.add("Read Grid Zpts", "")
            rep.todo("Topography", "No DTM - pick one on the TGC page (Read Grid Zpts).")
        if d2 is not None and d2.zlines:
            rep.todo("Topography", "{} not converted (Flood Modeller z-line / z-shape attributes differ) - redraw "
                                   "as 2d_zsh: {}.".format(_say(len(d2.zlines), "z-line file"),
                                                           _names(os.path.basename(z[0]) for z in d2.zlines)))
        G.blank()
        G.add("Set Mat", "1")
        mat = lay.ref([lay.name("2d_mat", "R")], gdir)
        if mat:
            G.add("Read GIS Mat", mat)
        if any(m[2] == "Flood Modeller global roughness" for m in (o.get("_materials") or [])):
            rep.done("Roughness", "Global Manning's n -> material 1 (Set Mat 1).")
    # -- TBC
    if tbc is not None:
        B = _CF(tbc)
        bdir = os.path.dirname(tbc.path)
        B.note("TUFLOW Boundary Control File - {} (from Flood Modeller)".format(name))
        B.blank()
        refs = [lay.name("2d_bc", g) for g in ("R", "L", "P")]
        v = lay.ref(refs, bdir)
        B.add("Read GIS BC", v)
        sa = lay.ref([lay.name("2d_sa", "R")], bdir)
        if sa:
            B.add("Read GIS SA", sa)
    # -- ECF
    if net is not None and not linked:
        E = _CF(prj.files["ECF"])
        edir = os.path.dirname(prj.files["ECF"].path)
        E.note("ESTRY (1D) Control File - {} (converted from Flood Modeller)".format(name))
        E.blank()
        s_lengths = [l.length for l in net.links if l.type == "S" and l.length]
        dt1 = fm._f(ief.get("timestep")) if ief is not None else None
        dt1 = min(dt1 or 1.0, max(0.1, round(min(s_lengths) / 10.0, 1)) if s_lengths else 2.0)
        E.add("Timestep", fmt(dt1), "seconds")
        E.add("Read GIS Network", lay.ref([lay.name("1d_nwk", "L"), lay.name("1d_nwk", "P")], edir))
        xs = lay.ref([lay.name("1d_xs", "L")], edir)
        if xs:
            E.add("Read GIS Table Links", xs)
        bc1 = lay.ref([lay.name("1d_bc", "P")], edir)
        if bc1:
            E.add("Read GIS BC", bc1)
        E.blank()
        E.add("Output Interval", fmt(fm._f(ief.get("saveinterval")) if ief is not None and
                                     fm._f(ief.get("saveinterval")) else 60), "seconds")


def _write_linked_ief(ief, tcf_path, prj, rep, dt2=None):
    """Copy of the event file with absolute paths and 2DFile pointing at the new TCF."""
    src_dir = os.path.dirname(ief.path)
    out = os.path.join(prj.runs_dir, os.path.splitext(os.path.basename(ief.path))[0] + "_TUFLOW.ief")
    lines = fm._read_lines(ief.path)
    new = []
    have_2d = False
    path_keys = {"datafile", "eventdata", "results", "initialconditions"}
    for line in lines:
        s = line.strip()
        if "=" in s and not s.startswith(";"):
            k, v = [x.strip() for x in s.split("=", 1)]
            kl = k.lower()
            if kl == "2dfile":
                new.append("2DFile={}".format(tcf_path))
                have_2d = True
                continue
            if kl in path_keys and v:
                new.append("{}={}".format(k, fm.resolve(v, src_dir)))
                continue
        new.append(line)
    idx = next((i for i, l in enumerate(new) if l.strip().lower().startswith("[isis event details]")), None)
    at = idx + 1 if idx is not None else len(new)
    if not have_2d:
        new.insert(at, "2DFile={}".format(tcf_path))
    if dt2 and not ief.get("2dtimestep"):
        new.insert(at + 1, "2DTimestep={}".format(fmt(dt2)))
    with io.open(out, "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("\n".join(new) + "\n")
    rep.done("Flood Modeller link", "Event file {} written - run it in Flood Modeller to run the 1D with the "
                                    "TUFLOW 2D.".format(os.path.basename(out)))
    rep.review("Flood Modeller link", "Open {} in Flood Modeller and check the 2D link settings (TUFLOW selected as "
                                      "the 2D engine).".format(os.path.basename(out)))
    return out
