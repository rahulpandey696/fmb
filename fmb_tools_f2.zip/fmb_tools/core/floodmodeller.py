# -*- coding: utf-8 -*-
"""
Readers for Flood Modeller (Jacobs, formerly ISIS) model files - written for FMB tools from the
published file layouts; nothing here needs Flood Modeller installed.

    read_ief(path)   event file (.ief): data file, 2D file, times, event data (.ied) files
    read_dat(path)   1D network (.dat / .ied): river sections, boundaries, conduits, junctions,
                     bridges, spills ... with node coordinates from section points, .gxy or GISINFO
    read_xml2d(path) 2D model (.xml): computational area, topography, roughness, initial
                     conditions, boundary conditions, time, run data, output, 1D link
    read_project(path) any of the above -> FmProject (follows the links between them)

DAT files are fixed width: 10-character numbers, labels of `label_len` characters (12 by default).
"""
import io
import os
import re
import xml.etree.ElementTree as ET

# unit keywords that start a block in a .dat / .ied file
UNIT_KEYWORDS = {
    "QTBDY", "HTBDY", "QHBDY", "REFHBDY", "RIVER", "BRIDGE", "CONDUIT", "SLUICE", "ORIFICE", "SPILL",
    "INITIAL CONDITIONS", "VARIABLES", "BLOCKAGE", "CULVERT", "RNWEIR", "WEIR", "CRUMP", "FLAT-V WEIR",
    "INTERPOLATE", "REPLICATE", "OUTFALL", "COMMENT", "JUNCTION", "LATERAL", "RESERVOIR", "FLOODPLAIN",
    "ABSTRACTION", "BERNOULLI", "BREACH", "FEHBDY", "FLOOD RELIEF", "FLOOD RELIEF ARCH", "FRQSIM", "FSRBDY",
    "FSSR16BDY", "GATED WEIR", "GAUGE", "GERRBDY", "INVERTED SYPHON", "LABYRINTH WEIR", "LOSS", "LOSSID",
    "MANHOLE", "NCDBDY", "NOTWEIR", "OCPUMP", "POND", "QH CONTROL", "QRATING", "REBDY", "REFH2BDY", "SCSBDY",
    "SCWEIR", "SYPHON", "TIDBDY", "GISINFO",
}
TIME_FACTORS = {"SECONDS": 1 / 3600.0, "SECOND": 1 / 3600.0, "MINUTES": 1 / 60.0, "MINUTE": 1 / 60.0,
                "MINS": 1 / 60.0, "HOURS": 1.0, "HOUR": 1.0, "HRS": 1.0, "DAYS": 24.0, "DAY": 24.0,
                "WEEKS": 168.0, "WEEK": 168.0, "MONTHS": 730.5, "MONTH": 730.5, "YEARS": 8766.0, "YEAR": 8766.0}
APPROX_TIME_UNITS = {"MONTHS", "MONTH", "YEARS", "YEAR"}
HYDROLOGY_UNITS = {"REFHBDY", "FEHBDY", "FSRBDY", "FSSR16BDY", "REFH2BDY", "SCSBDY", "GERRBDY", "REBDY", "NCDBDY",
                   "TIDBDY", "FRQSIM"}
STRUCTURE_UNITS = {"BRIDGE", "SPILL", "SLUICE", "ORIFICE", "WEIR", "RNWEIR", "CRUMP", "FLAT-V WEIR", "NOTWEIR",
                   "GATED WEIR", "LABYRINTH WEIR", "SCWEIR", "QH CONTROL", "QRATING", "OCPUMP", "SYPHON",
                   "INVERTED SYPHON", "OUTFALL", "FLOOD RELIEF", "FLOOD RELIEF ARCH", "BREACH", "BERNOULLI"}


def _f(text, default=None):
    try:
        return float(str(text).strip())
    except (TypeError, ValueError):
        return default


def _cols(line, width=10, n=12):
    line = line.rstrip("\n").ljust(width * n)
    return [line[i * width:(i + 1) * width] for i in range(n)]


def _read_lines(path):
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            with io.open(path, "r", encoding=enc) as f:
                return [l.rstrip("\r\n") for l in f]
        except UnicodeDecodeError:
            continue
    return []


def find_file(p):
    """Flood Modeller runs on Windows, so file names are case-insensitive: find the real name."""
    if not p or os.path.exists(p):
        return p
    folder, name = os.path.split(p)
    folder = find_file(folder) if folder and not os.path.isdir(folder) else folder
    try:
        for n in os.listdir(folder or "."):
            if n.lower() == name.lower():
                return os.path.join(folder, n)
    except OSError:
        pass
    return p


def resolve(path, base_dir):
    if not path:
        return ""
    p = path.strip().strip('"').replace("\\", os.sep).replace("/", os.sep)
    if not os.path.isabs(p) and not re.match(r"^[A-Za-z]:", p):
        p = os.path.normpath(os.path.join(base_dir, p))
    return find_file(p)


# ---------------------------------------------------------------------------
class Unit(object):
    def __init__(self, kind, subtype="", labels=None, comment=""):
        self.kind = kind
        self.subtype = subtype
        self.labels = [l for l in (labels or [])]
        self.comment = comment
        self.dist = 0.0                 # distance to next node (m)
        self.data = []                  # unit-specific rows
        self.params = {}

    @property
    def label(self):
        return self.labels[0] if self.labels else ""

    def __repr__(self):
        return "Unit({} {} {})".format(self.kind, self.subtype, self.labels[:4])


class Section(Unit):
    """RIVER SECTION: rows of (offset, elevation, n, panel, rpl, marker, easting, northing)."""

    def points(self):
        return [(r[6], r[7]) for r in self.data if r[6] is not None and r[7] is not None]

    def thalweg(self):
        """Easting / northing of the BED marker, else the lowest point that has coordinates."""
        for r in self.data:
            if r[5].strip().upper().startswith("BED") and r[6] is not None and r[7] is not None:
                return (r[6], r[7])
        pts = [r for r in self.data if r[6] is not None and r[7] is not None]
        if not pts:
            return None
        low = min(pts, key=lambda r: r[1])
        return (low[6], low[7])

    def bed_level(self):
        return min((r[1] for r in self.data), default=None)


class Boundary(Unit):
    """QTBDY / HTBDY / QHBDY: rows of (time_h, value) or (head, flow) for QHBDY."""


class FmDat(object):
    def __init__(self, path=""):
        self.path = path
        self.title = ""
        self.label_len = 12
        self.units = []
        self.gisinfo = {}          # label -> (x, y)
        self.gxy = {}              # 'TYPE_SUBTYPE_LABEL' / label -> (x, y)
        self.unknown = []

    # -- lookups -------------------------------------------------------------
    def sections(self):
        return [u for u in self.units if isinstance(u, Section)]

    def boundaries(self):
        return [u for u in self.units if isinstance(u, Boundary)]

    def of_kind(self, *kinds):
        return [u for u in self.units if u.kind in kinds]

    def node_xy(self, label):
        """Best location for a node label: section thalweg, then .gxy, then GISINFO."""
        for u in self.units:
            if isinstance(u, Section) and u.label == label:
                t = u.thalweg()
                if t:
                    return t
        for key, xy in self.gxy.items():
            if key == label or key.endswith("_" + label):
                return xy
        xy = self.gisinfo.get(label)
        if xy and (abs(xy[0]) > 0 or abs(xy[1]) > 0):
            return xy
        return None


def _split_blocks(lines, start=0):
    """[(keyword, [block lines])] for every unit block from line index `start`."""
    blocks, cur, kw = [], [], None
    i = start
    in_comment = 0
    while i < len(lines):
        line = lines[i]
        if in_comment:
            cur.append(line)
            in_comment -= 1
            i += 1
            continue
        word = line.split(" ")[0].strip() if line.strip() else ""
        two = " ".join(line.split()[:2])
        three = " ".join(line.split()[:3])
        key = three if three in UNIT_KEYWORDS else (two if two in UNIT_KEYWORDS else
                                                    (word if word in UNIT_KEYWORDS else None))
        if key == "FLOODPLAIN" and two == "FLOODPLAIN SECTION":
            key = "FLOODPLAIN"
        if key is not None and line == line.lstrip():
            if kw is not None:
                blocks.append((kw, cur))
            kw, cur = key, [line]
            if key == "COMMENT" and i + 1 < len(lines):
                n = int(_f(lines[i + 1], 0) or 0)
                cur.append(lines[i + 1])
                in_comment = n
                i += 2
                continue
            if key == "GISINFO":
                blocks.append((kw, lines[i:]))
                return blocks
        elif kw is not None:
            cur.append(line)
        i += 1
    if kw is not None:
        blocks.append((kw, cur))
    return blocks


def _labels(line, n):
    line = line.rstrip()
    out = []
    for i in range(0, max(len(line), n), n):
        out.append(line[i:i + n].strip())
    while out and not out[-1]:
        out.pop()
    return out


def _boundary(kw, block, label_len):
    b = Boundary(kw, "", [block[1][:label_len].strip()] if len(block) > 1 else [], block[0][len(kw):].strip())
    if len(block) < 3:
        return b
    p = _cols(block[2])
    n = int(_f(p[0], 0) or 0)
    if kw == "QTBDY":
        unit = (p[3].strip() or "HOURS").upper()
        b.params = {"time_unit": unit, "multiplier": _f(p[6], 0) or 1.0, "offset": _f(p[1], 0) or 0.0}
    elif kw == "HTBDY":
        unit = (p[2].strip() or "HOURS").upper()
        if unit in ("EXTEND", "NOEXTEND", "REPEAT") and p[3].strip().upper() in TIME_FACTORS:
            unit = p[3].strip().upper()
        b.params = {"time_unit": unit, "multiplier": 1.0, "offset": 0.0}
    else:
        b.params = {"time_unit": "", "multiplier": 1.0, "offset": 0.0}
    factor = TIME_FACTORS.get(b.params["time_unit"], 1.0)
    for row in block[3:3 + n]:
        c = _cols(row)
        a, t = _f(c[0]), _f(c[1])
        if a is None or t is None:
            continue
        if kw == "QHBDY":
            b.data.append((t, a))                         # (head, flow)
        else:
            mult = b.params["multiplier"] if kw == "QTBDY" and b.params["multiplier"] else 1.0
            b.data.append(((t + b.params["offset"]) * factor, a * mult))     # (hours, value)
    if b.params.get("time_unit") == "DATES":
        b.params["note"] = "uses calendar dates - times not converted"
    elif b.params.get("time_unit") in APPROX_TIME_UNITS:
        b.params["note"] = "times in {} converted with an average length".format(b.params["time_unit"].lower())
    return b


def _section(block, label_len):
    labels = _labels(block[2] if len(block) > 2 else "", label_len)
    s = Section("RIVER", "SECTION", labels, block[0][5:].strip())
    p = _cols(block[3] if len(block) > 3 else "")
    s.dist = _f(p[0], 0.0) or 0.0
    s.params = {"slope": _f(p[2], 0.0001), "density": _f(p[3], 1000.0)}
    n = int(_f(_cols(block[4])[0], 0) or 0) if len(block) > 4 else 0
    for row in block[5:5 + n]:
        c = _cols(row)
        x, z, mann = _f(c[0]), _f(c[1]), _f(c[2])
        if x is None or z is None:
            continue
        panel = c[3].strip().startswith("*")
        rpl = _f(c[3].strip().lstrip("*"), 0.0)
        e, nn = _f(c[5]), _f(c[6])
        if not e and not nn:                 # 0, 0 = no coordinates
            e = nn = None
        s.data.append((x, z, mann, panel, rpl, c[4], e, nn))
    return s


SUBTYPE_UNITS = {"BRIDGE", "SLUICE", "ORIFICE", "JUNCTION", "CULVERT", "FLOODPLAIN", "RIVER", "CONDUIT",
                 "FLOOD RELIEF", "OUTFALL", "INVERTED SYPHON", "POND"}
# (line index, column) of breadth / crest for weir-like units, from the unit layouts
WEIR_FIELDS = {"RNWEIR": (2, 2, 3), "WEIR": (3, 2, 3), "CRUMP": (2, 1, 2), "FLAT-V WEIR": (2, 1, 2),
               "SLUICE": (3, 2, 3), "NOTWEIR": (2, 1, 2), "SCWEIR": (2, 1, 2), "GATED WEIR": (3, 2, 3)}


def _section_table(block, first=3):
    """First 'n' line followed by n rows of (offset, elevation[, n]) - e.g. a bridge opening."""
    i = first
    while i < len(block) - 1:
        c = _cols(block[i])
        n = _f(c[0])
        if n is not None and float(n).is_integer() and n >= 2 and not any(x.strip() for x in c[1:]) \
                and i + int(n) < len(block):
            rows = []
            for row in block[i + 1:i + 1 + int(n)]:
                r = _cols(row)
                x, z = _f(r[0]), _f(r[1])
                if x is None or z is None:
                    rows = []
                    break
                rows.append((x, z, _f(r[2])))
            if rows:
                return rows
        i += 1
    return []


def _structure(kw, block, label_len):
    has_sub = kw in SUBTYPE_UNITS
    sub = block[1].split()[0] if has_sub and len(block) > 1 and block[1].strip() else ""
    lab_line = block[2] if has_sub and len(block) > 2 else (block[1] if len(block) > 1 else "")
    u = Unit(kw, sub, _labels(lab_line, label_len), block[0][len(kw):].strip())
    u.data = block
    if kw == "FLOODPLAIN" and len(block) > 4:
        # labels / coefficients / n rows of (chainage, elevation, n, easting, northing)
        n = int(_f(_cols(block[4])[0], 0) or 0)
        pts = []
        for row in block[5:5 + n]:
            r = _cols(row)
            pts.append((_f(r[0]), _f(r[1]), _f(r[3]), _f(r[4])))
        u.params["profile"] = [p for p in pts if p[0] is not None and p[1] is not None]
    if kw == "SPILL":
        # labels / coefficients / n rows of (chainage, elevation, [easting, northing])
        c = _cols(block[2]) if len(block) > 2 else _cols("")
        u.params = {"cd": _f(c[0], 1.2), "modular_limit": _f(c[1], 0.9)}
        n = int(_f(_cols(block[3])[0], 0) or 0) if len(block) > 3 else 0
        pts = []
        for row in block[4:4 + n]:
            r = _cols(row)
            pts.append((_f(r[0]), _f(r[1]), _f(r[2]), _f(r[3])))
        u.params["profile"] = [p for p in pts if p[0] is not None and p[1] is not None]
    elif kw in WEIR_FIELDS and len(block) > WEIR_FIELDS[kw][0]:
        li, cb, cz = WEIR_FIELDS[kw]
        c = _cols(block[li])
        u.params = {"breadth": _f(c[cb]), "crest": _f(c[cz])}
    elif kw == "ORIFICE" and len(block) > 3:
        c = _cols(block[3])
        u.params = {"invert": _f(c[0]), "soffit": _f(c[1]), "area": _f(c[2]), "shape": c[5].strip()}
    elif kw == "BRIDGE":
        u.params["section"] = _section_table(block, 3)
    return u


def _conduit(block, label_len):
    sub = block[1].split()[0] if len(block) > 1 and block[1].strip() else ""
    u = Unit("CONDUIT", sub, _labels(block[2] if len(block) > 2 else "", label_len), block[0][7:].strip())
    u.dist = _f(_cols(block[3])[0], 0.0) if len(block) > 3 else 0.0
    if sub in ("CIRCULAR", "RECTANGULAR", "SPRUNG", "SPRUNGARCH", "FULLARCH") and len(block) > 5:
        c = _cols(block[5])
        u.params["invert"] = _f(c[0])
        if sub == "CIRCULAR":
            u.params["diameter"] = _f(c[1])
        else:
            u.params["width"] = _f(c[1])
            u.params["height"] = _f(c[2]) if sub == "RECTANGULAR" else _f(c[3]) or _f(c[2])
        if len(block) > 6:
            fr = _cols(block[6])
            u.params["n"] = _f(fr[0]) if sub == "CIRCULAR" else _f(fr[0])
    return u


def read_dat(path):
    """Parse a .dat (or .ied) file."""
    d = FmDat(path)
    lines = _read_lines(path)
    if not lines:
        return d
    d.title = lines[0].strip()
    start = 0
    for i, l in enumerate(lines[:12]):
        if l.strip().upper() == "END GENERAL":
            start = i + 1
            break
    # general header: label length is the 6th number on the parameter line
    for l in lines[1:4]:
        c = _cols(l)
        if _f(c[5]) and 4 <= _f(c[5]) <= 64 and _f(c[0]) is not None:
            d.label_len = int(_f(c[5]))
            break
    if start == 0 and not lines[0].strip() in UNIT_KEYWORDS:
        # files without END GENERAL (old revision): skip the 4-5 line header to the first unit
        for i, l in enumerate(lines[:12]):
            if l.split(" ")[0] in UNIT_KEYWORDS:
                start = i
                break
    for kw, block in _split_blocks(lines, start):
        try:
            if kw == "GISINFO":
                for row in block[1:]:
                    parts = row.split()
                    nums = [i for i, t in enumerate(parts) if re.match(r"^-?\d+(\.\d+)?$", t)]
                    if len(parts) >= 3 and nums and len(parts) - nums[0] >= 2:
                        label = parts[nums[0] - 1]
                        x, y = float(parts[nums[0]]), float(parts[nums[0] + 1])
                        d.gisinfo.setdefault(label, (x, y))
                continue
            if kw == "RIVER" and len(block) > 1 and block[1].strip().upper().startswith("SECTION"):
                d.units.append(_section(block, d.label_len))
            elif kw in ("QTBDY", "HTBDY", "QHBDY"):
                d.units.append(_boundary(kw, block, d.label_len))
            elif kw == "RIVER":            # CES SECTION, MUSKINGUM ...: kept as a reach unit
                u = _structure("RIVER", block, d.label_len)
                u.subtype = block[1].strip().upper() if len(block) > 1 else ""
                u.dist = _f(_cols(block[3])[0], 0.0) if len(block) > 3 else 0.0
                d.units.append(u)
            elif kw == "CONDUIT":
                d.units.append(_conduit(block, d.label_len))
            elif kw in ("INTERPOLATE", "REPLICATE"):
                u = Unit(kw, "", _labels(block[1] if len(block) > 1 else "", d.label_len))
                u.dist = _f(_cols(block[2])[0], 0.0) if len(block) > 2 else 0.0
                if kw == "REPLICATE" and len(block) > 2:
                    u.params["bed_drop"] = _f(_cols(block[2])[1], 0.0)
                d.units.append(u)
            elif kw in ("COMMENT", "INITIAL CONDITIONS", "VARIABLES"):
                continue
            elif kw in ("JUNCTION", "CULVERT", "FLOODPLAIN") or kw in STRUCTURE_UNITS:
                d.units.append(_structure(kw, block, d.label_len))
            else:
                u = Unit(kw, "", _labels(block[1] if len(block) > 1 else "", d.label_len))
                u.data = block
                d.units.append(u)
        except Exception as ex:          # keep going - report the unit
            d.unknown.append("{}: {}".format(kw, ex))
    gxy = os.path.splitext(path)[0] + ".gxy"
    if os.path.isfile(gxy):
        d.gxy = read_gxy(gxy)
    return d


def read_gxy(path):
    out, key, x = {}, None, None
    for line in _read_lines(path):
        s = line.strip()
        m = re.match(r"^\[(.+)\]$", s)
        if m:
            key, x = m.group(1), None
            continue
        if key and s.upper().startswith("X="):
            x = _f(s[2:])
        elif key and s.upper().startswith("Y=") and x is not None:
            y = _f(s[2:])
            if y is not None and (x or y):
                out[key] = (x, y)
                parts = key.split("_", 2)
                if len(parts) == 3 and parts[2]:
                    out.setdefault(parts[2], (x, y))
    return out


# ---------------------------------------------------------------------------
class FmIef(object):
    def __init__(self, path=""):
        self.path = path
        self.values = {}            # lower-case key -> value (last one wins)
        self.event_data = []        # .ied paths (resolved)
        self.flow_time_profiles = []

    def get(self, key, default=""):
        return self.values.get(key.lower(), default)

    @property
    def title(self):
        return self.get("title") or os.path.splitext(os.path.basename(self.path))[0]

    @property
    def datafile(self):
        return resolve(self.get("datafile"), os.path.dirname(self.path)) if self.get("datafile") else ""

    @property
    def file_2d(self):
        v = self.get("2dfile")
        return resolve(v, os.path.dirname(self.path)) if v else ""

    def hours(self, key):
        return _f(self.get(key))


def read_ief(path):
    ief = FmIef(path)
    base = os.path.dirname(path)
    for line in _read_lines(path):
        s = line.strip()
        if not s or s.startswith(";") or s.startswith("["):
            continue
        if "=" not in s:
            continue
        k, v = [x.strip() for x in s.split("=", 1)]
        kl = k.lower()
        if kl == "eventdata":
            ief.event_data.append(resolve(v, base))
            continue
        if kl.startswith("flowtimeprofile"):
            ief.flow_time_profiles.append(v)
            continue
        ief.values[kl] = v
    return ief


# ---------------------------------------------------------------------------
class Fm2dBoundary(object):
    def __init__(self):
        self.bc_type = ""            # waterelevation, totalflow, verticalflow ...
        self.file = ""
        self.xy = ""
        self.value_type = ""         # timevar, fixedvalue, ied, csv, hydrologyunit
        self.value = ""
        self.time_units = "second"
        self.header_label = ""


class Fm2dDomain(object):
    def __init__(self):
        self.name = ""
        self.xll = self.yll = self.dx = None
        self.nrows = self.ncols = None
        self.rotation = 0.0
        self.active_area = ""
        self.deactive_area = ""
        self.topography = []         # raster / shape files
        self.zlines = []             # (file, type)
        self.start_h = 0.0
        self.total_h = None
        self.timestep = None
        self.scheme = ""
        self.drydepth = None
        self.ic_type = ""
        self.ic_value = ""
        self.roughness = []          # (law, type, value) value = number or shp path
        self.boundaries = []
        self.output_vars = []
        self.output_freq = None
        self.output_format = ""


class Fm2d(object):
    def __init__(self, path=""):
        self.path = path
        self.name = ""
        self.unit_system = "SI"
        self.link_files = []
        self.link_ief = ""
        self.domains = []


def _strip_ns(root):
    for el in root.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def _hours(value, unit):
    v = _f(value)
    if v is None:
        return None
    return v * {"second": 1 / 3600.0, "minute": 1 / 60.0, "hour": 1.0, "day": 24.0}.get((unit or "second").lower(),
                                                                                    1 / 3600.0)


def read_xml2d(path):
    m = Fm2d(path)
    base = os.path.dirname(path)
    root = _strip_ns(ET.parse(path).getroot())
    m.name = root.get("name", "")
    m.unit_system = root.get("unit_system", "SI")
    for lk in root.findall("link1d"):
        for l in lk.findall("link"):
            if (l.text or "").strip():
                m.link_files.append(resolve(l.text, base))
        ief = lk.find("ief")
        if ief is not None and (ief.text or "").strip():
            m.link_ief = resolve(ief.text, base)
    for dom in root.findall("domain"):
        d = Fm2dDomain()
        d.name = dom.get("domain_id", "")
        ca = dom.find("computational_area")
        if ca is not None:
            g = lambda k: (ca.find(k).text if ca.find(k) is not None else None)
            d.xll, d.yll, d.dx = _f(g("xll")), _f(g("yll")), _f(g("dx"))
            d.nrows, d.ncols = int(_f(g("nrows"), 0) or 0), int(_f(g("ncols"), 0) or 0)
            d.rotation = _f(g("rotation"), 0.0) or 0.0
            d.active_area = resolve(g("active_area"), base) if g("active_area") else ""
            d.deactive_area = resolve(g("deactive_area"), base) if g("deactive_area") else ""
        for t in dom.findall("topography"):
            if (t.text or "").strip():
                d.topography.append(resolve(t.text, base))
        for t2 in dom.findall("topography_2"):
            kind = t2.get("type", "standard")
            for fm in t2.iter("fmfile"):
                p = resolve(fm.text, base)
                if kind == "standard" and os.path.splitext(p)[1].lower() != ".shp":
                    d.topography.append(p)
                else:
                    d.zlines.append((p, kind))
        tm = dom.find("time")
        if tm is not None:
            tot = tm.find("total")
            if tot is not None:
                d.total_h = _hours(tot.text, tot.get("unit", "second"))
            off = tm.find("start_offset")
            if off is not None:
                d.start_h = _hours(off.text, off.get("unit", "second")) or 0.0
        rd = dom.find("run_data")
        if rd is not None:
            d.timestep = _f(rd.findtext("time_step"))
            d.scheme = (rd.findtext("scheme") or "").strip()
            d.drydepth = _f(rd.findtext("drydepth"))
        ic = dom.find("initial_conditions")
        if ic is not None:
            d.ic_type = ic.get("type", "")
            d.ic_value = (ic.text or "").strip()
            if d.ic_type.endswith("file"):
                d.ic_value = resolve(d.ic_value, base)
        for r in dom.findall("roughness"):
            val = (r.text or "").strip()
            if r.get("type", "global") == "file":
                val = resolve(val, base)
            d.roughness.append((r.get("law", "manning"), r.get("type", "global"), val,
                                _f(r.get("default_roughness"))))
        bcs = dom.find("boundary_conditions")
        if bcs is not None:
            for b in bcs.findall("boundary"):
                bc = Fm2dBoundary()
                bc.bc_type = (b.findtext("BC") or "").strip().lower()
                f = b.findtext("file")
                bc.file = resolve(f, base) if f and f.strip() else ""
                bc.xy = (b.findtext("xy") or "").strip()
                v = b.find("value")
                if v is not None:
                    bc.value_type = v.get("type", "")
                    bc.value = (v.text or "").strip()
                    bc.time_units = v.get("time_units", "second")
                    bc.header_label = v.get("header_label", "")
                    if bc.value_type in ("csv", "hpcsv", "ied", "hydrologyunit") and bc.value:
                        bc.value = resolve(bc.value, base) if bc.value_type != "ied" or \
                            os.path.splitext(bc.value)[1] else bc.value
                d.boundaries.append(bc)
        out = dom.find("output_results")
        if out is not None:
            o = out.find("output")
            if o is not None:
                d.output_format = o.get("format", "")
                d.output_vars = [v.strip() for v in (o.findtext("variables") or "").split() if v.strip()]
                d.output_freq = _f(o.findtext("frequency"))
        m.domains.append(d)
    return m


# ---------------------------------------------------------------------------
class FmProject(object):
    """Everything found from one starting file (ief, dat or xml), with notes on what was read."""

    def __init__(self):
        self.source = ""
        self.ief = None
        self.dat = None
        self.events = []             # FmDat of each .ied
        self.xml = None
        self.notes = []

    @property
    def name(self):
        if self.ief is not None:
            return self.ief.title
        for f in (self.xml, self.dat):
            if f is not None:
                return os.path.splitext(os.path.basename(f.path))[0]
        return "FM_model"

    def boundary_units(self):
        """Boundary units of the network, overridden by the event data (.ied) files in order."""
        out = {}
        if self.dat is not None:
            for b in self.dat.boundaries():
                out[b.label] = b
        for ev in self.events:
            for b in ev.boundaries():
                out[b.label] = b
        return out

    def summary(self):
        s = []
        if self.ief is not None:
            s.append("Event file: {}".format(os.path.basename(self.ief.path)))
        if self.dat is not None:
            kinds = {}
            for u in self.dat.units:
                k = u.kind + (" " + u.subtype if u.kind in ("CONDUIT", "BRIDGE", "RIVER") and u.subtype else "")
                kinds[k] = kinds.get(k, 0) + 1
            s.append("1D network {}: {}".format(os.path.basename(self.dat.path), ", ".join(
                "{} {}{}".format(v, k.lower(), "s" if v > 1 and not k.endswith(("S", "H")) else "")
                for k, v in sorted(kinds.items(), key=lambda kv: -kv[1]))))
        for ev in self.events:
            s.append("Event data {}: {} boundaries".format(os.path.basename(ev.path), len(ev.boundaries())))
        if self.xml is not None:
            for d in self.xml.domains:
                s.append("2D domain '{}': {} x {} cells of {} m, {} boundary condition(s)".format(
                    d.name, d.ncols, d.nrows, d.dx, len(d.boundaries)))
        return s


def read_project(path):
    p = FmProject()
    p.source = path
    ext = os.path.splitext(path)[1].lower()
    if ext == ".ief":
        p.ief = read_ief(path)
    elif ext == ".xml":
        p.xml = read_xml2d(path)
        if p.xml.link_ief and os.path.isfile(p.xml.link_ief):
            p.ief = read_ief(p.xml.link_ief)
    elif ext in (".dat", ".ied"):
        p.dat = read_dat(path)
    else:
        raise ValueError("Pick a Flood Modeller .ief, .dat or .xml file")
    if p.ief is not None:
        if p.dat is None and p.ief.datafile:
            if os.path.isfile(p.ief.datafile):
                p.dat = read_dat(p.ief.datafile)
            else:
                p.notes.append("1D data file not found: {}".format(p.ief.datafile))
        for ied in p.ief.event_data:
            if os.path.isfile(ied):
                p.events.append(read_dat(ied))
            else:
                p.notes.append("Event data file not found: {}".format(ied))
        f2 = p.ief.file_2d
        if p.xml is None and f2:
            if f2.lower().endswith(".xml") and os.path.isfile(f2):
                p.xml = read_xml2d(f2)
            elif f2.lower().endswith(".tcf"):
                p.notes.append("The event file is already linked to a TUFLOW model: {}".format(f2))
            elif not os.path.isfile(f2):
                p.notes.append("2D file not found: {}".format(f2))
    return p
