# -*- coding: utf-8 -*-
"""
Command index for every TUFLOW Classic/HPC control file.

Each line is "<command syntax as listed in the manual> @@ <manual anchor>".
The syntax strings follow the TUFLOW convention:
    {x}    default value
    <x>    user supplied value
    a | b  alternatives
    [ .. ] optional modifier on the left of '=='

Only command *names and syntax* are listed here (facts, not prose). Explanations
are always taken from the official manual through the per-command help link,
so this plugin never redistributes manual text.

Source: TUFLOW Classic/HPC User Manual 2026.3, Appendices A-K.
Refresh this file when a new manual release adds commands.
"""

MANUAL_VERSION = "2026.3"
MANUAL_ROOT = "https://docs.tuflow.com/classic-hpc/manual/{ver}/".format(ver=MANUAL_VERSION)
MANUAL_LATEST = "https://docs.tuflow.com/classic-hpc/manual/latest/"

APPENDIX_PAGES = {
    "TCF": "80-AppendicesA-TCFCommands.html",
    "ECF": "81-AppendicesB-ECFCommands.html",
    "TGC": "82-AppendicesC-TGCCommands.html",
    "TBC": "83-AppendicesD-TBCCommands.html",
    "TOC": "84-AppendicesE-TOCCommands.html",
    "TRFC": "85-AppendicesF-TRFCCommands.html",
    "TESF": "86-AppendicesG-TESFCommands.html",
    "QCF": "87-AppendicesH-QCFCommands.html",
    "TSCF": "88-AppendicesI-TSCFCommands.html",
    "ADCF": "89-AppendicesJ-ADCFCommands.html",
    "TEF": "90-AppendicesK-TEFCommands.html",
}

# Logic / block keywords (If Scenario / If Event blocks) - allowed in the control
# files whose appendix lists them.
LOGIC_COMMANDS = """
If Scenario == <s1> | <s2> | <s3> | ... @@ IfScenario
Else If Scenario == <s1> | <s2> | <s3> | ... @@ IfScenario
If Event == <e1> | <e2> | <e3> | ... @@ IfEvent
Else If Event == <e1> | <e2> | <e3> | ... @@ IfEvent
Else @@ IfScenario
End If @@ IfScenario
"""
READ_FILE_COMMAND = "Read File == <file> @@ ReadFile\n"
PAUSE_COMMAND = "Pause == <message> @@ Pause\n"
EXTRA_BY_TYPE = {
    "TCF": LOGIC_COMMANDS + READ_FILE_COMMAND + PAUSE_COMMAND,
    "TGC": LOGIC_COMMANDS + READ_FILE_COMMAND,
    "ECF": LOGIC_COMMANDS + READ_FILE_COMMAND,
    "TBC": LOGIC_COMMANDS, "TOC": LOGIC_COMMANDS, "QCF": LOGIC_COMMANDS, "TRFC": LOGIC_COMMANDS,
    "TSCF": LOGIC_COMMANDS, "TESF": "", "ADCF": "", "TEF": "",
}
# kept for backward compatibility
COMMON_BLOCK_COMMANDS = LOGIC_COMMANDS + READ_FILE_COMMAND + PAUSE_COMMAND

TCF = """
AD Control File == <.adcf_file> @@ tcf-ADControlFile
Adjust Head at ESTRY Interface == ON | ON Variable | {OFF} @@ tcf-AdjustHeadatESTRYInterface
Auto Terminate dV Cell Tolerance == {0%} | <value> @@ tcf-AutoTerminatedVCellTolerance
Auto Terminate dV Value Tolerance == {0} | <value> @@ tcf-AutoTerminatedVValueTolerance
Auto Terminate Start Time == {Simulation Start Time} | <value> @@ tcf-AutoTerminateStartTime
Auto Terminate Wet Cell Tolerance == {0} | <value> @@ tcf-AutoTerminateWetCellTolerance
BC Control File == <.tbc_file> @@ tcf-BCControlFile
BC Database == <.csv_file> @@ tcf-BCDatabase
BC Event Name == <bc_event_name> @@ tcf-BCEventName
BC Event Source == <bc_event_text> | <bc_event_name> @@ tcf-BCEventSource
BC Event Text == <bc_event_text> @@ tcf-BCEventText
BC Wet/Dry Method == PRE 2005-11-AF @@ tcf-BCWetDryMethod
BC Zero Flow == {OFF} | START | END | START and END @@ tcf-BCZeroFlow
Bed Resistance Cell Sides == AVERAGE M | AVERAGE n | MAXIMUM n | {INTERROGATE} @@ tcf-BedResistanceCellSides
Bed Resistance Depth Interpolation == LINEAR M | {SPLINE n} | LINEAR n @@ tcf-BedResistanceDepthInterpolation
Bed Resistance Values == {MANNING N} | MANNING M | CHEZY @@ tcf-BedResistanceValues
BG FLC Default Approach == {LINEAR} | LINEAR-CONSTANT | PARABOLIC | INVERTED-PARABOLIC @@ tcf-BGFLCDefaultApproach
Blank BG FLC Approach == {NONE} | METHOD A | METHOD B @@ tcf-BlankBGFLCApproach
Blockage AEP == <aep_value_in_%> @@ tcf-BlockageAEP
Blockage ARI == <ari_value_in_years> @@ tcf-BlockageARI
Blockage Default == <Default_Blockage_Category> @@ tcf-BlockageDefault
Blockage ELM Method == FLC | {SPLIT} @@ tcf-BlockageELMMethod
Blockage Matrix == {OFF} | ON @@ tcf-BlockageMatrix
Blockage Matrix File == <blockage_csv_file> @@ tcf-BlockageMatrixFile
Blockage Method == ELM | RAM @@ tcf-BlockageMethod
Blockage Override == <Blockage_Category> @@ tcf-BlockageOverride
Blockage PMF AEP == <aep_value> @@ tcf-BlockagePMFAEP
Blockage PMF ARI == <ari_value_in_years> @@ tcf-BlockagePMFARI
Blockage Return Period == AEP | ARI @@ tcf-BlockageReturnPeriod
Blue Kenue Start Date == <date_in_isodate_format> @@ tcf-BlueKenueStartDate
Boundary Viscosity Factor == {1.0} | <factor> @@ tcf-BoundaryViscosityFactor
BSS Cutoff Depth == {0.1} | <BSS_cutoff_depth> @@ tcf-BSSCutoffDepth
Calibration Points MI File == <mif_layer> @@ tcf-CalibrationPointsMIFile
Cell Side Wet/Dry Depth == {0.001} | <depth_in_m> @@ tcf-CellSideWetDryDepth
Cell Size == <value_in_metres> @@ tcf-CellSize
Cell Wet/Dry Depth == {0.002} | <wet/dry_depth> @@ tcf-CellWetDryDepth
Change Zero Material Values to One == ON | {OFF} @@ tcf-ChangeZeroMaterialValuestoOne
Check Inside Grid == {ERROR} | WARNING | OFF @@ tcf-CheckInsideGrid
Check MI Save Date == {ERROR} | WARNING | OFF @@ tcf-CheckMISaveDate
Check MI Save Ext == {.tab} | <ext> @@ tcf-CheckMISaveExt
Command Line Processing == {2016} | Pre 2016 @@ tcf-CommandLineProcessing
Control Number Factor == {1.0} | <CN_value> @@ tcf-ControlNumberFactor
CPU Threads == {4} | <number_of_CPU_threads> @@ tcf-CPUThreads
CSV Header Line == {} | SINGLE @@ tcf-CSVHeaderLine
CSV Maximum Number Columns == <max_col> @@ tcf-CSVMaximumNumberColumns
CSV Time == DAYS | {HOURS} | MINUTES | SECONDS @@ tcf-CSVTime
Defaults == PRE 2026 | PRE 2025 | PRE 2023 | PRE 2020-10-AB | PRE 2020-10 | PRE 2020-01 | PRE 2017 | PRE 2016 | PRE 2013 | PRE 2012 | PRE 2010 | PRE 2008-08 | PRE 2007-07-AA | PRE 2006-06-AA @@ tcf-Defaults
Define Output Zone == <oz_name> @@ tcf-DefineOutputZone
Demo Model == ON | {OFF} @@ tcf-DemoModel
Density of Air == {1.25} | <value> @@ tcf-DensityofAir
Density of Water == {1025} | <value> @@ tcf-DensityofWater
Depth/Ripple Height Factor Limit == {10} | <value> @@ tcf-DepthRippleHeightFactorLimit
Display Water Level == <X>, <Y> @@ tcf-DisplayWaterLevel
Distribute HX Flows == ON | {OFF} @@ tcf-DistributeHXFlows
End 1D Domain @@ tcf-End1DDomain
End 2D Domain @@ tcf-End2DDomain
End After Maximum == <time_in_hours> | <h_tol> @@ tcf-EndAfterMaximum
End After Maximum Start Time == {0} | <time_in_hours> @@ tcf-EndAfterMaximumStartTime
End Define @@ tcf-EndDefine
End Map Output == <time_in_hours> @@ tcf-EndMapOutput
End Time == <time_in_hours> @@ tcf-EndTime
ESTRY Control File [ {} | Auto ] == <.ecf_file> @@ tcf-ESTRYControlFile
Event File == <.tef_file> @@ tcf-EventFile
Excel Start Date == <days_since_1900> @@ tcf-ExcelStartDate
External Stress File == <.tesf_file> @@ tcf-ExternalStressFile
FEWS Geodatum == <geodatum_string> @@ tcf-FEWSGeodatum
FEWS Input File == <FEWS_boundary_file> @@ tcf-FEWSInputFile
File Retry Max Count == {40} | <max_count> @@ tcf-FileRetryMaxCount
File Retry Timeout == {30} | <max_time> @@ tcf-FileRetryTimeout
First Sweep Direction == AUTOMATIC | {POSITIVE} | NEGATIVE @@ tcf-FirstSweepDirection
Force File IO Display == ON | {OFF} @@ tcf-ForceFileIODisplay
Form Loss Rotational Adjustment == {ON POLYLINE} | ON | OFF @@ tcf-FormLossRotationalAdjustment
Free Overfall == {ON} | ON WITHOUT WEIRS | OFF @@ tcf-FreeOverfall
Free Overfall Factor == {0.6} | <value_0.0_to_1.0> @@ tcf-FreeOverfallFactor
Froude Check == {1} | <froude_no> @@ tcf-FroudeCheck
Froude Depth Adjustment == {ON} | OFF @@ tcf-FroudeDepthAdjustment
GA Convergence Value == {0.001} | <value> @@ tcf-GAConvergenceValue
GA Maximum Iterations == {ON} | OFF @@ tcf-GAMaximumIterations
GDAL Raster Create Options == <raster_format> | <creation_options> @@ tcf-GDALRasterCreateOptions
GDAL VRT Resample Approach Float == {bilinear} | nearest | cubic | cubicspline | lanczos | average | max | min | med | q1 | q3 @@ tcf-GdalVrtResampleApproachFloat
GDAL VRT Resample Approach Integer == {nearest} | mode @@ tcf-GdalVrtResampleApproachInteger
Geometry Control File == <.tgc_file> @@ tcf-GeometryControlFile
GIS Format == {MIF} | SHP | GPKG @@ tcf-GISFormat
GIS Grid Vector Direction == {ANGLE} | BEARING | VERBOSE @@ tcf-GISGridVectorDirection
GIS Grid Vector SF == {1} | <scale_factor> @@ tcf-GISGridVectorSF
GIS Grid Vector TTF == {0} | <tail_thickness_factor> @@ tcf-GISGridVectorTTF
GIS Grid Vector Type == {Region} | Point @@ tcf-GISGridVectorType
GIS Project Path Format == Absolute | {Relative} @@ tcf-GISProjectPathFormat
GIS Projection Check == {ERROR} | WARNING @@ tcf-GISProjectionCheck
GIS Supported Object Ignored == ERROR | {WARNING} @@ tcf-GISSupportedObjectIgnored
GIS Unsupported Object == {ERROR} | WARNING | <level> @@ tcf-GISUnsupportedObject
Global FC Ch Factor == {0.8} | <Ch> @@ tcf-GlobalFCChFactor
Global Rainfall Use Material Loss == OFF | {ON} @@ tcf-GlobalRainfallUseMaterialLoss
Global Weir Factor == {1.0} | <value> @@ tcf-GlobalWeirFactor
GPKG Compression == NONE | {LZW} @@ tcf-GPKGCompression
GPKG Compression Predictor == NONE | {Horizontal Differencing} @@ tcf-GPKGCompressionPredictor
GPKG Conversion Check == WARNING @@ tcf-GPKGConversionCheck
GPKG Inputs Read Only == ON | {OFF} @@ tcf-GPKGInputsReadOnly
GPKG Projection == <GPKG_layer> @@ tcf-GPKGProjection
GPU Device IDs == <list_of_device_ids> @@ tcf-GPUDeviceIDs
GPU DP Check == {ERROR} | OFF @@ tcf-GPUDPCheck
GPU Peer to Peer Access == DISABLED | {ENABLED IF AVAILABLE} @@ tcf-GPUPeertoPeerAccess
GPU Solver == ON | {OFF} @@ tcf-GPUSolver
GPU Temporal Scheme == 1 | 2 | {4} @@ tcf-GPUTemporalScheme
Grid Format == ASC | FLT | {TIF} | GPKG | NC | TGO | WRR | COG @@ tcf-GridFormat
Grid Output Cell Size == <grid_cell_size> @@ tcf-GridOutputCellSize
Grid Output Interpolation == CC EXCLUDE H | CC ALL | {TIN} @@ tcf-GridOutputInterpolation
Grid Output Origin == {AUTOMATIC} | MODEL ORIGIN @@ tcf-GridOutputOrigin
Groundwater Blend Threshold == {0.9} | <float> @@ tcf-GroundwaterBlendThreshold
Groundwater Horizontal Flux Include Porosity == ON | {OFF} @@ tcf-GroundwaterHorizontalFluxIncludePorosity
Groundwater Horizontal Flux Model == {Darcy's Law} | Soil Moisture Dependent | <exponent> @@ tcf-GroundwaterHorizontalFluxModel
Groundwater Vertical Flux Model == {Darcy's Law} | <exponent> @@ tcf-GroundwaterVerticalFluxModel
Hardware == {CPU} | GPU @@ tcf-Hardware
HEC-DSS Start Date == <value> @@ tcf-HEC-DSSStartDate
HPC 1D Synchronisation == {MAXIMISE 1D TIMESTEP} | EVERY 2D TIMESTEP | <value> @@ tcf-HPC1DSynchronisation
HPC [ Thin | Thick ] Weir Parameters == <Cd>, <Ex>, <a>, <b> @@ tcf-HPCWeirParameters
HPC Boundary Approach == Method A | Method B | {Method C} @@ tcf-HPCBoundaryApproach
HPC Cyclone Boundary Update Interval [ {} | Minute | Hour | Day ] == <time> @@ tcf-HPCCycloneBoundaryUpdateInterval
HPC Device Split == <value1, value2, ...> @@ tcf-HPCDeviceSplit
HPC DP Check == ERROR | OFF | {CHECK} @@ tcf-HPCDPCheck
HPC Dry Face Inertia Approach == Method A | {Method B} @@ tcf-HPCDryFaceInertiaApproach
HPC dt Write Interval == <number_of_timesteps> @@ tcf-HPCdtWriteInterval
HPC HQ Boundary Approach == CELL | {TOTAL} @@ tcf-HPCHQBoundaryApproach
HPC HQ Boundary Filter Constant == {5} | <float> @@ tcf-HPCHQBoundaryFilterConstant
HPC Infiltration Drying Approach == Method A | Method B | {Method C} @@ tcf-HPCInfiltrationDryingApproach
HPC Infiltration Drying Depth == <drying_depth> @@ tcf-HPCInfiltrationDryingDepth
HPC Mannings Depth Approach == Method A | {Method B} @@ tcf-HPCManningsDepthApproach
HPC Non-Newtonian Mixing Exponent == {0, 0, 0} | <float>, <float>, <float> @@ tcf-HPCNon-NewtonianMixingExponent
HPC Restart Geometry == Restart File | {TGC} @@ tcf-HPCRestartGeometry
HPC SX Momentum Approach == Method A | {Method B} @@ tcf-HPCSXMomentumApproach
HPC Temporal Scheme == 1 | 2 | {4} @@ tcf-HPCTemporalScheme
HPC Timestep Approach == Method A | {Method B} @@ tcf-HPCTimestepApproach
HPC Weir Approach == Method A | Method B | {Method B Energy} @@ tcf-HPCWeirApproach
HQ Boundary Approach == METHOD A | METHOD B | {METHOD C} @@ tcf-HQBoundaryApproach
HR Grid Output Cell Size == <distance> @@ tcf-HRGridOutputCellSize
HR Grid Output Use Face Elevations == {ON} | OFF @@ tcf-HRGridOutputUseFaceElevations
HR Interpolation Approach == Method A | Method B | {Method C} @@ tcf-HRInterpolationApproach
HR Thin Z Line Output Adjustment == OFF | {ON CELL SIDES} | ON ALIGNMENT @@ tcf-HRThinZLineOutputAdjustment
HX Force Weir Equation == ON | {OFF} | <value> @@ tcf-HXForceWeirEquation
HX ZC Check == {ON} | OFF @@ tcf-HXZCCheck
Index 1D2D Links == {ON} | OFF @@ tcf-Index1D2DLinks
Input Drive == <drive_letter> @@ tcf-InputDrive
Inside Region == METHOD A | {METHOD B} @@ tcf-InsideRegion
Instability Water Level == <value> @@ tcf-InstabilityWaterLevel
Latitude == {0} | <value_in_degrees_from_equator> @@ tcf-Latitude
Layered FLC Default Approach == METHOD A | {METHOD B} | METHOD C | METHOD D @@ tcf-LayeredFLCDefaultApproach
Line Cell Selection == METHOD A | METHOD C | {METHOD D} @@ tcf-LineCellSelection
Link 2D2D Adjust Velocity Head == {0} | <value> @@ tcf-Link2D2DAdjustVelocityHead
Link 2D2D Approach == METHOD A | METHOD B | METHOD C | {METHOD D} @@ tcf-Link2D2DApproach
Link 2D2D Distribute Flow == {ON} | OFF @@ tcf-Link2D2DDistributeFlow
Link 2D2D Global Stability Factor == {1.0} | <value> @@ tcf-Link2D2DGlobalStabilityFactor
Log Folder == <folder> @@ tcf-LogFolder
Map Cutoff Depth == {0.0} | <value_in_m> @@ tcf-MapCutoffDepth
Map Cutoff SGS == Average | {Exact} | Median | Minimum | Percentile @@ tcf-MapCutoffSGS
Map Cutoff Vector == {ON} | OFF @@ tcf-MapCutoffVector
Map Output Corner Interpolation == METHOD A | METHOD B | {METHOD C} @@ tcf-MapOutputCornerInterpolation
Map Output Data Types == {h V} | <data_types> @@ tcf-MapOutputDataTypes
Map Output Entire Model == {ON} | OFF @@ tcf-MapOutputEntireModel
Map Output Format == {XMDF} | <formats> @@ tcf-MapOutputFormat
Map Output Interval == <time_in_seconds> @@ tcf-MapOutputInterval
Map Output Vector Dry Zpts == ON | {OFF} @@ tcf-MapOutputVectorDryZpts
Mass Balance Corrector == ON | {OFF} @@ tcf-MassBalanceCorrector
Mass Balance Output == {ON} | OFF @@ tcf-MassBalanceOutput
Mass Balance Output Interval == <time_in_seconds> @@ tcf-MassBalanceOutputInterval
Maximum 1D Channels == {100000} | <mchan> @@ tcf-Maximum1DChannels
Maximum Courant Number == <Cr_max> @@ tcf-MaximumCourantNumber
Maximum Points == {500000} | <mp> @@ tcf-MaximumPoints
Maximum Velocity Cutoff Depth == {0.1} | <y> @@ tcf-MaximumVelocityCutoffDepth
Maximum Vertices == {100000} | <mp> @@ tcf-MaximumVertices
Maximums and Minimums == ON | OFF | {ON MAXIMUMS ONLY} @@ tcf-MaximumsandMinimums
Maximums and Minimums Only for Grids == ON | {OFF} @@ tcf-MaximumsandMinimumsOnlyforGrids
Maximums and Minimums Time Series == {ON} | OFF @@ tcf-MaximumsandMinimumsTimeSeries
Maximums Approach == Method A | {Method B} @@ tcf-MaximumsApproach
Maximums Start Track Time == <time_in_hours> @@ tcf-MaximumsStartTrackTime
Maximums Track Time == {OFF} | ON | OFF Completely | Velocity @@ tcf-MaximumsTrackTime
Meshparts == ON | {OFF} @@ tcf-Meshparts
MI Projection == <.mif_file> @@ tcf-MIProjection
MI Projection Check Ignore Bounds == {OFF} | ON @@ tcf-MIProjectionCheckIgnoreBounds
Model Events == <e1> | <e2> | ... @@ tcf-ModelEvents
Model Output Zones == <oz_name_1> | <oz_name_2> | ... @@ tcf-ModelOutputZones
Model Platform == w32 | w64 | linux @@ tcf-ModelPlatform
Model Precision == SINGLE | DOUBLE @@ tcf-ModelPrecision
Model Scenarios == <s1> | <s2> | <s3> | ... @@ tcf-ModelScenarios
Model TUFLOW Build == <build> @@ tcf-ModelTUFLOWBuild
Model TUFLOW Release == <release> @@ tcf-ModelTUFLOWRelease
Negative Depth Approach == Method A | {Method B} @@ tcf-NegativeDepthApproach
NetCDF Output Compression == OFF | {ON} | <level> @@ tcf-NetCDFOutputCompression
NetCDF Output Direction == {ANGLE} | BEARING @@ tcf-NetCDFOutputDirection
NetCDF Output Format == {Generic} | FEWS @@ tcf-NetCDFOutputFormat
NetCDF Output Start Date == {2000-01-01 00:00} | OFF | <date_in_isodate_format> @@ tcf-NetCDFOutputStartDate
NetCDF Output Time Unit == DAY | {HOUR} | MINUTE @@ tcf-NetCDFOutputTimeUnit
Null Cell Checks == ON | {OFF} @@ tcf-NullCellChecks
Number 2D2D Link Iterations == {1} | <no_iterations> @@ tcf-Number2D2DLinkIterations
Number Iterations == {2} | <no_iterations> @@ tcf-NumberIterations
Output Approach == {DEFAULT 2016} | PRE 2016 @@ tcf-OutputApproach
Output Drive == <drive_letter> @@ tcf-OutputDrive
Output Files [ {ALL} | NONE | INCLUDE | EXCLUDE ] == <output_type_list> @@ tcf-OutputFiles
Output Folder == <folder> @@ tcf-OutputFolder
Pit No 1D Connection == {CHECK} | ERROR @@ tcf-PitNo1DConnection
Pit Surcharge ccA Cutoff Depth == {0} | <depth> @@ tcf-PitSurchargeccACutoffDepth
Plot Output Invalid Type == ERROR | {WARNING} @@ tcf-PlotOutputInvalidType
PO Approach == METHOD A | {METHOD B} @@ tcf-POApproach
Process All Grids == {OFF} | ON @@ tcf-ProcessAllGrids
Quadtree BC Parallel Inertia Approach == Method A | {Method B} @@ tcf-QuadtreeBCParallelInertiaApproach
Quadtree Control File == <.qcf_file> | Single Level @@ tcf-QuadtreeControlFile
Rainfall Boundaries == {STEPPED} | SMOOTHED | SMOOTHED TIME CENTRED @@ tcf-RainfallBoundaries
Rainfall Boundary Factor == {1.0} | <value> @@ tcf-RainfallBoundaryFactor
Rainfall Control File == <.trfc_file> @@ tcf-RainfallControlFile
Rainfall Gauges == One per Cell | {Unlimited per Cell} @@ tcf-RainfallGauges
Rainfall Null Value == {-99} | <null_value> @@ tcf-RainfallNullValue
RAM Optimisation == {ON} | OFF @@ tcf-RAMOptimisation
Read GIS 12D Network == <gis_layer> @@ tcf-ReadGIS12DNetwork
Read GIS 12D Nodes == <gis_layer> @@ tcf-ReadGIS12DNodes
Read GIS 12D WLL == <gis_layer> @@ tcf-ReadGIS12DWLL
Read GIS 12D WLL Points == <gis_layer> @@ tcf-ReadGIS12DWLLPoints
Read GIS <option> == <gis_layer> @@ tcf-ReadGIS
Read GIS Auto Terminate == <gis_layer> @@ tcf-ReadGISAutoTerminate
Read GIS Cyclone [ {} | NO PRESSURE ] [ {} | NO WIND ] == <gis_layer> @@ tcf-ReadGISCyclone
Read GIS FC == <gis_layer> @@ tcf-ReadGISFC
Read GIS GLO == <gis_layer> @@ tcf-ReadGISGLO
Read GIS Hurricane [ {} | NO PRESSURE ] [ {} | NO WIND ] == <gis_layer> @@ tcf-ReadGISHurricane
Read GIS ISIS Network == <gis_layer> @@ tcf-ReadGISISISNetwork
Read GIS ISIS Nodes == <gis_layer> @@ tcf-ReadGISISISNodes
Read GIS ISIS WLL == <gis_layer> @@ tcf-ReadGISISISWLL
Read GIS ISIS WLL Points == <gis_layer> @@ tcf-ReadGISISISWLLPoints
Read GIS IWL == <gis_layer> @@ tcf-ReadGISIWL
Read GIS LP == <gis_layer> @@ tcf-ReadGISLP
Read GIS Output Zone == <gis_layer> @@ tcf-ReadGISOutputZone
Read GIS PO == <gis_layer> @@ tcf-ReadGISPO
Read GIS Reporting Location == <gis_layer> @@ tcf-ReadGISReportingLocation
Read GIS X1D Network == <gis_layer> @@ tcf-ReadGISX1DNetwork
Read GIS X1D Nodes == <gis_layer> @@ tcf-ReadGISX1DNodes
Read GIS X1D WLL == <gis_layer> @@ tcf-ReadGISX1DWLL
Read GIS X1D WLL Points == <gis_layer> @@ tcf-ReadGISX1DWLLPoints
Read GIS XP Network == <gis_layer> @@ tcf-ReadGISXPNetwork
Read GIS XP Nodes == <gis_layer> @@ tcf-ReadGISXPNodes
Read GIS XP WLL == <gis_layer> @@ tcf-ReadGISXPWLL
Read GIS XP WLL Points == <gis_layer> @@ tcf-ReadGISXPWLLPoints
Read Grid RF == <.csv_file> | <.nc_file> @@ tcf-ReadGridRF
Read Hazard File == <.csv_file> @@ tcf-ReadHazardFile
Read Materials File == <materials_file> @@ tcf-ReadMaterialsFile
Read Restart File == <.trf_file> @@ tcf-ReadRestartFile
Read RowCol IWL == <.mid_file> @@ tcf-ReadRowColIWL
Read Soils File == <.tsoilf_file> @@ tcf-ReadSoilsFile
Recalculate Chezy Interval == {0} | <timesteps> @@ tcf-RecalculateChezyInterval
Record Gauge Data == RLP | RLL | Gauge @@ tcf-RecordGaugeData
Record Gauge Data EXCLUDE == RLP | RLL | Gauge @@ tcf-RecordGaugeDataEXCLUDE
Restart File Ignore Fields == <field> @@ tcf-RestartFileIgnoreFields
Reveal 1D Nodes == ON | {OFF} @@ tcf-Reveal1DNodes
SA Minimum Depth == {-99999} | <depth_in_m> @@ tcf-SAMinimumDepth
SA Proportion to Depth == {ON} | OFF @@ tcf-SAProportiontoDepth
Screen/Log Display Interval == <timesteps> @@ tcf-ScreenLogDisplayInterval
Set Auto Terminate == {0} | 1 @@ tcf-SetAutoTerminate
Set IWL == {0.0} | AUTO | <value> @@ tcf-SetIWL
Set Route Cut Off Type == {Depth} | Velocity | Hazard | Energy @@ tcf-SetRouteCutOffType
Set Route Cut Off Values == <y1, y2, ...> @@ tcf-SetRouteCutOffValues
Set Variable <name> == <value> @@ tcf-SetVariable
SGS == ON | {OFF} @@ tcf-SGS
SGS 2nd Order BC Slope == {Method A} | Method B @@ tcf-SGS2ndOrderBCSlope
SGS Approach == Method B | {Method C} @@ tcf-SGSApproach
SGS Breakline Detection Delta == <maximum_delta_value> @@ tcf-SGSBreaklineDetectionDelta
SGS Depth Output == EXACT | {CELL AVERAGE} | MEAN | MEDIAN | MINIMUM | PERCENTILE @@ tcf-SGSDepthOutput
SGS Infiltration Approach == {AUTO} | TOTAL AREA | WETTED AREA @@ tcf-SGSInfiltrationApproach
SGS Map Extent [ Full | {Trim} ] == {ALL} | <map_data_types> @@ tcf-SGSMapExtent
SGS Materials == {OFF} | ON @@ tcf-SGSMaterials
SGS Max Sample Frequency == <maximum_frequency> @@ tcf-SGSMaxSampleFrequency
SGS Negative Rainfall Approach == TOTAL AREA | {WETTED AREA} @@ tcf-SGSNegativeRainfallApproach
SGS Sample Frequency == <frequency> @@ tcf-SGSSampleFrequency
SGS Sample Target Distance == <distance> @@ tcf-SGSSampleTargetDistance
SGS Sheet Flow Approach == {Method A} | Method B @@ tcf-SGSSheetFlowApproach
SGS SX Z Flag Approach == Method A | {Method B} @@ tcf-SGSSXZFlagApproach
SGS TIN Memory Allocation Factor == {1.02} | <value> @@ tcf-SGSTINMemoryAllocationFactor
SGS Velocity Based Outputs == {CELL AVERAGE DEPTH} | SGS DEPTH OUTPUT @@ tcf-SGSVelocityBasedOutputs
SGS Water Level Output == {METHOD A} | METHOD B @@ tcf-SGSWaterLevelOutput
SGS Z Shape Line Approach == Method A | {Method B} @@ tcf-SGSZShapeLineApproach
SGS Zpt MAX/MIN Approach == IGNORE | {MINIMUM} | MEDIAN | CENTRE @@ tcf-SGSZptMAXMINApproach
Shallow Depth Stability Factor == <SF> @@ tcf-ShallowDepthStabilityFactor
SHP Projection == <.prj_file> @@ tcf-SHPProjection
SHP Projection Check Method == SIMPLE | {PARSED} @@ tcf-SHPProjectionCheckMethod
Simulation Pause Interval == <time_interval_in_hours> @@ tcf-SimulationPauseInterval
Simulation Pause Start == <model_time_in_hours> @@ tcf-SimulationPauseStart
Simulations Log Folder == Do Not Use | <folder> @@ tcf-SimulationsLogFolder
Snap Tolerance == {0.001} | <snap_distance> @@ tcf-SnapTolerance
Soil Initial Loss == {Ignore Material Impervious} | Use Material Impervious @@ tcf-SoilInitialLoss
Soil Negative Rainfall Approach == {None} | Factor @@ tcf-SoilNegativeRainfallApproach
Soil Negative Rainfall Factor == {1} | <factor> @@ tcf-SoilNegativeRainfallFactor
Solution Scheme == {CLASSIC} | HPC | HPC 1st @@ tcf-SolutionScheme
Spatial Database == <GPKG_database> @@ tcf-SpatialDatabase
Spatial Database Output == SEPARATE | {GROUPED} @@ tcf-SpatialDatabaseOutput
SQLite On Open SQL [ {} | Read | Write ] == <SQL_Pragma_Command> @@ tcf-SQLiteOnOpenSQL
Start 1D Domain @@ tcf-Start1DDomain
Start 2D Domain == <2d_domain_name> @@ tcf-Start2DDomain
Start Map Output == <time_in_hours> @@ tcf-StartMapOutput
Start Time == <time_in_hours> @@ tcf-StartTime
Start Time Series Output == <time_in_hours> @@ tcf-StartTimeSeriesOutput
Supercritical == {ON} | OFF | PRE 2002-11-AD @@ tcf-Supercritical
SWMM Control File == <.tscf_file> @@ tcf-SWMMControlFile
SX Flow Distribution Cutoff Depth == {AUTO} | <depth_m> @@ tcf-SXFlowDistributionCutoffDepth
SX FMP Unit Type Error == {ON} | Off @@ tcf-SXFMPUnitTypeError
SX Head Adjustment == ON | {OFF} @@ tcf-SXHeadAdjustment
SX Head Distribution Cutoff Depth == {AUTO} | <depth_m> @@ tcf-SXHeadDistributionCutoffDepth
SX Storage Approach == {1D NODE AVERAGE} | Cell Only @@ tcf-SXStorageApproach
SX Storage Factor == {1.0, 20.0} | <sxs_factor>, <sxs_limits> @@ tcf-SXStorageFactor
SX ZC Check == {ON} | OFF | <dZ_limit_in_m> @@ tcf-SXZCCheck
TIF Compression == NONE | LZW | {DEFLATE} @@ tcf-TIFCompression
TIF Compression Predictor == NONE | {Horizontal Differencing} @@ tcf-TIFCompressionPredictor
TIF Projection == <geotiff_file> @@ tcf-TIFProjection
Time Output Corner Interpolation == {VALUE} | WET | START | <Offset> @@ tcf-TimeOutputCornerInterpolation
Time Output Cutoff [ Depths | VxD | <Hazard> ] == {OFF} | <v1, v2, ...> @@ tcf-TimeOutputCutoff
Time Series Null Value == {cell_elevation} | <null_value> @@ tcf-TimeSeriesNullValue
Time Series Output Format == {csv} | NC | GPKG @@ tcf-TimeSeriesOutputFormat
Time Series Output Interval == <time_in_seconds> @@ tcf-TimeSeriesOutputInterval
Timestep == {1.0} | <timestep_in_seconds> @@ tcf-Timestep
Timestep Initial == <initial_timestep_in_seconds> @@ tcf-TimestepInitial
Timestep Maximum == {Auto} | <max_timestep_in_seconds> @@ tcf-TimestepMaximum
Timestep Maximum Increase (%) == {0.5} | <value_as_a_%> @@ tcf-TimestepMaximumIncrease
Timestep Minimum == {AUTO} | <min_timestep_in_seconds> @@ tcf-TimestepMinimum
Timestep Repeats == {10} | <n_allowed_repeats> @@ tcf-TimestepRepeats
TIN Output Format == {2DM} | SMS TIN @@ tcf-TINOutputFormat
TIN Triangulation Approach == Method A | {Method B} @@ tcf-TINTriangulationApproach
TSF Update Interval == {0} | <interval_in_seconds> @@ tcf-TSFUpdateInterval
Tutorial Model == ON | {OFF} @@ tcf-TutorialModel
UK Hazard Debris Factor == {1} | <DF> @@ tcf-UKHazardDebrisFactor
UK Hazard Formula == D*(V+1.5) | {D*(V+0.5)+DF} @@ tcf-UKHazardFormula
UK Hazard Land Use == PASTURE | WOODLAND | URBAN | {CONSERVATIVE} | NOT SET @@ tcf-UKHazardLandUse
Units == {METRIC} | ENGLISH | IMPERIAL | US Customary @@ tcf-Units
Unused HX and SX Connections == {ERROR} | WARNING @@ tcf-UnusedHXandSXConnections
Use Forward Slash == ON | {OFF} @@ tcf-UseForwardSlash
Use GDAL == ON | {OFF} @@ tcf-UseGDAL
Verbose == ON | OFF | {LOW} | HIGH @@ tcf-Verbose
VG Z Adjustment == {MAX ZC} | ZC | ZH @@ tcf-VGZAdjustment
Viscosity Approach == Method A | {Method B} @@ tcf-ViscosityApproach
Viscosity Coefficient == <value1, value2, ...> @@ tcf-ViscosityCoefficient
Viscosity Formulation == CONSTANT | SMAGORINSKY | WU | NONNEWTONIAN @@ tcf-ViscosityFormulation
Water Level Checks == {ON} | OFF @@ tcf-WaterLevelChecks
Wetting and Drying == {ON METHOD B} | ON | ON NO SIDE CHECKS | OFF @@ tcf-WettingandDrying
WIBU FIRM Code Search Order == <list_of_firm_codes> @@ tcf-WIBUFIRMCodeSearchOrder
Wind/Wave Shallow Depths == {0.2, 1.0} | <y1, y2> @@ tcf-WindWaveShallowDepths
Write Check Files [ {} | ALL | NONE | INCLUDE | EXCLUDE ] == <folder_or_prefix_list> @@ tcf-WriteCheckFiles
Write Empty GIS Files == <folder> @@ tcf-WriteEmptyGISFiles
Write PO Online == ON | {OFF} @@ tcf-WritePOOnline
Write Restart File at Time == <time_in_hours> @@ tcf-WriteRestartFileatTime
Write Restart File Interval == {0} | <interval_in_hours> @@ tcf-WriteRestartFileInterval
Write Restart File Version == 2 @@ tcf-WriteRestartFileVersion
Write Restart Filename == {INCLUDE TIME} | OVERWRITE @@ tcf-WriteRestartFilename
Write X1D Check Files == ON | {OFF} @@ tcf-WriteX1DCheckFiles
XF Files == {ON} | OFF @@ tcf-XFFiles
XF Files Boundaries == {ON} | OFF @@ tcf-XFFilesBoundaries
XF Files Include in Filename == <text> @@ tcf-XFFilesIncludeinFilename
XF Files Merge TIN Elevations == {Reprocess} | Use XF @@ tcf-XFFilesMergeTINElevations
XMDF Output Compression == {ON} | OFF | <level> @@ tcf-XMDFOutputCompression
Zero Negative Depths == {ON} | OFF @@ tcf-ZeroNegativeDepths
Zero Rainfall Check == {ERROR} | WARNING @@ tcf-ZeroRainfallCheck
ZP Hazard Cutoff Depth == {0.01} | <depth> @@ tcf-ZPHazardCutoffDepth
Zpt Range Check == {-9998, 99998} | <zmin>, <zmax> @@ tcf-ZptRangeCheck
"""

TGC = """
12DA Read Approach == Method A | {Method B} @@ tgc-12DAReadApproach
Allow Dangling Z Lines == ON | {OFF} @@ tgc-AllowDanglingZLines
Cell Size == <value> @@ tgc-CellSize
Create TIN Zpts [ {} | WRITE TIN ] [ {} | XF ON | XF OFF ] == <gis_layer> @@ tgc-CreateTINZpts
Default Land Z == <elevation> @@ tgc-DefaultLandZ
Grid Approach == Method A | {Method B} @@ tgc-GridApproach
Grid Size (N,M) == <rows>, <columns> @@ tgc-GridSizeNM
Grid Size (X,Y) == <X_length>, <Y_length> @@ tgc-GridSizeXY
Interpolate ZC [ {} | ALL ] [ {} | LOWER ] @@ tgc-InterpolateZC
Interpolate ZHC [ {} | ALL ] @@ tgc-InterpolateZHC
Interpolate ZUV [ {} | ALL ] [ {} | MAX ] @@ tgc-InterpolateZUV
Interpolate ZUVC [ {} | ALL ] @@ tgc-InterpolateZUVC
Interpolate ZUVH [ {} | ALL ] [ {} | MAX ] @@ tgc-InterpolateZUVH
Orientation == <XX>, <YX> @@ tgc-Orientation
Orientation Angle == <angle> @@ tgc-OrientationAngle
Origin == <OX>, <OY> @@ tgc-Origin
Pause When Polyline Does Not Find Zpt == ON | {OFF} @@ tgc-PauseWhenPolylineDoesNotFindZpt
Read GIS BG Shape == <gis_layer> @@ tgc-ReadGISBGShape
Read GIS CnM == <gis_layer> @@ tgc-ReadGISCnM
Read GIS Code [ {} | BC | Invert | BC Invert ] == <gis_layer> @@ tgc-ReadGISCode
Read GIS CWF == <gis_layer> @@ tgc-ReadGISCWF
Read GIS FC Shape [ {} | Write TIN ] == <gis_layer> @@ tgc-ReadGISFCShape
Read GIS FLC == <gis_layer> @@ tgc-ReadGISFLC
Read GIS FLC/L == <gis_layer> @@ tgc-ReadGISFLCL
Read GIS FRIC == <gis_layer> @@ tgc-ReadGISFRIC
Read GIS GWD == <gis_layer> @@ tgc-ReadGISGWD
Read GIS GWL == <gis_layer> @@ tgc-ReadGISGWL
Read GIS IGW Conc Layer <layers> Tracer <tracers> == <gis_layer> @@ tgc-ReadGISIGWConc
Read GIS IGW Depth == <gis_layer> @@ tgc-ReadGISIGWDepth
Read GIS IGW Level == <gis_layer> @@ tgc-ReadGISIGWLevel
Read GIS IWL == <gis_layer> @@ tgc-ReadGISIWL
Read GIS Layered FC Shape [ {} | Write TIN ] == <gis_layer> @@ tgc-ReadGISLayeredFCShape
Read GIS Location == <gis_layer> @@ tgc-ReadGISLocation
Read GIS Mat == <gis_layer> @@ tgc-ReadGISMat
Read GIS Objects [ {} | RECORD GAUGE DATA ] == <gis_layer> @@ tgc-ReadGISObjects
Read GIS Receptors [ {} | RECORD GAUGE DATA ] == <gis_layer> @@ tgc-ReadGISReceptors
Read GIS Soil == <gis_layer> @@ tgc-ReadGISSoil
Read GIS Soil Base Elevation == <gis_layer> @@ tgc-ReadGISSoilBaseElevation
Read GIS Soil Thickness == <gis_layer> @@ tgc-ReadGISSoilThickness
Read GIS SRF == <gis_layer> @@ tgc-ReadGISSRF
Read GIS Variable Z Shape [ {} | XF ON | XF OFF | Write TIN ] == <gis_layer> @@ tgc-ReadGISVariableZShape
Read GIS WrF == <gis_layer> @@ tgc-ReadGISWrF
Read GIS Z HX Line [ {} | RIDGE | MAX | RAISE ] == <gis_layer> @@ tgc-ReadGISZHXLine
Read GIS Z Line == <gis_layer> @@ tgc-ReadGISZLine
Read GIS Z Shape [ {} | RIDGE | MAX | RAISE | GULLY | MIN | LOWER ] [ {} | XF ON | XF OFF | Write TIN ] == <gis_layer> @@ tgc-ReadGISZShape
Read GIS Z Shape Route [ {} | RIDGE | MAX | RAISE | GULLY | MIN | LOWER | Write TIN ] == <gis_layer> @@ tgc-ReadGISZShapeRoute
Read GIS Zpts [ {} | ADD | MAX | MIN ] == <gis_layer> @@ tgc-ReadGISZpts
Read GIS Zpts Modify Conveyance == <gis_layer> | <k_factor> | <water_level_grid> @@ tgc-ReadGISZptsModifyConveyance
Read Grid CnM == <grid_file> @@ tgc-ReadGridCnM
Read Grid Code == <grid_file> @@ tgc-ReadGridCode
Read Grid CWF == <grid_file> @@ tgc-ReadGridCWF
Read Grid FLC == <grid_file> @@ tgc-ReadGridFLC
Read Grid FLC/L == <grid_file> @@ tgc-ReadGridFLCL
Read Grid FRIC == <grid_file> @@ tgc-ReadGridFRIC
Read Grid GWD == <grid_file> @@ tgc-ReadGridGWD
Read Grid GWL == <grid_file> @@ tgc-ReadGridGWL
Read Grid IGW Conc Layer <layers> Tracer <tracers> == <grid_file> @@ tgc-ReadGridIGWConc
Read Grid IGW Depth == <grid_file> @@ tgc-ReadGridIGWDepth
Read Grid IGW Level == <grid_file> @@ tgc-ReadGridIGWLevel
Read Grid IWL == <grid_file> @@ tgc-ReadGridIWL
Read Grid Location == <grid_file> @@ tgc-ReadGridLocation
Read Grid Mat == <grid_file> @@ tgc-ReadGridMat
Read Grid Soil == <grid_file> @@ tgc-ReadGridSoil
Read Grid Soil Base Elevation == <grid_file> @@ tgc-ReadGridSoilBaseElevation
Read Grid Soil Thickness == <grid_file> @@ tgc-ReadGridSoilThickness
Read Grid SRF == <grid_file> @@ tgc-ReadGridSRF
Read Grid WrF == <grid_file> @@ tgc-ReadGridWrF
Read Grid Zpts [ {} | ADD | MAX | MIN ] [ {} | XF ON | XF OFF ] == <grid_file> @@ tgc-ReadGridZpts
Read RowCol <option> == <mid_file> @@ tgc-ReadRowCol
Read RowCol WrF == <mid_file> @@ tgc-ReadRowColWrF
Read RowCol Zpts [ {} | ADD | MAX | MIN ] [ {} | XF ON | XF OFF ] == <zpt_file> @@ tgc-ReadRowColZpts
Read TIN Zpts [ {} | ADD | MAX | MIN ] [ {} | XF ON | XF OFF ] == <tin_file> @@ tgc-ReadTINZpts
Set CnM == <value> @@ tgc-SetCnM
Set Code [ {} | ZERO ABOVE ZC ] == <value> @@ tgc-SetCode
Set Code and Clean Zpt == <Z_inactive> @@ tgc-SetCodeandCleanZpt
Set CWF == <value> @@ tgc-SetCWF
Set FLC == <value> @@ tgc-SetFLC
Set FLC/L == <value> @@ tgc-SetFLCL
Set FRIC == <value> @@ tgc-SetFRIC
Set GWD == <value> @@ tgc-SetGWD
Set GWL == <value> @@ tgc-SetGWL
Set IGW Conc Layer <layers> Tracer <tracers> == <value> @@ tgc-SetIGWConc
Set IGW Depth == <value> @@ tgc-SetIGWDepth
Set IGW Level == <value> @@ tgc-SetIGWLevel
Set IWL == <value> @@ tgc-SetIWL
Set Mat == <value> @@ tgc-SetMat
Set Route Cut Off Type == {Depth} | Velocity | Hazard | Energy @@ tgc-SetRouteCutOffType
Set Route Cut Off Values == <y1, y2, ...> @@ tgc-SetRouteCutOffValues
Set Soil == <value> @@ tgc-SetSoil
Set Soil Base Elevation == <value> @@ tgc-SetSoilBaseElevation
Set Soil Thickness == <value> @@ tgc-SetSoilThickness
Set SRF == <value> @@ tgc-SetSRF
Set WrF == <WrF_value> @@ tgc-SetWrF
Set Zpt == <elevation> @@ tgc-SetZpt
SGS [ {} | Grid | TIN ] Sample Distance == <distance> @@ tgc-SGSSampleDistance
SGS Grid Max Null Frac == {0.5} | <maximum_null_fraction> @@ tgc-SGSGridMaxNullFrac
SGS Partial Grid Update Null Frac == {0.1, 0.9} | <lower>, <upper> @@ tgc-SGSPartialGridUpdateNullFrac
SGS ZH Sample Ratio == {1} | <ratio> @@ tgc-SGSZHSampleRatio
Spatial Database == OFF | TCF | <GPKG_database> @@ tgc-SpatialDatabase
Stop @@ tgc-Stop
Thin Line as Thick == ON | {OFF} @@ tgc-ThinLineasThick
TIN Angles == {55, 30} | <point_angle>, <edge_angle> @@ tgc-TINAngles
TIN Coincident Point Distance == {0.001} | <dist_in_m> @@ tgc-TINCoincidentPointDistance
Write GIS Domain == <gis_layer_out> @@ tgc-WriteGISDomain
Write GIS Grid == <gis_layer_out> @@ tgc-WriteGISGrid
Write GIS Zpts == <gis_layer_out> @@ tgc-WriteGISZpts
ZC == MIN(ZU,ZV) @@ tgc-ZC
Zero Z Point == {ERROR} | WARNING @@ tgc-ZeroZPoint
"""

TBC = """
BC Database == <.csv_file> @@ tbc-BCDatabase
BC Event Name == <bc_event_name> @@ tbc-BCEventName
BC Event Source == <bc_event_text> | <bc_event_name> @@ tbc-BCEventSource
BC Event Text == <bc_event_text> @@ tbc-BCEventText
Blank BC Type == {NONE} | <bc_type> @@ tbc-BlankBCType
Blank HQ Slope == <slope> @@ tbc-BlankHQSlope
Global Rainfall Area Factor == {1.0} | <area_factor> @@ tbc-GlobalRainfallAreaFactor
Global Rainfall BC == <bc_name> @@ tbc-GlobalRainfallBC
Global Rainfall Continuing Loss == {0} | <CL> @@ tbc-GlobalRainfallContinuingLoss
Global Rainfall Initial Loss == {0} | <IL> @@ tbc-GlobalRainfallInitialLoss
Read GIS BC == <gis_layer> @@ tbc-ReadGISBC
Read GIS RF == <gis_layer> @@ tbc-ReadGISRF
Read GIS SA [ {} | <option> ] == <gis_layer> @@ tbc-ReadGISSA
Read GIS Streams == <gis_layer> @@ tbc-ReadGISStreams
Read RowCol RF == <.mid_file> @@ tbc-ReadRowColRF
Spatial Database == OFF | TCF | <GPKG_database> @@ tbc-SpatialDatabase
Unused HX and SX Connections == {ERROR} | WARNING @@ tbc-UnusedHXandSXConnections
"""

ECF = """
1D Node Invert Approach == {Method A} | Method B @@ ecf-1DNodeInvertApproach
AD Approach == METHOD A | {METHOD B} @@ ecf-ADApproach
Apply All Inverts == {ON} | OFF @@ ecf-ApplyAllInverts
Arch Bridge Minimum Blockage (%) == {5} | <min_pblockage> @@ ecf-ArchBridgeMinimumBlockage
BC Database == <.csv_file> @@ ecf-BCDatabase
BC Event Name == <bc_event_name> @@ ecf-BCEventName
BC Event Source == <bc_event_text> | <bc_event_name> @@ ecf-BCEventSource
BC Event Text == <bc_event_text> @@ ecf-BCEventText
Bridge Flow == Method A | {Method B} @@ ecf-BridgeFlow
Bridge Zero Coefficients == {DEFAULT} | OFF | <Cd>, <DLC>, <ELC>, <XLC> @@ ecf-BridgeZeroCoefficients
Conveyance Calculation == CHANGE IN RESISTANCE | {ALL PARALLEL} @@ ecf-ConveyanceCalculation
Create Nodes == {ON} | OFF @@ ecf-CreateNodes
CSV Format == HORIZONTAL | {VERTICAL} @@ ecf-CSVFormat
CSV Maximum Number Columns == <max_col> @@ ecf-CSVMaximumNumberColumns
CSV Time == {DAYS} | HOURS | MINUTES | SECONDS @@ ecf-CSVTime
Culvert Critical H/D == {OFF} | <critical_h/d> @@ ecf-CulvertCriticalHD
Culvert Flow == {Method E} | <Method_letter> @@ ecf-CulvertFlow
Culvert Zero Coefficients == DEFAULT | {OFF} | <v1, v2, v3, v4, v5> @@ ecf-CulvertZeroCoefficients
Depth Discharge Database == <.csv_file> @@ ecf-DepthDischargeDatabase
Depth Limit Factor == {10} | <value> @@ ecf-DepthLimitFactor
Flow Area == {EFFECTIVE} | TOTAL @@ ecf-FlowArea
Flow Calculation == Method A | {Method B} @@ ecf-FlowCalculation
Froude Check == {1} | <froude_no> @@ ecf-FroudeCheck
Froude Depth Adjustment == {ON} | OFF @@ ecf-FroudeDepthAdjustment
Head Rate Creep Factor == {1.2} | <value> @@ ecf-HeadRateCreepFactor
Head Rate Limit == ON | {OFF} | <hrl> @@ ecf-HeadRateLimit
Head Rate Limit Minimum == {0.001} | <hrlmin> @@ ecf-HeadRateLimitMinimum
Interpolate Cross-Sections == {ON} | OFF @@ ecf-InterpolateCrossSections
Interpolate Culvert Inverts == {ON} | OFF @@ ecf-InterpolateCulvertInverts
M Channel Approach == Method A | {Method B} @@ ecf-MChannelApproach
M11 Network == <.nwk11_file> @@ ecf-M11Network
Manhole Approach == METHOD A | METHOD B | {METHOD C} @@ ecf-ManholeApproach
Manhole Default C Exit Coefficient == {0.25} | <K_CE> @@ ecf-ManholeDefaultCExitCoefficient
Manhole Default Loss Approach == NONE | {ENGELUND} | FIXED @@ ecf-ManholeDefaultLossApproach
Manhole Default R Exit Coefficient == {0.5} | <K_RE> @@ ecf-ManholeDefaultRExitCoefficient
Manhole Default Side Clearance == {0.3} | <value_m> @@ ecf-ManholeDefaultSideClearance
Manhole Default Type == C | J | R | CR | {CJR} @@ ecf-ManholeDefaultType
Manhole K Maximum Bend/Drop == {4.0} | <max_K_bd> @@ ecf-ManholeKMaximumBendDrop
Manhole Minimum Dimension == {1.05} | <min_width_m> @@ ecf-ManholeMinimumDimension
Manholes at All Culvert Junctions == {ON} | OFF @@ ecf-ManholesatAllCulvertJunctions
Maximum Operational Controls == {1000} | <number> @@ ecf-MaximumOperationalControls
Minimum Channel Conveyance Length == {0} | <length_m> @@ ecf-MinimumChannelConveyanceLength
Minimum Channel Storage Length == {0} | <length_m> @@ ecf-MinimumChannelStorageLength
Minimum NA == {1} | <value> @@ ecf-MinimumNA
Minimum NA Pit == {1} | <value> @@ ecf-MinimumNAPit
Momentum Equation == PRE 2003-08-AD @@ ecf-MomentumEquation
Order Output == {ON} | OFF @@ ecf-OrderOutput
Output Data Types == {H Q S V} | <data_types> @@ ecf-OutputDataTypes
Output Folder == <folder> @@ ecf-OutputFolder
Output Interval == <time_in_seconds> @@ ecf-OutputInterval
Output Times Same as 2D == {ON} | OFF @@ ecf-OutputTimesSameas2D
Overlapping SX HX Boundary == CHECK | {ERROR} @@ ecf-OverlappingSXHXBoundary
Pit Channel Offset == <length_m> @@ ecf-PitChannelOffset
Pit Default 2D Connection == <Conn_1D_2D> @@ ecf-PitDefault2DConnection
Pit Default Extrapolate Q Curve == {ON} | OFF @@ ecf-PitDefaultExtrapolateQCurve
Pit Default Road Crossfall == <slope> @@ ecf-PitDefaultRoadCrossfall
Pit Inlet Database == <.csv_file> @@ ecf-PitInletDatabase
Pit Search Distance == {0.0} | <psd_m> @@ ecf-PitSearchDistance
Read GIS BC == <gis_layer> @@ ecf-ReadGISBC
Read GIS IWL == <gis_layer> @@ ecf-ReadGISIWL
Read GIS Manhole == <gis_layer> @@ ecf-ReadGISManhole
Read GIS Network == <gis_layer> @@ ecf-ReadGISNetwork
Read GIS Node == <gis_layer> @@ ecf-ReadGISNode
Read GIS Pits == <gis_layer> @@ ecf-ReadGISPits
Read GIS Table Links == <gis_layer> @@ ecf-ReadGISTableLinks
Read GIS WLL == <gis_layer> @@ ecf-ReadGISWLL
Read GIS WLL Points == <gis_layer> @@ ecf-ReadGISWLLPoints
Read Operating Controls File == <.toc_file> @@ ecf-ReadOperatingControlsFile
S Channel Approach == PRE 2004-06-AA | METHOD A | {METHOD B} @@ ecf-SChannelApproach
Set IWL == <IWL> @@ ecf-SetIWL
Spatial Database == OFF | TCF | <GPKG_database> @@ ecf-SpatialDatabase
Start Output == <time_in_hours> @@ ecf-StartOutput
Storage Above Structure Obvert == {5} | CHANNEL WIDTH | <value> @@ ecf-StorageAboveStructureObvert
Structure Flow Levels == {ENERGY} | WATER | ENERGY UPSTREAM @@ ecf-StructureFlowLevels
Structure Losses == {ADJUST EXCEPT BG TABLE} | ADJUST | FIX @@ ecf-StructureLosses
Structure Losses Approach == METHOD A | {METHOD B} @@ ecf-StructureLossesApproach
Structure Losses SX == ADJUST | ADJUST SKEW | {FIX} @@ ecf-StructureLossesSX
Structure Routines == ORIGINAL | {2013} @@ ecf-StructureRoutines
Taper Closed NA Table == {ON} | OFF @@ ecf-TaperClosedNATable
Timestep == <timestep_in_seconds> @@ ecf-Timestep
Trim XZ Profiles == ON | {OFF} @@ ecf-TrimXZProfiles
Vel Rate Creep Factor == {1.2} | <value> @@ ecf-VelRateCreepFactor
Vel Rate Limit == {0.2} | <vrl> @@ ecf-VelRateLimit
Vel Rate Limit Minimum == {0.0001} | <vrlmin> @@ ecf-VelRateLimitMinimum
Weir Approach == {Method A} | Method B @@ ecf-WeirApproach
Weir Flow == Method A | Method B | {Method C} @@ ecf-WeirFlow
WLL Approach == Method A | {Method B} @@ ecf-WLLApproach
WLL Automatic == CULVERTS | {OFF} @@ ecf-WLLAutomatic
WLL No Weirs == ON | {OFF} @@ ecf-WLLNoWeirs
WLL Vertical Offset == {10} | <dZ> @@ ecf-WLLVerticalOffset
WLLp Interpolate Bed == {ON} | OFF @@ ecf-WLLpInterpolateBed
Write Check Files [ {} | Exclude | Include | None | ALL ] == <folder_or_prefix_list> @@ ecf-WriteCheckFiles
XS Database == <.csv_file> @@ ecf-XSDatabase
"""

TEF = """
Define Event == <event_name> @@ tef-DefineEvent
End Define @@ tef-EndDefine
"""

QCF = """
Base Cell Size == {TGC} | <cell_size> @@ qcf-BaseCellSize
Model Origin and Extent == {Auto} | TGC @@ qcf-ModelOriginandExtent
Orientation Angle == {TGC} | Optimise | <angle> @@ qcf-OrientationAngle
Quadtree Mesh Processing Method == {FAST} | Memory Efficient @@ qcf-QuadtreeMeshProcessingMethod
Read GIS Nesting == <gis_layer> @@ qcf-ReadGISNesting
Spatial Database == OFF | TCF | <GPKG_database> @@ qcf-SpatialDatabase
"""

TRFC = """
IDW Exponent == {2} | <p> @@ trfc-IDWExponent
IDW Maximum Distance == <max_dist> @@ trfc-IDWMaximumDistance
IDW Maximum Points == <max_points> @@ trfc-IDWMaximumPoints
Maximum Hyetograph Points == {1000} | <max_pts> @@ trfc-MaximumHyetographPoints
Maximum RF Locations == {1000} | <max_rf_gauges> @@ trfc-MaximumRFLocations
Read GIS RF Point == <gis_layer> @@ trfc-ReadGISRFPoint
Read GIS RF Polygons == <gis_layer> @@ trfc-ReadGISRFPolygons
Read GIS RF Triangles == <gis_layer> @@ trfc-ReadGISRFTriangles
RF Grid Cell Size == <value> @@ trfc-RFGridCellSize
RF Grid Format == ASC | FLT | NC | TIF @@ trfc-RFGridFormat
RF Grid Origin == <OX>, <OY> @@ trfc-RFGridOrigin
RF Grid Size (N,M) == <rows>, <columns> @@ trfc-RFGridSizeNM
RF Grid Size (X,Y) == <X_length>, <Y_length> @@ trfc-RFGridSizeXY
RF Interpolation Method == IDW | POLYGON | TIN @@ trfc-RFInterpolationMethod
"""

TOC = """
Define [ {} | Gate | Pump | Weir | Orifice | Breach | Spillway | Bridge ] Control == <control_id> @@ toc-DefineControl
End Define @@ toc-EndDefine
Breach Opening == {CLOSE} | OPEN | NO CHANGE @@ toc-BreachOpening
Cd == <Cd> @@ toc-Cd
Cd Failed == <Cd> @@ toc-CdFailed
Cd Gate == <Cd> @@ toc-CdGate
Cd Gate Submerged == {0.8} | <Cd> @@ toc-CdGateSubmerged
Cd Intact == <Cd> @@ toc-CdIntact
Cd Spillway == {0.75} | <Cd> @@ toc-CdSpillway
Cf == {1.0} | <Cf> @@ toc-Cf
Cf Failed == {1.0} | <Cf> @@ toc-CfFailed
Cf Intact == {1.0} | <Cf> @@ toc-CfIntact
Depth Breached == <initial_breach_depth> @@ toc-DepthBreached
Depth Collapse == <depth_collapse> @@ toc-DepthCollapse
Depth Fully Breached == <depth_fully_breached> @@ toc-DepthFullyBreached
Discharge Curve Type == {Upstream Depth} | Head Difference | Pump @@ toc-DischargeCurveType
Ex Failed == <Ex> @@ toc-ExFailed
Ex Intact == <Ex> @@ toc-ExIntact
Gate Height Fully Open == <height> @@ toc-GateHeightFullyOpen
Gate Opening [ {} | (%) ] == {CLOSE} | OPEN | NO CHANGE | <opening> @@ toc-GateOpening
Gate Seat Vertical Offset == <offset> @@ toc-GateSeatVerticalOffset
Gate Speed [ {} | (min) ] == <speed> @@ toc-GateSpeed
Gate Type == VERTICAL UNDERFLOW | VERTICAL OVERFLOW | HORIZONTAL SINGLE | HORIZONTAL DOUBLE @@ toc-GateType
Gate Width Fully Open == <width> @@ toc-GateWidthFullyOpen
Ka == {0} | <value> @@ toc-Ka
Ka Intact == {0} | <value> @@ toc-KaIntact
Kp == {0} | <value> @@ toc-Kp
Kp Intact == {0} | <value> @@ toc-KpIntact
Method == <method> @@ toc-Method
Number of Piers == {0} | <value> @@ toc-NumberofPiers
Operation == NO CHANGE @@ toc-Operation
Orifice Height Fully Open == <height> @@ toc-OrificeHeightFullyOpen
Orifice Opening == {CLOSE} | OPEN | NO CHANGE @@ toc-OrificeOpening
Orifice Shape == {Rectangular} | Circular @@ toc-OrificeShape
Orifice Width Fully Open == <width> @@ toc-OrificeWidthFullyOpen
Period Collapse [ {} | (min) | (s) ] == {0.0} | <period> @@ toc-PeriodCollapse
Period Failure [ {} | (min) | (s) ] == {0.0167} | <period> @@ toc-PeriodFailure
Period Opening/Closing [ {} | (min) | (s) ] == {0.167} | <period> @@ toc-PeriodOpeningClosing
Period Startup/Shutdown [ {} | (min) | (s) ] == {0.167} | <period> @@ toc-PeriodStartupShutdown
Pump Capacity == <flow> | <discharge_curve> @@ toc-PumpCapacity
Pump Number == <no_pumps> @@ toc-PumpNumber
Pump Operation == ON | OFF | NO CHANGE @@ toc-PumpOperation
Sa Failed == <Sa> @@ toc-SaFailed
Sa Intact == <Sa> @@ toc-SaIntact
Sb Failed == <Sb> @@ toc-SbFailed
Sb Intact == <Sb> @@ toc-SbIntact
Side Slope (degree) == {90} | <slope_in_degree> @@ toc-SideSlopeDegree
Top Width Breached == <width> @@ toc-TopWidthBreached
Top Width Collapse == <top_width> @@ toc-TopWidthCollapse
Top Width Fully Breached == <top_width> @@ toc-TopWidthFullyBreached
Weir Height [ {} | % ] == <weir_height> @@ toc-WeirHeight
Weir Height Speed [ {} | (min) ] == <speed> @@ toc-WeirHeightSpeed
Weir Type Failed == <weir_type> @@ toc-WeirTypeFailed
Weir Type Intact == <weir_type> @@ toc-WeirTypeIntact
Weir Width [ {} | % ] == <weir_width> @@ toc-WeirWidth
Weir Width Speed [ {} | (min) ] == <speed> @@ toc-WeirWidthSpeed
"""

TESF = """
Global Wind BC == <boundary_name> @@ tesf-GlobalWindBC
Grid Interpolation Method == IWD | Poly @@ tesf-GridInterpolationMethod
IDW Exponent == {2.0} | <value> @@ tesf-IDWExponent
IDW Maximum Distance == <value> @@ tesf-IDWMaximumDistance
IDW Maximum Point == {all} | <maximum_points> @@ tesf-IDWMaximumPoint
Output Grid Cell Size == <value> @@ tesf-OutputGridCellSize
Output Grid Format == ASC | FLT | {NC} @@ tesf-OutputGridFormat
Output Grid Origin == <x>, <y> @@ tesf-OutputGridOrigin
Read GIS Wind Point == <gis_layer> @@ tesf-ReadGISWindPoint
Read GIS Wind Poly == <gis_layer> @@ tesf-ReadGISWindPoly
Read Gridded Tau == <.nc_file> @@ tesf-ReadGriddedTau
"""

TSCF = """
Check INP Save Date == {ERROR} | WARNING | OFF @@ tscf-CheckINPSaveDate
Inlet Surcharge Orifice Coefficient == {0.16} | <value> @@ tscf-InletSurchargeOrificeCoefficient
Maximum Inlet Ponded Depth == {999} | <value> @@ tscf-MaximumInletPondedDepth
Output Folder == <folder> @@ tscf-OutputFolder
Read BC <type> == <input_curve_1> | <input_curve_2> @@ tscf-ReadBC
Read GIS SWMM Inlet Usage == <gis_layer> @@ tscf-ReadGISSWMMInletUsage
Read SWMM == <.inp_file> @@ tscf-ReadSWMM
SWMM Iterations == {1} | <value> @@ tscf-SWMMIterations
"""

ADCF = """
AD BC Database == <.csv_file> @@ adcf-ADBCDatabase
AD Global Database == <.csv_file> @@ adcf-ADGlobalDatabase
Write CFL == ON | {OFF} @@ adcf-WriteCFL
Write Iterations == ON | {OFF} @@ adcf-WriteIterations
Write Mass == ON | {OFF} @@ adcf-WriteMass
Write Mass Unit == Kg | {Tonne} | Gram @@ adcf-WriteMassUnit
"""

RAW = {
    "TCF": TCF, "TGC": TGC, "TBC": TBC, "ECF": ECF, "TEF": TEF, "QCF": QCF,
    "TRFC": TRFC, "TOC": TOC, "TESF": TESF, "TSCF": TSCF, "ADCF": ADCF,
}
