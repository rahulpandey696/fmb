# -*- coding: utf-8 -*-
"""
The standard TUFLOW folder structure (as used by the TUFLOW tutorial models)
and a helper that creates it at any location.

    <root>/
        bc_dbase/        boundary condition database + time series
        check/           check files written by TUFLOW
        model/           .tgc .tbc .ecf .tef .qcf, materials / soils files
            gis/         GIS input layers
                empty/   TUFLOW empty template layers
            grid/        DEM and other rasters
        results/         map and time-series results
        runs/            .tcf and batch files
            log/         .tlf logs and messages layers
"""
import os

# (relative path with '/', ticked by default, what goes in it)
FOLDER_TREE = [
    ("bc_dbase", True, "Boundary condition database (bc_dbase.csv) and the time-series CSV files it points to."),
    ("check", True, "Check files TUFLOW writes (Write Check Files) - review them before trusting results."),
    ("model", True, "Control files read by the TCF: .tgc, .tbc, .ecf, .tef, .qcf and the materials / soils files."),
    ("model/gis", True, "GIS input layers (GeoPackage or Shapefiles): 2d_code, 2d_mat, 2d_bc, 2d_po, 1d_nwk ..."),
    ("model/gis/empty", True, "TUFLOW empty template layers (Write Empty GIS Files or the Empty layers tab)."),
    ("model/grid", True, "Rasters: the DEM for Read Grid Zpts and any material, soil or water-level grids."),
    ("model/csv", False, "1D cross-section and hydraulic-property tables, pit inlet and other CSV tables."),
    ("results", True, "Map and time-series results (Output Folder)."),
    ("runs", True, "The .tcf files and the batch files you run."),
    ("runs/log", True, ".tlf / .hpc.tlf logs and the messages layers (Log Folder)."),
    ("exe", False, "A copy of the TUFLOW executable used, so the model can be re-run with the same build."),
    ("docs", False, "Reports, notes and data received for the project."),
]
DEFAULT_FOLDERS = [p for p, on, _d in FOLDER_TREE if on]


def normalise(rel):
    """'model\\gis/ survey ' -> 'model/gis/survey'; rejects absolute paths and '..'."""
    parts = [p.strip() for p in (rel or "").replace("\\", "/").split("/") if p.strip() and p.strip() != "."]
    if not parts or any(p == ".." for p in parts) or ":" in parts[0]:
        return ""
    return "/".join(parts)


def with_parents(rels):
    """Add every parent folder so 'model/gis/empty' also creates 'model' and 'model/gis'."""
    out = []
    for r in rels:
        r = normalise(r)
        if not r:
            continue
        bits = r.split("/")
        for i in range(1, len(bits) + 1):
            p = "/".join(bits[:i])
            if p not in out:
                out.append(p)
    return out


def create_folder_structure(base, rels=None, readme=False):
    """Create the folders under `base`. Returns (created, existing) as absolute paths.
    With readme=True a short readme.txt describing each new folder is written into it."""
    rels = with_parents(DEFAULT_FOLDERS if rels is None else rels)
    notes = {p: d for p, _on, d in FOLDER_TREE}
    created, existing = [], []
    if not os.path.isdir(base):
        os.makedirs(base)
    for r in rels:
        path = os.path.join(base, *r.split("/"))
        if os.path.isdir(path):
            existing.append(path)
            continue
        os.makedirs(path)
        created.append(path)
        if readme and r in notes:
            with open(os.path.join(path, "readme.txt"), "w") as f:
                f.write("{}\n\n{}\n\n(created by FMB tools)\n".format(r, notes[r]))
    return created, existing


def tree_text(rels, root_name="TUFLOW"):
    """ASCII preview of the folders that will be created."""
    rels = with_parents(rels)
    lines = [root_name.rstrip("/\\") + "/"]
    for r in sorted(rels, key=lambda s: s.lower().split("/")):
        depth = r.count("/")
        lines.append("    " * (depth + 1) + r.split("/")[-1] + "/")
    return "\n".join(lines)
