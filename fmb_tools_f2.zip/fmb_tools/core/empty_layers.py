# -*- coding: utf-8 -*-
"""
TUFLOW empty GIS layers: layer types, attribute structures, naming, writing
(GeoPackage or Shapefile via OGR) and the matching "Read GIS" commands.

TUFLOW reads attributes by POSITION and TYPE, not by name. The built-in
structures below were cross-checked against real TUFLOW layers (official QGIS
TUFLOW plugin test data), the TUFLOW manual and the TUFLOW tutorials. Layer
types without a built-in structure can still be created exactly by pointing
FMB tools at a folder of TUFLOW's own empty files (written by the
"Write Empty GIS Files" command) - that folder always wins when it is set.
"""
import glob
import os
import re

# field kinds
C, F, I = "C", "F", "I"


class Field(object):
    __slots__ = ("name", "kind", "width", "desc", "choices")

    def __init__(self, name, kind, width=0, desc="", choices=None):
        self.name = name
        self.kind = kind            # C text, F float, I integer
        self.width = width
        self.desc = desc
        self.choices = choices or []   # [(value, meaning)]

    @property
    def type_label(self):
        return {"C": "Char({})".format(self.width or 254), "F": "Float", "I": "Integer"}[self.kind]

    def __repr__(self):
        return "Field({} {})".format(self.name, self.type_label)


class LayerType(object):
    def __init__(self, code, title, ftype, command, geoms, default_geoms, group, guide, fields=None,
                 source="built-in", combine=True):
        self.code = code
        self.title = title
        self.ftype = ftype              # control file that reads it (None = several / check manual)
        self.command = command          # Read GIS command (lhs) or None
        self.geoms = geoms              # allowed: subset of "PLR"
        self.default_geoms = default_geoms
        self.group = group
        self.guide = guide              # {"P": text, "L": text, "R": text, "": general}
        self.fields = fields            # list of Field, or None (needs TUFLOW empties)
        self.source = source
        self.combine = combine          # read all geometries with one command

    @property
    def has_schema(self):
        return bool(self.fields)

    def __repr__(self):
        return "LayerType({})".format(self.code)


# ---------------------------------------------------------------------------
# attribute helpers
YES_NO = [("", "blank"), ("T", "true / yes"), ("F", "false / no")]

BC_TYPES_2D = [
    ("QT", "flow vs time (inflow) - line across the flow path or point"),
    ("HT", "water level vs time - downstream/tidal line"),
    ("HQ", "automatic stage-discharge (normal depth) outflow - line; slope in 'b'"),
    ("ST", "source flow vs time applied to cells - point or region"),
    ("RF", "rainfall vs time applied to cells"),
    ("HX", "1D water level to 2D link along 1D channel banks - line"),
    ("SX", "1D/2D flow link at culvert/pipe ends - point, line or region"),
    ("CN", "connection of a HX/SX line to 1D nodes - line"),
    ("2D", "2D/2D domain link - line"),
    ("CD", "set cell code (e.g. 2 for boundary cells)"),
    ("VG", "variable geometry"),
    ("HS", "sinusoidal / tidal water level"),
]
PO_TYPES = [
    ("H_", "water level at a point"),
    ("d_", "depth at a point"),
    ("V_", "velocity at a point"),
    ("VX", "velocity X component at a point"),
    ("VY", "velocity Y component at a point"),
    ("E_", "energy level at a point"),
    ("Q_", "total flow across a line"),
]
NWK_TYPES = [
    ("S", "open channel, all flow regimes"), ("G", "gradient channel"), ("", "normal channel (legacy)"),
    ("C", "circular culvert / pipe"), ("R", "rectangular culvert / box"), ("I", "irregular culvert"),
    ("B", "bridge (user loss coefficients)"), ("BB", "bridge (automatic losses)"), ("BArch", "arch bridge"),
    ("W", "weir"), ("WB", "weir variant WB (see manual)"), ("WC", "weir variant WC (see manual)"),
    ("WD", "weir variant WD (see manual)"), ("WO", "weir variant WO (see manual)"),
    ("WR", "weir variant WR (see manual)"), ("WT", "weir variant WT (see manual)"),
    ("WV", "weir variant WV (see manual)"), ("WW", "weir variant WW (see manual)"), ("VW", "variable geometry weir"),
    ("SG", "sluice gate"), ("SP", "spillway"), ("P", "pump"), ("M", "user-defined flow matrix"),
    ("Q", "depth-discharge channel"), ("X", "connector"), ("PF", "piping failure"), ("DF", "dam failure"),
]
XS_TYPES = [("XZ", "cross-section profile (distance, elevation)"), ("HW", "height-width table"),
            ("CS", "hydraulic properties table"), ("NA", "nodal area (storage) table"),
            ("BG", "bridge loss table"), ("LC", "loss coefficient table"), ("DD", "depth-discharge table")]
BC_TYPES_1D = [("QT", "flow vs time"), ("HT", "water level vs time"), ("HQ", "stage-discharge (slope=...)"),
               ("QH", "flow vs water level")]
ZSH_OPTIONS = [("", "set elevations (default)"), ("ADD", "add Z/dZ to existing"), ("MAX", "only raise"),
               ("RIDGE", "only raise (same as MAX)"), ("RAISE", "only raise"), ("MIN", "only lower"),
               ("GULLY", "only lower (same as MIN)"), ("LOWER", "only lower"), ("TIN", "triangulate region"),
               ("MERGE", "merge with neighbouring shapes"), ("NO MERGE", "do not merge")]


def _bc2d():
    return [Field("Type", C, 2, "BC type", BC_TYPES_2D), Field("Flags", C, 3, "optional flags"),
            Field("Name", C, 100, "row name in the BC database (bc_dbase.csv)"),
            Field("f", F, 0, "factor (e.g. multiplies flow)"), Field("d", F, 0, "offset / depth value"),
            Field("td", F, 0, "time offset"), Field("a", F, 0, "extra parameter a"),
            Field("b", F, 0, "extra parameter b (HQ: water surface slope)")]


def _zsh(first="Z"):
    return [Field(first, F, 0, "elevation"), Field("dZ", F, 0, "change in elevation"),
            Field("Shape_Width_or_dMax", F, 0, "line: width (m); region: max distance between points"),
            Field("Shape_Options", C, 20, "how the shape modifies Zpts", ZSH_OPTIONS)]


def _nwk():
    return [Field("ID", C, 36, "unique channel / node ID"),
            Field("Type", C, 8, "channel type", NWK_TYPES),
            Field("Ignore", C, 1, "T = ignore this object", YES_NO),
            Field("UCS", C, 1, "use channel storage at nodes", YES_NO),
            Field("Len_or_ANA", F, 0, "length (m); <=0 uses digitised length"),
            Field("n_nF_Cd", F, 0, "Manning's n (or factor / Cd)"),
            Field("US_Invert", F, 0, "upstream invert; -99999 = from table/node"),
            Field("DS_Invert", F, 0, "downstream invert; -99999 = from table/node"),
            Field("Form_Loss", F, 0, "additional form loss coefficient"),
            Field("pBlockage", F, 0, "percentage blockage"),
            Field("Inlet_Type", C, 50, "pit inlet type (pits)"),
            Field("Conn_1D_2D", C, 4, "1D/2D connection option"),
            Field("Conn_No", I, 0, "connection number"),
            Field("Width_or_Dia", F, 0, "culvert width or diameter (m)"),
            Field("Height_or_WF", F, 0, "culvert height (m) or weir factor"),
            Field("Number_of", I, 0, "number of barrels"),
            Field("HConF_or_WC", F, 0, "height contraction / weir coefficient"),
            Field("WConF_or_WEx", F, 0, "width contraction / weir exponent"),
            Field("EntryC_or_WSa", F, 0, "entry loss (typically 0.5)"),
            Field("ExitC_or_WSb", F, 0, "exit loss (typically 1.0)")]


def _xs():
    return ([Field("Source", C, 50, "CSV file with the table (relative path)"),
             Field("Type", C, 2, "table type", XS_TYPES),
             Field("Flags", C, 8, "optional flags")] +
            [Field("Column_{}".format(i), C, 20, "CSV column header to use") for i in range(1, 7)] +
            [Field("Z_Increment", F, 0, "height increment for XZ processing"),
             Field("Z_Maximum", F, 0, "maximum height for XZ processing"),
             Field("Skew", F, 0, "skew angle (degrees)")])


LAYER_TYPES = [
    # ---------------------------------------------------------------- TGC
    LayerType("2d_loc", "Grid location", "TGC", "Read GIS Location", "L", "L", "2D domain (TGC)",
              {"L": "Draw ONE line starting at the grid origin (lower-left corner) along the X axis. Its length "
                    "and direction set the grid orientation; set the grid size with Grid Size (X,Y)."},
              [Field("Comment", C, 250, "optional comment")]),
    LayerType("2d_code", "Active / inactive cells", "TGC", "Read GIS Code", "PLR", "R", "2D domain (TGC)",
              {"R": "Draw polygon(s) around the area to model and give them Code = 1. Draw holes / areas to "
                    "exclude (e.g. inside buildings modelled as blocked) with Code = 0.",
               "L": "Lines set the code of the cells they cross.",
               "P": "Points set the code of the cell they fall in."},
              [Field("Code", I, 0, "1 = active, 0 = inactive", [("1", "active"), ("0", "inactive")])]),
    LayerType("2d_mat", "Materials (land use)", "TGC", "Read GIS Mat", "R", "R", "2D domain (TGC)",
              {"R": "Draw land-use polygons (roads, buildings, grass, dense vegetation ...) and set Material to "
                    "an ID from materials.csv. Cells outside all polygons get the Set Mat default."},
              [Field("Material", I, 0, "material ID from the materials file")]),
    LayerType("2d_zsh", "Z shape (topography modifier)", "TGC", "Read GIS Z Shape", "PLR", "LP", "Topography (TGC)",
              {"L": "Draw breaklines along embankment crests, levees, roads or channel inverts. Set Shape_Width "
                    "for thick lines and Shape_Options (e.g. RIDGE / GULLY / ADD).",
               "P": "Snap points to line vertices to give their elevations (Z). Lines take elevations from snapped "
                    "points and interpolate between them.",
               "R": "Draw polygons to set/raise/lower a whole area (e.g. a building pad or basin)."},
              _zsh("Z")),
    LayerType("2d_lfcsh", "Layered flow constriction (2D bridges)", "TGC", "Read GIS Layered FC Shape", "PLR", "RP",
              "Structures (TGC)",
              {"R": "Draw a polygon over the bridge deck footprint. Fill the three layers: L1 below the deck "
                    "(pier blockage and losses), L2 the deck, L3 the railing, each with pBlockage and FLC.",
               "L": "Draw a line across the flow path for a thin structure.",
               "P": "Snap points to the polygon/line to vary the deck obvert (L1_Obvert) and layer depths."},
              [Field("Invert", F, 0, "invert elevation (99999 = use the ground)"), Field("dZ", F, 0, "change in elevation"),
               Field("Shape_Width_or_dMax", F, 0, "line width (m)"), Field("Shape_Options", C, 20, "options"),
               Field("L1_Obvert", F, 0, "layer 1 obvert (deck soffit) elevation"),
               Field("L1_pBlockage", F, 0, "layer 1 % blockage (piers)"), Field("L1_FLC", F, 0, "layer 1 form loss"),
               Field("L2_Depth", F, 0, "layer 2 depth (deck thickness)"),
               Field("L2_pBlockage", F, 0, "layer 2 % blockage (usually 100)"), Field("L2_FLC", F, 0, "layer 2 form loss"),
               Field("L3_Depth", F, 0, "layer 3 depth (railing)"), Field("L3_pBlockage", F, 0, "layer 3 % blockage"),
               Field("L3_FLC", F, 0, "layer 3 form loss"), Field("Notes", C, 250, "notes")],
              source="manual/tutorial"),
    LayerType("2d_bg", "Bridge geometry (BG shape)", "TGC", "Read GIS BG Shape", "LR", "R", "Structures (TGC)",
              {"R": "Draw a polygon over each bridge (deck footprint) and fill the pier, deck and rail attributes. "
                    "TUFLOW works out the losses.",
               "L": "Draw a line along the bridge centreline across the flow path."},
              [Field("ID", C, 36, "bridge ID"), Field("Option", C, 20, "reserved"),
               Field("Pier_pBlockage", F, 0, "pier layer % blockage"), Field("Pier_FLC", F, 0, "pier form loss"),
               Field("Deck_Soffit", F, 0, "deck soffit elevation"), Field("Deck_Depth", F, 0, "deck thickness"),
               Field("Deck_Width", F, 0, "deck width in the flow direction"),
               Field("Deck_pBlockage", F, 0, "deck % blockage"), Field("Rail_Depth", F, 0, "rail depth"),
               Field("Rail_pBlockage", F, 0, "rail % blockage"), Field("SuperS_FLC", F, 0, "superstructure form loss"),
               Field("SuperS_IPf", F, 0, "inflection point factor (default 1.6)")],
              source="release notes"),
    LayerType("2d_iwl", "Initial water level (2D)", "TCF", "Read GIS IWL", "PLR", "R", "Initial conditions",
              {"R": "Draw polygons over areas that start wet (lakes, ponds, the sea) and set IWL to the starting "
                    "water level.", "L": "Lines set the level of the cells they cross.",
               "P": "Points set the level of the cell they fall in."},
              [Field("IWL", F, 0, "initial water level (m)")]),
    # ---------------------------------------------------------------- TBC
    LayerType("2d_bc", "2D boundaries & 1D/2D links", "TBC", "Read GIS BC", "PLR", "L", "Boundaries (TBC)",
              {"L": "Inflow: draw a line across the flow path where water enters (Type QT, Name = BC database "
                    "row). Outflow: draw a line across the downstream edge (Type HQ, slope in 'b', or HT with a "
                    "level curve). 1D/2D: HX lines along the channel banks with CN lines to the 1D nodes.",
               "P": "Points for ST sources or SX links at culvert / pipe ends.",
               "R": "Regions to apply ST / RF boundaries or SX links over an area."},
              _bc2d()),
    LayerType("2d_sa", "Source areas (inflow hydrographs)", "TBC", "Read GIS SA", "R", "R", "Boundaries (TBC)",
              {"R": "Draw polygons over the areas where a hydrograph is applied; the flow goes to the lowest wet "
                    "cells inside. Name = BC database row."},
              [Field("Name", C, 100, "BC database name")]),
    LayerType("2d_sa_rf", "Source areas from rainfall", "TBC", "Read GIS SA RF", "R", "R", "Boundaries (TBC)",
              {"R": "Draw sub-catchment polygons that route rainfall (hyetograph) with losses to the lowest cells."},
              [Field("Name", C, 100, "rainfall BC name"), Field("Catchment_Area", F, 0, "catchment area (m2)"),
               Field("Rain_Gauge_Factor", F, 0, "rainfall multiplier"), Field("IL", F, 0, "initial loss (mm)"),
               Field("CL", F, 0, "continuing loss (mm/h)")]),
    LayerType("2d_sa_tr", "Source areas with trigger", "TBC", "Read GIS SA TRIGGER", "R", "R", "Boundaries (TBC)",
              {"R": "Source-area polygons that start when a flow or level at a 2d_po location reaches a value."},
              [Field("Name", C, 100, "BC name"),
               Field("Trigger_Type", C, 40, "Q_ flow or H_ level", [("Q_", "flow"), ("H_", "water level")]),
               Field("Trigger_Location", C, 40, "Label of the 2d_po object"), Field("Trigger_Value", F, 0, "trigger value")]),
    LayerType("2d_sa_po", "Source areas driven by a PO result", "TBC", "Read GIS SA PO", "R", "R", "Boundaries (TBC)",
              {"R": "Source-area polygons whose flow follows an H vs Q curve of a 2d_po flow or level result."},
              [Field("Name", C, 100, "curve name"), Field("PO_Type", C, 16, "Q_ or H_", [("Q_", "flow"), ("H_", "level")]),
               Field("PO_Label", C, 40, "Label of the 2d_po object")]),
    LayerType("2d_rf", "Rainfall polygons", "TBC", "Read GIS RF", "R", "R", "Boundaries (TBC)",
              {"R": "Draw polygons that apply a rainfall hyetograph (Name = BC database row) with factors f1 "
                    "(spatial) and f2 (temporal). Use Global Rainfall BC instead for uniform rain over the model."},
              [Field("Name", C, 100, "rainfall BC name"), Field("f1", F, 0, "factor 1"), Field("f2", F, 0, "factor 2")]),
    # ---------------------------------------------------------------- TCF outputs
    LayerType("2d_po", "Plot output locations", "TCF", "Read GIS PO", "PL", "PL", "Outputs (TCF)",
              {"P": "Points where you want time series: Type H_ (level), V_ (velocity), d_ (depth). Give each a "
                    "Label.", "L": "Lines across flow paths for flow time series: Type Q_. Give each a Label."},
              [Field("Type", C, 20, "output type (combine e.g. H_V_)", PO_TYPES),
               Field("Label", C, 30, "name shown in results"), Field("Comment", C, 250, "comment")]),
    # ---------------------------------------------------------------- QCF
    LayerType("2d_qnl", "Quadtree nesting levels", "QCF", "Read GIS Nesting", "R", "R", "Quadtree (QCF)",
              {"R": "Draw polygons where finer cells are needed and set Nest_Level: 1 halves the cell size, "
                    "2 quarters it, and so on. Nest polygons of higher levels inside lower ones."},
              [Field("Nest_Level", I, 0, "refinement level (1, 2, 3 ...)")], source="tutorial"),
    # ---------------------------------------------------------------- ECF
    LayerType("1d_nwk", "1D network (channels, culverts, pipes)", "ECF", "Read GIS Network", "PL", "L", "1D network (ECF)",
              {"L": "Draw each channel / culvert / pipe from upstream to downstream. Set ID, Type (S open "
                    "channel, C circular, R box ...), inverts, sizes and losses. Snap line ends to each other or "
                    "to nodes.", "P": "Points at line ends for nodes (manholes, junctions, storage)."},
              _nwk()),
    LayerType("1d_xs", "1D cross-sections", "ECF", "Read GIS Table Links", "L", "L", "1D network (ECF)",
              {"L": "Draw cross-section lines across open channels (left to right looking downstream), each "
                    "intersecting its 1d_nwk channel. Source = CSV with the profile, Type = XZ."},
              _xs()),
    LayerType("1d_tab", "1D table links", "ECF", "Read GIS Table Links", "PL", "L", "1D network (ECF)",
              {"L": "Lines crossing a channel to link a table (HW, CS, BG, LC ...).",
               "P": "Points on nodes to link nodal area (NA) tables."},
              _xs()),
    LayerType("1d_bc", "1D boundaries", "ECF", "Read GIS BC", "PR", "P", "1D network (ECF)",
              {"P": "Snap a point to the 1D node where the boundary applies (Type QT inflow, HT or HQ outflow). "
                    "Name = BC database row.", "R": "QT regions spread an inflow over the nodes inside."},
              [Field("Type", C, 2, "BC type", BC_TYPES_1D), Field("Flags", C, 6, "optional flags"),
               Field("Name", C, 50, "BC database name"), Field("Description", C, 250, "description")]),
]

# Types TUFLOW can write as empty files but without a built-in structure here.
# They are created from TUFLOW's own empty files (Write Empty GIS Files folder).
_EMPTIES_ONLY = [
    ("2d_soil", "Soils (infiltration)", "TGC", "Read GIS Soil", "Soil type polygons for infiltration", "Soils & groundwater"),
    ("2d_gw", "Groundwater", "TGC", None, "Groundwater level / depth inputs", "Soils & groundwater"),
    ("2d_fcsh", "Flow constriction shape", "TGC", "Read GIS FC Shape", "Bridge losses below the obvert", "Structures (TGC)"),
    ("2d_flc", "Form loss coefficient", "TGC", "Read GIS FLC", "Energy losses at 2D cell sides", "Structures (TGC)"),
    ("2d_wrf", "Weir factor", "TGC", "Read GIS WrF", "Local weir factor (e.g. road embankments)", "Structures (TGC)"),
    ("2d_cwf", "Cell width factor", "TGC", "Read GIS CWF", "Reduced 2D cell flow width", "Structures (TGC)"),
    ("2d_vzsh", "Variable Z shape (breach)", "TGC", "Read GIS Variable Z Shape", "Time-varying elevations, e.g. dam / levee breach", "Topography (TGC)"),
    ("2d_zshr", "Z shape route", "TGC", "Read GIS Z Shape Route", "Evacuation route cut-off output", "Topography (TGC)"),
    ("2d_zpt", "Elevation points", "TGC", "Read GIS Zpts", "Elevations at 2D cell Zpts", "Topography (TGC)"),
    ("2d_obj", "Objects / receptors", "TGC", "Read GIS Objects", "Buildings / properties for hazard reporting", "Outputs (TCF)"),
    ("2d_rec", "Receptors", "TGC", "Read GIS Receptors", "Receptors for flood hazard gauging", "Outputs (TCF)"),
    ("2d_strm", "Streamlines", "TBC", "Read GIS Streams", "Streamlines for SA inflows", "Boundaries (TBC)"),
    ("2d_lp", "Long profile output", "TCF", "Read GIS LP", "Longitudinal profile output lines", "Outputs (TCF)"),
    ("2d_oz", "Output zones", "TCF", "Read GIS Output Zone", "Polygons for output zones", "Outputs (TCF)"),
    ("0d_rl", "Reporting locations", "TCF", "Read GIS Reporting Location", "1D/2D reporting locations", "Outputs (TCF)"),
    ("2d_glo", "Gauge level output", "TCF", "Read GIS GLO", "Gauge level output locations", "Outputs (TCF)"),
    ("2d_at", "Auto terminate", "TCF", "Read GIS Auto Terminate", "Locations tracked for auto-terminate", "Outputs (TCF)"),
    ("2d_fc", "Flow constriction (legacy)", "TCF", "Read GIS FC", "Bridge/culvert losses (use 2d_lfcsh)", "Structures (TGC)"),
    ("1d_iwl", "Initial water level (1D)", "ECF", "Read GIS IWL", "Initial water levels at 1D nodes", "Initial conditions"),
    ("1d_pit", "Pits", "ECF", "Read GIS Pits", "Pit / inlet locations", "1D network (ECF)"),
    ("1d_mh", "Manholes", "ECF", "Read GIS Manhole", "Manhole locations and losses", "1D network (ECF)"),
    ("1d_nd", "1D nodes", "ECF", "Read GIS Node", "1D node locations and attributes", "1D network (ECF)"),
    ("1d_na", "Nodal areas", "ECF", None, "Nodal storage area tables", "1D network (ECF)"),
    ("1d_nwkb", "Network blockage", "ECF", "Read GIS Network", "Culvert blockage matrix inputs", "1D network (ECF)"),
    ("1d_nwke", "Network (extended)", "ECF", "Read GIS Network", "Grouped structures", "1D network (ECF)"),
    ("1d_wll", "Water level lines", "ECF", "Read GIS WLL", "Lines to map 1D results onto 2D", "1D network (ECF)"),
    ("1d_wllp", "Water level line points", "ECF", "Read GIS WLL Points", "Elevations/materials along WLLs", "1D network (ECF)"),
]
for code, title, ft, cmd, desc, grp in _EMPTIES_ONLY:
    LAYER_TYPES.append(LayerType(code, title, ft, cmd, "PLR", "R" if code not in ("2d_lp", "1d_wll", "2d_strm") else "L",
                                 grp, {"": desc + ". The attribute structure comes from TUFLOW's own empty files "
                                             "(set the TUFLOW empties folder above)."}, None, source="TUFLOW empties"))

BY_CODE = {lt.code: lt for lt in LAYER_TYPES}
GROUP_ORDER = ["2D domain (TGC)", "Topography (TGC)", "Initial conditions", "Boundaries (TBC)", "Structures (TGC)",
               "1D network (ECF)", "Quadtree (QCF)", "Outputs (TCF)", "Soils & groundwater"]

PRESETS = {
    "2D base model": {"2d_loc": "L", "2d_code": "R", "2d_mat": "R", "2d_bc": "L", "2d_po": "PL"},
    "Topography update": {"2d_zsh": "LP"},
    "Direct rainfall": {"2d_code": "R", "2d_mat": "R", "2d_bc": "L", "2d_rf": "R", "2d_po": "PL"},
    "Source-area inflows": {"2d_sa": "R", "2d_bc": "L", "2d_po": "PL"},
    "1D/2D culverts": {"1d_nwk": "L", "2d_bc": "PL"},
    "1D open channel": {"1d_nwk": "L", "1d_xs": "L", "1d_bc": "P", "2d_bc": "L"},
    "2D bridges": {"2d_lfcsh": "RP"},
    "Quadtree": {"2d_qnl": "R"},
    "Initial water level": {"2d_iwl": "R"},
}

GEOM_NAMES = {"P": "points", "L": "lines", "R": "regions"}


# ---------------------------------------------------------------------------
def layer_name(code, stem, geom):
    stem = (stem or "").strip().strip("_")
    return "{}_{}_{}".format(code, stem, geom) if stem else "{}_{}".format(code, geom)


def valid_stem(stem):
    return bool(re.fullmatch(r"[A-Za-z0-9_\-~]*", stem or ""))


class LayerJob(object):
    """One layer to write."""

    def __init__(self, ltype, geom, name, fields, defaults=None):
        self.ltype = ltype
        self.geom = geom
        self.name = name
        self.fields = fields
        self.defaults = defaults or {}       # field name -> value (applied as QGIS default values)
        self.path = ""                       # file written
        self.uri = ""                        # QGIS data source

    def __repr__(self):
        return "LayerJob({})".format(self.name)


# ---------------------------------------------------------------------------
# TUFLOW's own empty files
_EMPTY_RE = re.compile(r"^(?P<code>.+?)_empty(?P<pts>_pts)?(?:_(?P<geom>[PLR]))?$", re.IGNORECASE)


def scan_empty_folder(folder):
    """Return {code: {geom: (path, layername)}} for TUFLOW empty files in `folder`
    (SHP, MIF or GPKG, including one GeoPackage holding all empties)."""
    out = {}
    if not folder or not os.path.isdir(folder):
        return out

    def add(name, path, layer):
        m = _EMPTY_RE.match(name)
        if not m:
            return
        code = m.group("code") + ("_pts" if m.group("pts") else "")
        geom = (m.group("geom") or "").upper()
        out.setdefault(code, {})[geom or "?"] = (path, layer)

    for path in sorted(glob.glob(os.path.join(folder, "*"))):
        ext = os.path.splitext(path)[1].lower()
        if ext in (".shp", ".mif"):
            add(os.path.splitext(os.path.basename(path))[0], path, "")
        elif ext == ".gpkg":
            from .qc import gpkg_layers
            for lyr in gpkg_layers(path) or []:
                add(lyr, path, lyr)
    return out


def read_schema(path, layer=""):
    """Read fields and geometry of a TUFLOW empty file with OGR -> ([Field], geom letter)."""
    from osgeo import ogr
    ds = ogr.Open(path)
    if ds is None:
        raise IOError("Cannot open {}".format(path))
    lyr = ds.GetLayerByName(layer) if layer else ds.GetLayer(0)
    defn = lyr.GetLayerDefn()
    fields = []
    for i in range(defn.GetFieldCount()):
        fd = defn.GetFieldDefn(i)
        t = fd.GetType()
        if t in (ogr.OFTInteger, ogr.OFTInteger64):
            kind = I
        elif t == ogr.OFTReal:
            kind = F
        else:
            kind = C
        fields.append(Field(fd.GetName(), kind, fd.GetWidth() if kind == C else 0, "from TUFLOW empty"))
    gt = ogr.GT_Flatten(lyr.GetGeomType())
    geom = {ogr.wkbPoint: "P", ogr.wkbMultiPoint: "P", ogr.wkbLineString: "L", ogr.wkbMultiLineString: "L",
            ogr.wkbPolygon: "R", ogr.wkbMultiPolygon: "R"}.get(gt, "")
    ds = None
    return fields, geom


# ---------------------------------------------------------------------------
# writing
def _ogr_geom(geom):
    from osgeo import ogr
    return {"P": ogr.wkbPoint, "L": ogr.wkbLineString, "R": ogr.wkbPolygon}[geom]


def _srs(crs_wkt=None, epsg=None):
    from osgeo import osr
    srs = osr.SpatialReference()
    if crs_wkt:
        srs.ImportFromWkt(crs_wkt)
    elif epsg:
        srs.ImportFromEPSG(int(epsg))
    else:
        return None
    try:
        srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    except AttributeError:
        pass
    return srs


def _shp_names(fields):
    """Shapefile field names are limited to 10 characters - keep them unique."""
    out, used = [], set()
    for f in fields:
        n = f.name[:10]
        k = 1
        while n.lower() in used:
            suffix = str(k)
            n = f.name[:10 - len(suffix)] + suffix
            k += 1
        used.add(n.lower())
        out.append(n)
    return out


def write_layers(jobs, fmt, target, crs_wkt=None, epsg=None, overwrite=False):
    """Create empty layers with OGR.

    fmt: 'gpkg'      -> all layers in one GeoPackage `target` (a .gpkg path)
         'gpkg_each' -> one GeoPackage per layer in folder `target`
         'shp'       -> one Shapefile per layer in folder `target`
    Returns (written_jobs, skipped[(job, reason)])."""
    from osgeo import ogr
    ogr.UseExceptions()
    srs = _srs(crs_wkt, epsg)
    written, skipped = [], []
    folder = os.path.dirname(target) if fmt == "gpkg" else target
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    gpkg_ds = None
    if fmt == "gpkg":
        drv = ogr.GetDriverByName("GPKG")
        gpkg_ds = drv.Open(target, 1) if os.path.exists(target) else drv.CreateDataSource(target)
    for job in jobs:
        if not job.fields:
            skipped.append((job, "no attribute structure (set the TUFLOW empties folder)"))
            continue
        if fmt == "gpkg":
            ds, path = gpkg_ds, target
        elif fmt == "gpkg_each":
            path = os.path.join(target, job.name + ".gpkg")
            if os.path.exists(path):
                if not overwrite:
                    skipped.append((job, "exists"))
                    continue
                ogr.GetDriverByName("GPKG").DeleteDataSource(path)
            ds = ogr.GetDriverByName("GPKG").CreateDataSource(path)
        else:
            path = os.path.join(target, job.name + ".shp")
            if os.path.exists(path):
                if not overwrite:
                    skipped.append((job, "exists"))
                    continue
                ogr.GetDriverByName("ESRI Shapefile").DeleteDataSource(path)
            ds = ogr.GetDriverByName("ESRI Shapefile").CreateDataSource(path)
        if fmt == "gpkg" and ds.GetLayerByName(job.name) is not None:
            if not overwrite:
                skipped.append((job, "exists"))
                continue
            for i in range(ds.GetLayerCount()):
                if ds.GetLayer(i).GetName() == job.name:
                    ds.DeleteLayer(i)
                    break
        opts = ["ENCODING=UTF-8"] if fmt == "shp" else []
        name = job.name
        lyr = ds.CreateLayer(name, srs, _ogr_geom(job.geom), options=opts)
        names = _shp_names(job.fields) if fmt == "shp" else [f.name for f in job.fields]
        for f, n in zip(job.fields, names):
            if f.kind == I:
                fd = ogr.FieldDefn(n, ogr.OFTInteger)
                if fmt == "shp":
                    fd.SetWidth(10)
            elif f.kind == F:
                fd = ogr.FieldDefn(n, ogr.OFTReal)
                if fmt == "shp":
                    fd.SetWidth(24)
                    fd.SetPrecision(15)
            else:
                fd = ogr.FieldDefn(n, ogr.OFTString)
                fd.SetWidth(max(1, min(f.width or 254, 254)))
            lyr.CreateField(fd)
        lyr = None
        if fmt != "gpkg":
            ds = None
        job.path = path
        job.uri = "{}|layername={}".format(path, name) if fmt.startswith("gpkg") else path
        written.append(job)
    gpkg_ds = None
    return written, skipped


# ---------------------------------------------------------------------------
# control-file commands
def _rel(path, base):
    try:
        rel = os.path.relpath(path, base) if base else path
    except ValueError:
        rel = path
    return rel.replace("/", "\\")


def build_commands(jobs, fmt, control_dirs, spatial_db=None):
    """Return [(ftype, command_lhs, value)] reading the written layers.

    control_dirs: {ftype: folder of that control file}
    spatial_db:   absolute path of the TCF Spatial Database (layer names only when the
                  layers were written into that GeoPackage)."""
    grouped = {}
    for j in jobs:
        lt = j.ltype
        if not lt.command or not lt.ftype:
            continue
        key = (lt.ftype, lt.command, lt.code if lt.combine else j.name)
        grouped.setdefault(key, []).append(j)
    out = []
    order = {"P": 2, "L": 1, "R": 0}
    for (ftype, cmd, _k), js in grouped.items():
        js = sorted(js, key=lambda x: order.get(x.geom, 9))
        base = control_dirs.get(ftype, "")
        if fmt == "gpkg":
            same_db = spatial_db and os.path.normcase(os.path.abspath(spatial_db)) == \
                os.path.normcase(os.path.abspath(js[0].path))
            if same_db:
                value = " | ".join(j.name for j in js)
            else:
                value = "{} >> {}".format(_rel(js[0].path, base), " && ".join(j.name for j in js))
        else:
            value = " | ".join(_rel(j.path, base) for j in js)
        out.append((ftype, cmd, value))
    return out


# ---------------------------------------------------------------------------
# fields whose values form a closed list -> dropdown (ValueMap) in the QGIS attribute form
CLOSED_FIELDS = {("2d_code", "Code"), ("1d_xs", "Type"), ("1d_tab", "Type"), ("1d_bc", "Type"),
                 ("2d_sa_tr", "Trigger_Type"), ("2d_sa_po", "PO_Type"), ("1d_nwk", "Ignore"), ("1d_nwk", "UCS")}


def default_expression(field, value):
    """QGIS default-value expression for a field."""
    if value is None or str(value).strip() == "":
        return ""
    v = str(value).strip()
    if field.kind in (I, F):
        try:
            float(v)
            return v
        except ValueError:
            return ""
    return "'{}'".format(v.replace("'", "''"))


# ---------------------------------------------------------------------------
# asking TUFLOW itself to write its empty files
def write_projection_layer(folder, fmt, crs_wkt=None, epsg=None):
    """Create a tiny layer holding only the projection. Returns its path."""
    from osgeo import ogr
    ogr.UseExceptions()
    if not os.path.isdir(folder):
        os.makedirs(folder)
    srs = _srs(crs_wkt, epsg)
    if fmt == "shp":
        path = os.path.join(folder, "projection.shp")
        drv = ogr.GetDriverByName("ESRI Shapefile")
    else:
        path = os.path.join(folder, "projection.gpkg")
        drv = ogr.GetDriverByName("GPKG")
    if os.path.exists(path):
        drv.DeleteDataSource(path)
    ds = drv.CreateDataSource(path)
    lyr = ds.CreateLayer("projection", srs, ogr.wkbPoint)
    lyr.CreateField(ogr.FieldDefn("ID", ogr.OFTInteger))
    lyr = None
    ds = None
    return path


def empties_tcf_text(empty_folder, fmt, projection_path, tcf_dir):
    """A minimal TCF that makes TUFLOW write its empty files and stop."""
    rel_proj = _rel(projection_path, tcf_dir)
    rel_empty = _rel(empty_folder, tcf_dir).rstrip("\\") + "\\"
    lines = ["! Written by FMB tools - asks TUFLOW to write its empty GIS files",
             "GIS Format == {}".format("SHP" if fmt == "shp" else "GPKG"),
             "{} == {}".format("SHP Projection" if fmt == "shp" else "GPKG Projection",
                               rel_proj if fmt != "shp" else rel_proj[:-4] + ".prj"),
             "Write Empty GIS Files == {}".format(rel_empty)]
    return "\r\n".join(lines) + "\r\n"


# ---------------------------------------------------------------------------
# What to enter in each field. Written for FMB tools from the TUFLOW manual,
# tutorials and TUFLOW's own layers - always check the manual section linked
# in the tab for the full rules.
_ZSH_GUIDE = {
    "Z": "Elevation (m). Points: the elevation at that vertex (lines between snapped points are interpolated). "
         "Lines: the elevation used where no points are snapped. Regions: used with options such as ADD.",
    "dZ": "Change in elevation (m) applied on top of Z / the existing ground, e.g. 0.3 to raise a crest. 0 = none.",
    "Shape_Width_or_dMax": "Lines: width of the breakline in m - 0 or less gives a thin line (cell sides only), a "
                           "width larger than the cell changes every Zpt inside the width. Regions: maximum spacing "
                           "of points added around the edge. Not used for points.",
    "Shape_Options": "Blank = set the elevations. RIDGE / MAX / RAISE only raise the ground, GULLY / MIN / LOWER "
                     "only lower it, ADD adds Z or dZ to the ground. Regions also accept MERGE / NO MERGE and TIN.",
}
FIELD_GUIDE = {
    "2d_loc": {"Comment": "Free text, not used by TUFLOW. What matters is the line: its first vertex is the grid "
                          "origin and its direction is the grid X axis."},
    "2d_code": {"Code": "Integer. 1 = active cell (water can flow), 0 = inactive (removed from the model). "
                        "Commands later in the TGC overwrite earlier ones, so keep 'Set Code == 0' before this layer."},
    "2d_mat": {"Material": "Integer material ID - must exist in the first column of materials.csv (Read Materials "
                           "File in the TCF). The ID sets Manning's n (optionally depth-varying), rainfall losses and "
                           "other land-use properties. Polygons read later overwrite earlier ones; cells outside all "
                           "polygons get the 'Set Mat' default."},
    "2d_zsh": _ZSH_GUIDE,
    "2d_lfcsh": dict(_ZSH_GUIDE, **{
        "Invert": "Bed elevation (m) under the structure. 99999 = keep the existing ground (as in the TUFLOW tutorial).",
        "L1_Obvert": "Elevation (m) of the top of layer 1 - the deck soffit. Snap points to vary it along the bridge.",
        "L1_pBlockage": "% of the layer-1 flow area blocked, e.g. by piers (0-100).",
        "L1_FLC": "Form loss coefficient for flow through layer 1 (below the deck).",
        "L2_Depth": "Thickness (m) of layer 2 above L1_Obvert - usually the deck depth.",
        "L2_pBlockage": "% of layer 2 blocked - normally 100 for a solid deck.",
        "L2_FLC": "Form loss coefficient for layer 2 (flow over / against the deck).",
        "L3_Depth": "Thickness (m) of layer 3 above layer 2 - usually railings / parapets.",
        "L3_pBlockage": "% of layer 3 blocked, e.g. partly open railings.",
        "L3_FLC": "Form loss coefficient for layer 3.",
        "Notes": "Free text for your own notes (e.g. bridge name).",
    }),
    "2d_bg": {
        "ID": "Unique bridge ID (text).", "Option": "Reserved by TUFLOW - leave blank.",
        "Pier_pBlockage": "% of the waterway blocked by piers (0-100).",
        "Pier_FLC": "Form loss coefficient of the pier layer.",
        "Deck_Soffit": "Elevation (m) of the underside of the deck.",
        "Deck_Depth": "Deck thickness (m).", "Deck_Width": "Deck width (m) in the main flow direction.",
        "Deck_pBlockage": "% of the deck layer blocked (usually 100).", "Rail_Depth": "Railing depth (m).",
        "Rail_pBlockage": "% of the railing layer blocked.",
        "SuperS_FLC": "Combined form loss coefficient of deck and railings. Can be left blank when 'Blank BG FLC "
                      "Approach' is set in the TCF so TUFLOW estimates it.",
        "SuperS_IPf": "Inflection point elevation factor (TUFLOW default 1.6).",
    },
    "2d_iwl": {"IWL": "Initial water level (m) for cells inside / under the object. Cells whose ground is below this "
                      "level start wet."},
    "2d_bc": {
        "Type": "Two-letter boundary type. Common: QT flow vs time (line across the flow), HT water level vs time "
                "(line), HQ automatic stage-discharge outflow (line), ST source flow vs time (point / region), "
                "HX 1D-to-2D level link along channel banks (line), SX 1D/2D flow link at culvert or pipe ends, "
                "CN connection line from HX/SX to a 1D node, 2D link between 2D domains.",
        "Flags": "Optional flags (up to 3 characters), e.g. S = spline-interpolate the curve. Usually blank - see the "
                 "manual for all flags.",
        "Name": "Name of the row in the BC database (bc_dbase.csv) holding the curve. Not needed for HX, SX, CN or "
                "code boundaries.",
        "f": "Factor multiplying the boundary values (e.g. 1.2 = +20% flow). For CN lines a weighting; for code "
             "boundaries the code value.",
        "d": "Offset added to the boundary values (e.g. +0.2 m on a tide). For HX / ZP objects an adjustment of the "
             "cell elevations.",
        "td": "Time shift of the boundary curve (h) - positive delays it.",
        "a": "Extra parameter: storage / form loss multiplier for HX and SX links, or the flow angle for QT with "
             "the A flag.",
        "b": "Extra parameter: for HQ the water-surface slope (m/m) used for the normal-depth outflow; otherwise a "
             "value increment.",
    },
    "2d_sa": {"Name": "BC database row with a flow hydrograph (time, flow). The flow enters at the lowest wet cell(s) "
                      "inside the polygon, following the water as it spreads."},
    "2d_sa_rf": {"Name": "BC database row with a rainfall hyetograph (time, rainfall).",
                 "Catchment_Area": "Catchment area (m2) used to turn rainfall into flow.",
                 "Rain_Gauge_Factor": "Multiplier on the rainfall (e.g. areal reduction or gauge adjustment).",
                 "IL": "Initial loss (mm) - rain lost before runoff starts.",
                 "CL": "Continuing loss (mm/h) after the initial loss is satisfied."},
    "2d_sa_tr": {"Name": "BC database row with the hydrograph applied once triggered.",
                 "Trigger_Type": "Q_ = triggered by a flow, H_ = by a water level.",
                 "Trigger_Location": "Label of the 2d_po point / line whose result is watched.",
                 "Trigger_Value": "Flow (m3/s) or level (m) that starts the inflow."},
    "2d_sa_po": {"Name": "BC database row with the curve relating the watched result to the inflow.",
                 "PO_Type": "Q_ = flow result, H_ = water level result.",
                 "PO_Label": "Label of the 2d_po object to watch."},
    "2d_rf": {"Name": "BC database row with a rainfall hyetograph (time, rainfall).",
              "f1": "First rainfall factor (e.g. spatial adjustment for this polygon).",
              "f2": "Second rainfall factor (e.g. temporal adjustment)."},
    "2d_po": {"Type": "What to output. Points: H_ water level, d_ depth, V_ velocity (and VX / VY components). "
                      "Lines: Q_ total flow across the line. The manual lists further types.",
              "Label": "Unique name (max 30 characters) used in the _PO.csv and plot result files.",
              "Comment": "Free text."},
    "2d_qnl": {"Nest_Level": "Integer refinement level: 1 = cells half the base cell size, 2 = a quarter, 3 = an "
                             "eighth. Draw higher levels inside lower-level polygons."},
    "1d_nwk": {
        "ID": "Unique channel or node ID - no spaces, commas or quotes.",
        "Type": "Channel type, e.g. S open channel, C circular culvert/pipe, R box culvert, I irregular culvert, "
                "B / BB bridge, W weir, P pump, X connector. Flags can be appended (e.g. U uni-directional).",
        "Ignore": "T (or Y) = ignore this object; blank or F = use it.",
        "UCS": "Use channel storage at the nodes: T (default when blank) or F.",
        "Len_or_ANA": "Channel length (m). 0 or negative = use the digitised line length. For nodes: extra "
                      "storage area.",
        "n_nF_Cd": "Manning's n for channels / culverts (e.g. 0.013 concrete pipe), or a factor / discharge "
                   "coefficient for other types.",
        "US_Invert": "Upstream invert (m). -99999 = take it from the cross-section, node or pit.",
        "DS_Invert": "Downstream invert (m). -99999 = take it from the cross-section, node or pit.",
        "Form_Loss": "Additional form loss coefficient (e.g. for bends or junctions).",
        "pBlockage": "% blockage of culverts / pipes (0-100).",
        "Inlet_Type": "Pit inlet reference for pits (from the pit inlet database). Blank for channels.",
        "Conn_1D_2D": "1D/2D connection option used for pits and nodes. Usually blank for channels.",
        "Conn_No": "Legacy connection number - usually 0.",
        "Width_or_Dia": "C: pipe diameter (m). R: box width (m).",
        "Height_or_WF": "R: box height (m). Weirs: weir factor.",
        "Number_of": "Number of identical barrels (0 or 1 = one).",
        "HConF_or_WC": "Culverts: height contraction coefficient (typically 0.6-0.8). Weirs: weir coefficient.",
        "WConF_or_WEx": "Culverts: width contraction coefficient (typically 0.9-1.0). Weirs: weir exponent.",
        "EntryC_or_WSa": "Culverts: entry loss coefficient (typically 0.5).",
        "ExitC_or_WSb": "Culverts: exit loss coefficient (typically 1.0).",
    },
    "1d_xs": {
        "Source": "CSV file with the table, relative to this GIS layer's folder (e.g. ..\\xs\\XS_01.csv).",
        "Type": "XZ = cross-section profile (distance, elevation); HW / CS = hydraulic property tables; NA = "
                "nodal storage; BG / LC = bridge and loss tables; DD = depth-discharge.",
        "Flags": "Optional flags, e.g. for XZ which extra CSV columns hold roughness or markers. Usually blank.",
        "Column_1": "Header of the CSV column to read first (e.g. the distance column). Blank = first column.",
        "Column_2": "Header of the second CSV column (e.g. elevation). Blank = next column.",
        "Column_3": "Optional third column (e.g. Manning's n or relative resistance).",
        "Column_4": "Optional fourth column.", "Column_5": "Optional fifth column.",
        "Column_6": "Optional sixth column.",
        "Z_Increment": "Vertical increment (m) used to build the property table from an XZ profile. 0 = default.",
        "Z_Maximum": "Top elevation (m) of the property table. 0 = top of the profile.",
        "Skew": "Skew angle (degrees) of the cross-section to the flow.",
    },
    "1d_bc": {"Type": "QT inflow vs time, HT water level vs time, HQ stage-discharge, QH flow vs level.",
              "Flags": "Optional flags, e.g. S = spline. Usually blank.",
              "Name": "BC database row with the curve.",
              "Description": "Free text."},
}
FIELD_GUIDE["1d_tab"] = FIELD_GUIDE["1d_xs"]

# generic guidance for fields copied from TUFLOW's own empty files
GENERIC_GUIDE = {
    "soil_id": "Integer soil ID defined in the soils file (Read Soils File in the TCF).",
    "wrf": "Weir factor - multiplies the weir coefficient (1 = no change).",
    "flc": "Form loss coefficient applied to the cell sides crossed.",
    "cwf": "Cell width factor between 0 and 1 (fraction of the cell width available to flow).",
    "id": "Identifier (text).", "name": "Name (text).", "label": "Label used in outputs.",
    "comment": "Free text.", "notes": "Free text.", "iwl": "Initial water level (m).",
    "z": "Elevation (m).", "dz": "Change in elevation (m).",
}


def field_guide(code, field_name):
    g = FIELD_GUIDE.get(code, {})
    for k, v in g.items():
        if k.lower() == field_name.lower():
            return v
    # shapefile-truncated names (10 characters)
    for k, v in g.items():
        if len(field_name) == 10 and k.lower().startswith(field_name.lower()):
            return v
    return GENERIC_GUIDE.get(field_name.lower(), "")


def shp_field_names(fields):
    """Names the fields get in a Shapefile (10-character limit)."""
    return _shp_names(fields)


# ---------------------------------------------------------------------------
# 2d_loc / 2d_code from a drawn domain
def add_features(job, fmt, features):
    """Append features to a layer written by write_layers. features: [(wkt, {field: value})]."""
    from osgeo import ogr
    ogr.UseExceptions()
    ds = ogr.Open(job.path, 1)
    lyr = ds.GetLayerByName(job.name) if fmt == "gpkg" else ds.GetLayer(0)
    defn = lyr.GetLayerDefn()
    names = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
    lower = {n.lower(): n for n in names}
    for wkt, attrs in features:
        f = ogr.Feature(defn)
        f.SetGeometry(ogr.CreateGeometryFromWkt(wkt))
        for k, v in (attrs or {}).items():
            n = lower.get(k.lower()) or lower.get(k.lower()[:10])
            if n is not None:
                f.SetField(n, v)
        lyr.CreateFeature(f)
        f = None
    lyr.SyncToDisk()
    ds = None


def write_domain_layers(domain, fmt, target, stem, control_dirs, crs_wkt=None, area_points=None,
                        write_loc=True, spatial_db=None, overwrite=True):
    """Write the 2D domain as a 2d_loc line (origin -> along the X axis) and, optionally, the
    drawn area as a 2d_code polygon (Code = 1). Returns {command: value} for the TGC, e.g.
    {'Read GIS Location': '2d_loc_M01_L', 'Read GIS Code': '2d_code_M01_R'}."""
    jobs, feats = [], {}
    if write_loc:
        j = LayerJob(BY_CODE["2d_loc"], "L", layer_name("2d_loc", stem, "L"), BY_CODE["2d_loc"].fields)
        jobs.append(j)
        feats[j.name] = [(domain.loc_line_wkt(), {"Comment": "grid origin and X axis (FMB tools)"})]
    if area_points and len(area_points) >= 3:
        j = LayerJob(BY_CODE["2d_code"], "R", layer_name("2d_code", stem, "R"), BY_CODE["2d_code"].fields)
        jobs.append(j)
        ring = list(area_points) + [area_points[0]]
        feats[j.name] = [("POLYGON(({}))".format(", ".join("{!r} {!r}".format(float(x), float(y)) for x, y in ring)),
                          {"Code": 1})]
    if not jobs:
        return {}
    written, skipped = write_layers(jobs, fmt, target, crs_wkt=crs_wkt, overwrite=overwrite)
    for j in written:
        add_features(j, fmt, feats[j.name])
    out = {}
    for ftype, cmd, value in build_commands(written, fmt, control_dirs, spatial_db=spatial_db):
        out[cmd] = value
    return out
